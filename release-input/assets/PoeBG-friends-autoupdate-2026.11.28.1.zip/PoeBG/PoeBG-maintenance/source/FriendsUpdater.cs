using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public sealed class ReleaseFile { public string path; public string sha256; }
public sealed class ReleaseManifest {
    public int schema; public string version; public string package; public long size;
    public string sha256; public string notes; public ReleaseFile[] files;
}
public static class FriendsUpdater {
    public const string Repository="polo3507489-oss/poebg-maintenance-updates";
    public const string BuildVersion="2026.11.28.1";
    public const string PackageName="PoeBG-maintenance.zip";
    static readonly JavaScriptSerializer Json=new JavaScriptSerializer {MaxJsonLength=4*1024*1024};
    static string Root,Log;
    public static string Hash(string path) {using(var sha=SHA256.Create())using(var s=File.OpenRead(path))return BitConverter.ToString(sha.ComputeHash(s)).Replace("-","").ToLowerInvariant();}
    static void Report(string s) {try{Directory.CreateDirectory(Path.GetDirectoryName(Log));File.AppendAllText(Log,DateTime.Now.ToString("s")+" "+s+Environment.NewLine);}catch{}}
    public static string SafePath(string root,string relative) {
        if(string.IsNullOrEmpty(relative)||relative.Contains("\\")||relative.Contains(":")||relative.StartsWith("/")||relative.Split('/').Any(p=>p==""||p=="."||p==".."||p.EndsWith(".")||p.EndsWith(" ")))throw new Exception("Invalid update path");
        string path=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));
        if(!path.StartsWith(Path.GetFullPath(root).TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase))throw new Exception("Update path escapes folder");
        return path;
    }
    public static bool Protected(string path) {
        string p=path.ToLowerInvariant(); string leaf=p.Split('/').Last();
        return p.StartsWith("role/")||p.StartsWith("log/")||p.StartsWith("poebg-maintenance/transactions/")||p.StartsWith("poebg-maintenance/downloads/")||leaf.EndsWith(".settings")||leaf.EndsWith(".ini")||leaf.EndsWith(".log")||leaf=="blocked-version.txt"||leaf=="installed-release.txt"||leaf==".update-lock"||leaf=="pbupdate.zip"||leaf.Contains("private")||leaf.Contains("signing-key");
    }
    static string PublicKey() {using(var s=typeof(FriendsUpdater).Assembly.GetManifestResourceStream("ReleasePublicKey"))using(var r=new StreamReader(s))return r.ReadToEnd();}
    public static ReleaseManifest Parse(byte[] bytes,byte[] signature) {
        using(var rsa=new RSACryptoServiceProvider()){rsa.PersistKeyInCsp=false;rsa.FromXmlString(PublicKey());if(!rsa.VerifyData(bytes,CryptoConfig.MapNameToOID("SHA256"),signature))throw new Exception("更新簽章不正確，已保留目前版本。");}
        var m=Json.Deserialize<ReleaseManifest>(Encoding.UTF8.GetString(bytes));Version version;
        if(m==null||m.schema!=1||!Version.TryParse(m.version,out version)||m.package!=PackageName||m.size<=0||m.size>128L*1024*1024||!IsHash(m.sha256)||m.files==null||m.files.Length<3||m.files.Length>5000)throw new Exception("Unsupported release manifest");
        var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var f in m.files){SafePath(Path.GetTempPath(),f.path);if(!paths.Add(f.path)||Protected(f.path)||!IsHash(f.sha256))throw new Exception("Update contains a protected or duplicate file");}
        if(!paths.Contains("PoeBG.exe")||!paths.Contains("PoeBGUpdateGuard.exe")||!paths.Contains("PoeBGFriendsUpdater.exe"))throw new Exception("Incomplete update package");
        return m;
    }
    static bool IsHash(string s){return s!=null&&s.Length==64&&s.All(c=>(c>='0'&&c<='9')||(c>='a'&&c<='f'));}
    public static void ExtractVerified(string zipPath,string stage,ReleaseManifest m) {
        if(new FileInfo(zipPath).Length!=m.size||Hash(zipPath)!=m.sha256)throw new Exception("Downloaded package hash mismatch");
        var expected=m.files.ToDictionary(f=>f.path,f=>f.sha256,StringComparer.OrdinalIgnoreCase);
        var found=new HashSet<string>(StringComparer.OrdinalIgnoreCase);long total=0;
        using(var zip=ZipFile.OpenRead(zipPath)){
            if(zip.Entries.Count!=expected.Count)throw new Exception("Unexpected archive entry count");
            foreach(var e in zip.Entries){
                string path=SafePath(stage,e.FullName);
                if(!expected.ContainsKey(e.FullName)||!found.Add(e.FullName)||Protected(e.FullName)||((e.ExternalAttributes>>16)&0xF000)==0xA000||(e.ExternalAttributes&0x400)!=0)throw new Exception("Unexpected archive member");
                total=checked(total+e.Length);if(total>512L*1024*1024)throw new Exception("Update too large");
                Directory.CreateDirectory(Path.GetDirectoryName(path));e.ExtractToFile(path,false);
                if(Hash(path)!=expected[e.FullName])throw new Exception("Extracted file hash mismatch");
            }
        }
    }
    static byte[] Download(string url,int limit) {
        var u=new Uri(url);if(u.Scheme!="https")throw new Exception("HTTPS required");
        ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;
        var req=(HttpWebRequest)WebRequest.Create(u);req.UserAgent="PoeBG-Maintenance-Updater/1.0";req.Timeout=20000;req.ReadWriteTimeout=20000;
        using(var response=(HttpWebResponse)req.GetResponse())using(var input=response.GetResponseStream())using(var output=new MemoryStream()){
            var buffer=new byte[65536];int n;while((n=input.Read(buffer,0,buffer.Length))>0){if(output.Length+n>limit)throw new Exception("Download exceeds limit");output.Write(buffer,0,n);}return output.ToArray();
        }
    }
    static string Asset(Dictionary<string,object> release,string name) {
        string tag=(string)release["tag_name"];
        var assets=(System.Collections.IEnumerable)release["assets"];
        var a=assets.Cast<Dictionary<string,object>>().Single(x=>(string)x["name"]==name);
        string url=(string)a["browser_download_url"];
        string expected="https://github.com/"+Repository+"/releases/download/"+Uri.EscapeDataString(tag)+"/"+name;
        if(url!=expected)throw new Exception("Unexpected release asset source");return url;
    }
    static Version Installed(string root) {
        Version build=new Version(BuildVersion),saved;
        string marker=Path.Combine(root,"PoeBG-maintenance","installed-release.txt");
        if(File.Exists(marker)&&Version.TryParse(File.ReadAllText(marker).Trim(),out saved)&&saved>build)return saved;
        return build;
    }
    static string Q(string s){if(s.Contains("\"")||s.EndsWith("\\"))throw new Exception("Invalid argument");return "\""+s+"\"";}
    static bool Running(string root,string name) {
        foreach(var p in Process.GetProcessesByName(name))using(p){try{if(string.Equals(p.MainModule.FileName,Path.Combine(root,name+".exe"),StringComparison.OrdinalIgnoreCase))return true;}catch{return true;}}
        return false;
    }
    static void StartApp(string root) {
        if(Running(root,"PoeBG"))return;
        Environment.SetEnvironmentVariable("POEBG_CUSTOM_UPDATE_CHECKED","1");
        Process.Start(new ProcessStartInfo(Path.Combine(root,"PoeBG.exe")){WorkingDirectory=root,UseShellExecute=true});
    }
    static bool Check(bool launch) {
        var release=Json.Deserialize<Dictionary<string,object>>(Encoding.UTF8.GetString(Download("https://api.github.com/repos/"+Repository+"/releases/latest",4*1024*1024)));
        if((bool)release["draft"]||(bool)release["prerelease"])return false;
        byte[] bytes=Download(Asset(release,"update.json"),2*1024*1024),sig=Download(Asset(release,"update.sig"),8192);
        var m=Parse(bytes,sig);if(new Version(m.version)<=Installed(Root))return false;
        if(MessageBox.Show("維護版 "+m.version+" 已發布。\n\n"+m.notes+"\n\n下載並安裝？你的角色設定及功能開關會保留。\n若 PoeBG 正在使用，下載完成後請正常關閉它。","PoeBG 維護版更新",MessageBoxButtons.YesNo,MessageBoxIcon.Information)!=DialogResult.Yes)return false;
        string tx=Path.Combine(Root,"PoeBG-maintenance","transactions","friends-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(tx);
        File.WriteAllBytes(Path.Combine(tx,"update.json"),bytes);File.WriteAllBytes(Path.Combine(tx,"update.sig"),sig);
        File.WriteAllBytes(Path.Combine(tx,PackageName),Download(Asset(release,PackageName),128*1024*1024));
        ExtractVerified(Path.Combine(tx,PackageName),Path.Combine(tx,"stage"),m);
        string temp=Path.Combine(Path.GetTempPath(),"PoeBG-maintenance-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);
        string worker=Path.Combine(temp,"PoeBGFriendsUpdater.exe");File.Copy(typeof(FriendsUpdater).Assembly.Location,worker);
        Process.Start(new ProcessStartInfo(worker,"--install "+Q(Root)+" "+Q(tx)){WorkingDirectory=temp,UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden});
        return true;
    }
    public static void InstallVerified(string root,string tx,bool verifyRuntime,bool wait) {
        root=Path.GetFullPath(root).TrimEnd('\\');
        if(!Path.GetFullPath(tx).StartsWith(Path.Combine(root,"PoeBG-maintenance","transactions")+"\\",StringComparison.OrdinalIgnoreCase))throw new Exception("Invalid transaction folder");
        var m=Parse(File.ReadAllBytes(Path.Combine(tx,"update.json")),File.ReadAllBytes(Path.Combine(tx,"update.sig")));
        if(new Version(m.version)<=Installed(root))throw new Exception("Release is already installed or older");
        string stage=Path.Combine(tx,"verified");ExtractVerified(Path.Combine(tx,PackageName),stage,m);
        if(verifyRuntime){
            var start=new ProcessStartInfo(Path.Combine(stage,"PoeBG-maintenance","Verify.exe"),Q(Path.Combine(stage,"PoeBG.exe"))){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};
            using(var p=Process.Start(start)){var stdout=p.StandardOutput.ReadToEndAsync();var stderr=p.StandardError.ReadToEndAsync();if(!p.WaitForExit(90000)){try{p.Kill();}catch{}throw new Exception("Verification timeout");}System.Threading.Tasks.Task.WaitAll(stdout,stderr);Report(stdout.Result+stderr.Result);if(p.ExitCode!=0)throw new Exception("Runtime verification failed");}
        }
        if(wait){
            bool notified=false;DateTime deadline=DateTime.UtcNow.AddMinutes(10);
            while(Running(root,"PoeBG")||Running(root,"PoeBGUpdateGuard")||Running(root,"PoeBGFriendsUpdater")){
                if(!notified){MessageBox.Show("更新已下載並驗證。請儲存設定，正常關閉 PoeBG 及更新視窗後按確定。\n不會強制關閉遊戲或 PoeBG。","等待套用維護版更新");notified=true;}
                if(DateTime.UtcNow>deadline)throw new Exception("程式仍在執行，本次未安裝更新。");Thread.Sleep(500);
            }
        }
        Directory.CreateDirectory(Path.Combine(root,"PoeBG-maintenance"));
        using(var updateLock=new FileStream(Path.Combine(root,"PoeBG-maintenance",".update-lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)){
            if(wait&&(Running(root,"PoeBG")||Running(root,"PoeBGUpdateGuard")||Running(root,"PoeBGFriendsUpdater")))throw new Exception("PoeBG restarted; update postponed");
            var files=m.files.Select(f=>f.path.Replace('/','\\')).ToList();
            // Keep release state inside the same rollback transaction as the binaries.
            File.WriteAllText(Path.Combine(stage,"PoeBG-maintenance","installed-release.txt"),m.version,Encoding.ASCII);files.Add("PoeBG-maintenance\\installed-release.txt");
            var install=typeof(UpdateGuard).GetMethod("Install",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
            try{install.Invoke(null,new object[]{root,stage,files,Path.Combine(tx,"rollback")});}catch(System.Reflection.TargetInvocationException e){throw e.InnerException;}
        }
        Report("Installed maintenance release "+m.version+"; settings preserved.");
    }
    [STAThread]public static int Main(string[] args) {
        Application.EnableVisualStyles();Root=AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
        bool install=args.Length==3&&args[0]=="--install",check=args.Length==1&&args[0]=="--check";
        if(args.Length>0&&!install&&!check)return 2;
        if(install)Root=Path.GetFullPath(args[1]);Log=Path.Combine(Root,"PoeBG-maintenance","friends-update.log");
        bool handedOff=false;
        try{
            if(install){InstallVerified(Root,args[2],true,true);StartApp(Root);return 0;}
            bool created;string mutexName="Local\\PoeBGFriends-"+BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(Root.ToLowerInvariant()))).Replace("-","");
            using(var mutex=new Mutex(true,mutexName,out created)){if(!created)return 0;try{handedOff=Check(!check);}finally{mutex.ReleaseMutex();}}
        }catch(WebException e){Report("Update check unavailable: "+e.Status);}
        catch(Exception e){Report(e.ToString());MessageBox.Show("維護版更新未安裝，保留目前版本。\n"+e.Message,"PoeBG 維護版更新",MessageBoxButtons.OK,MessageBoxIcon.Warning);if(install)return 1;}
        if(!check&&!handedOff)StartApp(Root);return 0;
    }
}

