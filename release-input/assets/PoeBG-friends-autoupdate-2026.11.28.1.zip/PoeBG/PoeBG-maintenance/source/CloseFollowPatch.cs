using System;
using System.Linq;
using System.Collections.Generic;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class CloseFollowPatch {
 static void Need(bool p,string m){if(!p)throw new Exception("Close follow: "+m);}
 static bool Text(MethodDef m,string s){return m.HasBody&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand==s);}
 static bool Call(Instruction i,string text){return i.Operand is IMethod&&((IMethod)i.Operand).FullName==text;}
 static TypeDef Machine(ModuleDef module,MethodDef wrapper){var a=wrapper.CustomAttributes.Single(x=>x.TypeFullName=="System.Runtime.CompilerServices.AsyncStateMachineAttribute");return module.GetTypes().Single(t=>t.FullName==a.ConstructorArguments[0].Value.ToString());}
 public static Instruction FindLoopCadence(MethodDef worker,out FieldDef follow){
  var main=worker.Module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var il=worker.Body.Instructions;
  string delayName="System.Threading.Tasks.Task System.Threading.Tasks.Task::Delay(System.Int32)";
  var delays=il.Where(i=>Call(i,delayName)).ToArray();
  var wrapped=delays.Where(d=>il.Take(il.IndexOf(d)).Reverse().Take(5).Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).DeclaringType.FullName==main.FullName&&((IMethod)i.Operand).Name=="CloseFollowTickDelay")).ToArray();
  if(wrapped.Length>0){Need(wrapped.Length==1,"wrapped cadence ambiguous");follow=main.Methods.Single(m=>m.Name=="CloseFollowIsActive").Body.Instructions.Select(i=>i.Operand as IField).Single(f=>f!=null&&f.DeclaringType.FullName==main.FullName&&f.FieldSig.Type.ElementType==ElementType.Boolean).ResolveFieldDef();return wrapped[0];}
  var found=new Dictionary<Instruction,FieldDef>();
  foreach(var d in delays){
   int at=il.IndexOf(d);var window=il.Skip(Math.Max(0,at-12)).Take(Math.Min(12,at)).ToArray();
   if(window.Any(i=>i.IsLdcI4()&&i.GetLdcI4Value()==100)&&window.Any(i=>i.IsLdcI4()&&i.GetLdcI4Value()==200)){
    var flags=window.Select(i=>i.Operand as IField).Where(f=>f!=null&&f.DeclaringType.FullName==main.FullName&&f.FieldSig.Type.ElementType==ElementType.Boolean).Select(f=>f.ResolveFieldDef()).Distinct().ToArray();if(flags.Length==1)found[d]=flags[0];
   }
   if(at<1||!il[at-1].IsLdcI4()||il[at-1].GetLdcI4Value()!=100)continue;
   for(int n=3;n<il.Count;n++)if((il[n].OpCode==OpCodes.Br||il[n].OpCode==OpCodes.Br_S)&&il[n].Operand==d&&il[n-1].IsLdcI4()&&il[n-1].GetLdcI4Value()==200&&(il[n-2].OpCode==OpCodes.Brtrue||il[n-2].OpCode==OpCodes.Brtrue_S)&&il[n-2].Operand==il[at-1]&&il[n-3].OpCode==OpCodes.Ldfld&&il[n-3].Operand is IField){
    var flag=(IField)il[n-3].Operand;if(flag.DeclaringType.FullName==main.FullName&&flag.FieldSig.Type.ElementType==ElementType.Boolean)found[d]=flag.ResolveFieldDef();
   }
  }
  Need(found.Count==1,"loop cadence control flow missing/ambiguous");follow=found.Single().Value;return found.Single().Key;
 }
 public static void Apply(ModuleDef module) {
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(!profile.Fields.Any(f=>f.Name=="CloseFollowSchema"),"already patched");
  var enabled=profile.Fields.Single(f=>f.Name=="CloseFollowEnabled");var load=profile.Methods.Single(m=>m.Name=="LoadCloseFollowOptions");
  var worker=module.GetTypes().SelectMany(t=>t.Methods).Single(m=>Text(m,"無跟隨路徑  ")&&Text(m,"原地不動多次  "));var il=worker.Body.Instructions;
  var ownerField=worker.DeclaringType.Fields.Single(f=>f.FieldSig.Type.FullName==main.FullName);
  var planner=main.Methods.Single(m=>m.MethodSig.RetType.FullName=="System.Threading.Tasks.Task`1<SharpDX.Vector3>"&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[0].FullName=="SharpDX.Vector3"&&m.MethodSig.Params[1].ElementType==ElementType.I4);
  var plannerMachine=Machine(module,planner).Methods.Single(m=>m.Name=="MoveNext");var pi=plannerMachine.Body.Instructions;
  var fields=pi.Select(i=>i.Operand as IField).Where(f=>f!=null&&f.FieldSig!=null&&f.DeclaringType.FullName==main.FullName).Select(f=>f.ResolveFieldDef()).Where(f=>f!=null).Distinct().ToArray();
  var age=fields.Single(f=>f.FieldSig.Type.FullName=="System.DateTime");var busy=fields.Single(f=>f.FieldSig.Type.ElementType==ElementType.Boolean);
  var cost=Enumerable.Range(0,pi.Count-1).Where(n=>pi[n].Operand is IMethod&&((IMethod)pi[n].Operand).Name=="get_ElapsedMilliseconds"&&pi[n+1].OpCode==OpCodes.Stfld).Select(n=>((IField)pi[n+1].Operand).ResolveFieldDef()).Single();
  var stuck=fields.Where(f=>f.FieldSig.Type.ElementType==ElementType.I4).OrderByDescending(f=>pi.Count(i=>i.Operand is IField&&((IField)i.Operand).FullName==f.FullName)).First();Need(pi.Count(i=>i.Operand is IField&&((IField)i.Operand).FullName==stuck.FullName)>=6,"planner stuck counter shape changed");
  FieldDef follow;var tick=FindLoopCadence(worker,out follow);
  var plans=il.Where(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==planner.FullName).ToArray();Need(plans.Length==1,"follow planning call missing or ambiguous");
  var init=main.Methods.Single(m=>m.HasBody&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="cbAttackWithFollowMan")&&m.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).Name=="set_Name"));
  var ci=init.Body.Instructions;var controls=Enumerable.Range(1,ci.Count-1).Where(n=>ci[n].OpCode==OpCodes.Ldstr&&(string)ci[n].Operand=="numFollowDistance"&&ci[n-1].Operand is IField).Select(n=>((IField)ci[n-1].Operand).ResolveFieldDef()).Where(f=>f.FieldSig.Type.FullName=="System.Windows.Forms.NumericUpDown").Distinct().ToArray();Need(controls.Length==1,"follow distance control ambiguous");var control=controls[0];
  var comparisons=Enumerable.Range(0,il.Count-4).Where(n=>il[n].OpCode==OpCodes.Ldfld&&il[n].Operand is IField&&((IField)il[n].Operand).FullName==control.FullName&&Call(il[n+1],"System.Decimal System.Windows.Forms.NumericUpDown::get_Value()")&&Call(il[n+2],"System.Int32 System.Decimal::op_Explicit(System.Decimal)")&&il[n+3].OpCode==OpCodes.Conv_R4&&(il[n+4].OpCode==OpCodes.Ble_Un||il[n+4].OpCode==OpCodes.Ble_Un_S)).ToArray();Need(comparisons.Length==1,"movement-only threshold shape changed");int compareAt=comparisons[0]+4;var comparison=il[compareAt];
  var distance=il.Skip(Math.Max(0,compareAt-11)).Take(11).Select(i=>i.Operand as IField).Where(f=>f!=null&&f.DeclaringType.FullName==main.FullName&&f.FieldSig.Type.ElementType==ElementType.R4).Select(f=>f.ResolveFieldDef()).Distinct().Single();
  int planAt=il.IndexOf(plans[0]);var ten=Enumerable.Range(compareAt,planAt-compareAt).Where(n=>il[n].IsLdcI4()&&il[n].GetLdcI4Value()==10&&n>0&&il[n-1].Operand is IField&&((IField)il[n-1].Operand).DeclaringType.FullName==main.FullName&&((IField)il[n-1].Operand).FieldSig.Type.ElementType==ElementType.I4&&il[n+1].OpCode==OpCodes.Clt).ToArray();Need(ten.Length==1,"movement stuck limit shape changed");var followCounter=(IField)il[ten[0]-1].Operand;
  var limits=Enumerable.Range(1,il.Count-1).Where(n=>il[n].IsLdcI4()&&(il[n].GetLdcI4Value()==7||il[n].GetLdcI4Value()==10)&&il[n-1].Operand is IField&&((IField)il[n-1].Operand).FullName==followCounter.FullName&&il[n+1].OpCode==OpCodes.Clt).Select(n=>il[n]).ToArray();Need(limits.Length==2&&limits.Any(i=>i.GetLdcI4Value()==7)&&limits.Any(i=>i.GetLdcI4Value()==10),"stuck time-scale limits ambiguous");
  InstallStableHelpers(module,main,profile,follow,planner);
  var tickHelper=main.Methods.Single(m=>m.Name=="CloseFollowTickDelay");var threshold=main.Methods.Single(m=>m.Name=="CloseFollowMoveThreshold");var wrapper=main.Methods.Single(m=>m.Name=="PlanCloseFollow");var limit=profile.Methods.Single(m=>m.Name=="CloseFollowCurrentStuckLimit");
  // Preserve branch-target instruction objects while routing the original values through the feature gate.
  var tempInt=new Local(module.CorLibTypes.Int32);worker.Body.Variables.Add(tempInt);worker.Body.InitLocals=true;tick.OpCode=OpCodes.Stloc;tick.Operand=tempInt;int at=il.IndexOf(tick);foreach(var i in new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,ownerField),Instruction.Create(OpCodes.Ldloc,tempInt),Instruction.Create(OpCodes.Call,tickHelper),Instruction.Create(OpCodes.Call,new Importer(module).Import(typeof(System.Threading.Tasks.Task).GetMethod("Delay",new[]{typeof(int)})))})il.Insert(++at,i);
  var originalCode=comparison.OpCode;var originalTarget=(Instruction)comparison.Operand;var tempFloat=new Local(module.CorLibTypes.Single);worker.Body.Variables.Add(tempFloat);comparison.OpCode=OpCodes.Stloc;comparison.Operand=tempFloat;at=il.IndexOf(comparison);foreach(var i in new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,ownerField),Instruction.Create(OpCodes.Ldloc,tempFloat),Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,ownerField),Instruction.Create(OpCodes.Ldfld,distance),Instruction.Create(OpCodes.Call,threshold),Instruction.Create(originalCode,originalTarget)})il.Insert(++at,i);
  foreach(var value in limits){at=il.IndexOf(value);foreach(var i in new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,ownerField),Instruction.Create(OpCodes.Ldfld,follow),Instruction.Create(OpCodes.Call,limit)})il.Insert(++at,i);}
  plans[0].Operand=wrapper;worker.Body.SimplifyBranches();
  var schema=new FieldDefUser("CloseFollowSchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);schema.Constant=new ConstantUser("1");profile.Fields.Add(schema);Validate(module);
 }
 public static void Validate(ModuleDef module) {
  var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");Need(profile.Fields.Single(f=>f.Name=="CloseFollowSchema").Constant.Value.ToString()=="1","schema missing");  Need(profile.Fields.Single(f=>f.Name=="CloseFollowStabilitySchema").Constant.Value.ToString()=="1","stable geometry schema missing");
  foreach(string name in new[]{"SolveRawCloseFollow","CloseFollowTileBlocked","RestoreRawCloseFollow"}){var solver=main.Methods.Single(m=>m.Name==name);Need(!solver.Body.Instructions.Any(i=>i.Operand is IField&&((IField)i.Operand).FieldSig!=null&&((IField)i.Operand).DeclaringType.FullName==main.FullName&&!((IField)i.Operand).Name.String.StartsWith("CloseFollowSolver")),"shared solver data leaked: "+name);Need(!solver.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).DeclaringType.FullName=="System.Random"),"random movement leaked");}
  foreach(string name in new[]{"SolveRawCloseFollow","CloseFollowTileBlocked","RestoreRawCloseFollow"})foreach(var call in main.Methods.Single(m=>m.Name==name).Body.Instructions.Select(i=>i.Operand as IMethod).Where(m=>m!=null&&m.DeclaringType.FullName==main.FullName)){
   if(call.MethodSig.RetType.ElementType==ElementType.Void&&call.MethodSig.Params.Count==0)Need(call.Name=="CloseFollowIgnoreReload","original terrain reload leaked");
   if(call.MethodSig.RetType.ElementType==ElementType.Boolean&&call.MethodSig.Params.Count==3&&call.MethodSig.Params[0].FullName=="System.Byte[]")Need(call.Name=="CloseFollowTileBlocked","original tile reader leaked");
   if(call.MethodSig.RetType.FullName=="System.Collections.Generic.List`1<SharpDX.Vector3>")Need(call.Name=="RestoreRawCloseFollow"||call.Name=="SolveRawCloseFollow","original route workspace leaked");
  }  var all=module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).ToArray();foreach(string name in new[]{"PlanCloseFollow","CloseFollowTickDelay","CloseFollowMoveThreshold"}){var method=main.Methods.Single(m=>m.Name==name);Need(all.Sum(m=>m.Body.Instructions.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==method.FullName))==1,"hook missing or duplicated: "+name);}
  var limit=profile.Methods.Single(m=>m.Name=="CloseFollowCurrentStuckLimit");Need(all.Sum(m=>m.Body.Instructions.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==limit.FullName))==2,"stuck cadence compensation missing");
  Need(!all.Where(m=>m.Name.String.Contains("CloseFollow")).SelectMany(m=>m.Body.Instructions).Any(i=>i.Operand!=null&&i.Operand.ToString().Contains("CloseFollowTemplate")),"template reference leaked");
 }
 public static void ReplaceExisting(ModuleDef module){
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(profile.Fields.Any(f=>f.Name=="CloseFollowSchema"),"existing close follow missing");
  var active=main.Methods.Single(m=>m.Name=="CloseFollowIsActive");var follow=active.Body.Instructions.Select(i=>i.Operand as IField).Single(f=>f!=null&&f.FieldSig!=null&&f.DeclaringType.FullName==main.FullName).ResolveFieldDef();
  var planner=main.Methods.Single(m=>m.MethodSig.RetType.FullName=="System.Threading.Tasks.Task`1<SharpDX.Vector3>"&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[0].FullName=="SharpDX.Vector3"&&m.MethodSig.Params[1].ElementType==ElementType.I4&&m.Name!="PlanCloseFollow");
  InstallStableHelpers(module,main,profile,follow,planner);Validate(module);
 }
 static FieldDef NewField(TypeDef owner,string name,TypeSig type){var existing=owner.Fields.SingleOrDefault(f=>f.Name==name);if(existing!=null){Need(existing.FieldSig.Type.FullName==type.FullName,"field type changed: "+name);return existing;}var field=new FieldDefUser(name,new FieldSig(type),FieldAttributes.Public);owner.Fields.Add(field);return field;}
 static void InstallStableHelpers(ModuleDef module,TypeDef main,TypeDef profile,FieldDef follow,MethodDef planner){
  var pi=Machine(module,planner).Methods.Single(m=>m.Name=="MoveNext").Body.Instructions;
  var memory=pi.Select(i=>i.Operand as IMethod).Where(m=>m!=null&&m.DeclaringType.FullName==main.FullName).Select(m=>main.Methods.SingleOrDefault(x=>x.FullName==m.FullName)).Where(m=>m!=null).Distinct().ToArray();
  var pointer=memory.Single(m=>m.MethodSig.RetType.ElementType==ElementType.I8&&m.MethodSig.Params.Count==3&&m.MethodSig.Params[0].ElementType==ElementType.I8);
  var world=memory.Single(m=>m.MethodSig.RetType.FullName=="SharpDX.Vector3"&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[0].ElementType==ElementType.I8);
  var solverAsync=memory.Single(m=>m.MethodSig.RetType.FullName=="System.Threading.Tasks.Task`1<System.Collections.Generic.List`1<SharpDX.Vector3>>");
  var solverCalls=Machine(module,solverAsync).Methods.Single(m=>m.Name=="MoveNext").Body.Instructions.Select(i=>i.Operand as IMethod).Where(m=>m!=null&&m.DeclaringType.FullName==main.FullName).Select(m=>main.Methods.SingleOrDefault(x=>x.FullName==m.FullName)).Where(m=>m!=null).Distinct().ToArray();
  var line=solverCalls.Single(m=>m.MethodSig.RetType.ElementType==ElementType.Boolean&&m.MethodSig.Params.Count==3&&m.MethodSig.Params[0].FullName=="System.Byte[]");
  var rawAsync=solverCalls.Single(m=>m.MethodSig.RetType.FullName=="System.Threading.Tasks.Task`1<System.Collections.Generic.List`1<SharpDX.Vector3>>");
  var raw=main.Methods.Single(m=>m.MethodSig.RetType.FullName=="System.Collections.Generic.List`1<SharpDX.Vector3>"&&m.MethodSig.Params.Count==3&&m.MethodSig.Params[0].FullName=="SharpDX.Vector3"&&m.MethodSig.Params[1].FullName=="SharpDX.Vector3");
  var rawCalls=raw.Body.Instructions.Select(i=>i.Operand as IMethod).Where(m=>m!=null&&m.DeclaringType.FullName==main.FullName).Select(m=>main.Methods.SingleOrDefault(x=>x.FullName==m.FullName)).Where(m=>m!=null).Distinct().ToArray();
  var tile=rawCalls.Single(m=>m.MethodSig.RetType.ElementType==ElementType.Boolean&&m.MethodSig.Params.Count==3&&m.MethodSig.Params[0].FullName=="System.Byte[]");
  var restoreCandidates=rawCalls.Where(m=>m.MethodSig.RetType.FullName=="System.Collections.Generic.List`1<SharpDX.Vector3>").ToArray();Need(restoreCandidates.Length==1,"route reconstruction missing/ambiguous");var restore=restoreCandidates[0];
  bool dictionaryRoute=restore.MethodSig.Params.Count==3&&restore.MethodSig.Params[0].FullName.StartsWith("System.Collections.Generic.Dictionary`2<System.Int32,")&&restore.MethodSig.Params[1].FullName.EndsWith("/Node")&&restore.MethodSig.Params[2].ElementType==ElementType.R4;
  Need(restore.MethodSig.Params.Count==2||dictionaryRoute,"route reconstruction signature changed");
  var reload=rawCalls.Single(m=>m.MethodSig.RetType.ElementType==ElementType.Void&&m.MethodSig.Params.Count==0);
  var dims=tile.Body.Instructions.Where(i=>i.Operand is IField&&((IField)i.Operand).FieldSig!=null&&((IField)i.Operand).DeclaringType.FullName==main.FullName&&((IField)i.Operand).FieldSig.Type.ElementType==ElementType.I4).Select(i=>((IField)i.Operand).ResolveFieldDef()).Distinct().ToArray();Need(dims.Length==3,"terrain dimensions ambiguous");
  var rawFields=raw.Body.Instructions.Where(i=>i.Operand is IField&&((IField)i.Operand).FieldSig!=null&&((IField)i.Operand).DeclaringType.FullName==main.FullName).Select(i=>((IField)i.Operand).ResolveFieldDef()).Distinct().ToArray();
  var terrain=rawFields.Single(f=>f.FieldSig.Type.FullName=="System.Byte[]");var nodes=rawFields.SingleOrDefault(f=>f.FieldSig.Type.FullName.EndsWith("/Node[]"));var visits=rawFields.SingleOrDefault(f=>f.FieldSig.Type.FullName=="System.Int32[]");var version=rawFields.SingleOrDefault(f=>f.FieldSig.Type.ElementType==ElementType.I4&&!dims.Contains(f));
  Need(dictionaryRoute?(nodes==null&&visits==null&&version==null):(nodes!=null&&visits!=null&&version!=null),"solver workspace layout changed");
  var cost=pi.Where(i=>i.Operand is IField&&((IField)i.Operand).FieldSig!=null&&((IField)i.Operand).FieldSig.Type.ElementType==ElementType.I8&&((IField)i.Operand).DeclaringType.FullName==main.FullName).Select(i=>((IField)i.Operand).ResolveFieldDef()).Distinct().ToArray();
  var self=cost.Single(f=>!pi.Any(i=>i.OpCode==OpCodes.Stfld&&i.Operand is IField&&((IField)i.Operand).FullName==f.FullName));
  var worker=module.GetTypes().SelectMany(t=>t.Methods).Single(m=>Text(m,"無跟隨路徑  ")&&Text(m,"原地不動多次  "));var wi=worker.Body.Instructions;
  var grid=main.Methods.Single(m=>m.MethodSig.RetType.FullName=="SharpDX.Vector2"&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[0].ElementType==ElementType.I8);
  var distanceStores=Enumerable.Range(1,wi.Count-1).Where(n=>wi[n].OpCode==OpCodes.Stfld&&wi[n].Operand is IField&&((IField)wi[n].Operand).DeclaringType.FullName==main.FullName&&wi[n-1].Operand is IMethod&&((IMethod)wi[n-1].Operand).DeclaringType.FullName=="SharpDX.Vector2"&&((IMethod)wi[n-1].Operand).Name=="Distance").ToArray();Need(distanceStores.Length==1,"leader position source changed");
  var leader=wi.Skip(Math.Max(0,distanceStores[0]-65)).Take(65).Where(i=>i.Operand is IField&&((IField)i.Operand).FieldSig!=null&&((IField)i.Operand).DeclaringType.FullName==main.FullName&&((IField)i.Operand).FieldSig.Type.ElementType==ElementType.I8).Select(i=>((IField)i.Operand).ResolveFieldDef()).Distinct().Single();
  var stop=main.Methods.Single(m=>m.Name=="StopCloseFollowMove"&&m.MethodSig.Params.Count==0);
  MethodDef newRaw=null,newTile=null,newRestore=null;
  using(var source=ModuleDefMD.Load(typeof(CloseFollowPatch).Module.FullyQualifiedName)){
   var map=new Mapper();var vector=planner.MethodSig.Params[0].ToTypeDefOrRef();var gridType=grid.MethodSig.RetType.ToTypeDefOrRef();map.Types["CloseFollowTemplate.Owner"]=main;map.Types["CloseFollowTemplate.Profile"]=profile;map.Types["CloseFollowTemplate.Vector"]=vector;map.Types["CloseFollowTemplate.Grid"]=gridType;
   foreach(string name in new[]{"X","Y","Z"})map.Fields["CloseFollowTemplate.Vector::"+name]=new MemberRefUser(module,name,new FieldSig(module.CorLibTypes.Single),vector);
   foreach(string name in new[]{"X","Y"})map.Fields["CloseFollowTemplate.Grid::"+name]=new MemberRefUser(module,name,new FieldSig(module.CorLibTypes.Single),gridType);
   map.Fields["CloseFollowTemplate.Owner::FollowActive"]=follow;map.Fields["CloseFollowTemplate.Owner::SelfEntity"]=self;map.Fields["CloseFollowTemplate.Owner::LeaderEntity"]=leader;map.Fields["CloseFollowTemplate.Owner::Terrain"]=terrain;map.Fields["CloseFollowTemplate.Owner::WorldWidth"]=dims[0];map.Fields["CloseFollowTemplate.Owner::WorldHeight"]=dims[1];map.Fields["CloseFollowTemplate.Owner::WorldPitch"]=dims[2];map.Fields["CloseFollowTemplate.Profile::CloseFollowEnabled"]=profile.Fields.Single(f=>f.Name=="CloseFollowEnabled");
   map.Methods["CloseFollowTemplate.Profile::LoadCloseFollowOptions"]=profile.Methods.Single(m=>m.Name=="LoadCloseFollowOptions");map.Methods["CloseFollowTemplate.Owner::OriginalPlanner"]=planner;map.Methods["CloseFollowTemplate.Owner::ReadPointer"]=pointer;map.Methods["CloseFollowTemplate.Owner::ReadWorld"]=world;map.Methods["CloseFollowTemplate.Owner::ReadGrid"]=grid;map.Methods["CloseFollowTemplate.Owner::IsClearSegment"]=line;map.Methods["CloseFollowTemplate.Owner::StopMove"]=stop;
   newRaw=main.Methods.SingleOrDefault(m=>m.Name=="SolveRawCloseFollow")??new MethodDefUser("SolveRawCloseFollow",raw.MethodSig,raw.ImplAttributes,raw.Attributes);if(newRaw.DeclaringType==null)main.Methods.Add(newRaw);
   newTile=main.Methods.SingleOrDefault(m=>m.Name=="CloseFollowTileBlocked")??new MethodDefUser("CloseFollowTileBlocked",tile.MethodSig,tile.ImplAttributes,tile.Attributes);if(newTile.DeclaringType==null)main.Methods.Add(newTile);
   newRestore=main.Methods.SingleOrDefault(m=>m.Name=="RestoreRawCloseFollow")??new MethodDefUser("RestoreRawCloseFollow",restore.MethodSig,restore.ImplAttributes,restore.Attributes);if(newRestore.DeclaringType==null)main.Methods.Add(newRestore);map.Methods["CloseFollowTemplate.Owner::RawSolve"]=newRaw;
   var importer=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),map);
   foreach(var f in source.GetTypes().Single(t=>t.FullName=="CloseFollowTemplate.Owner").Fields.Where(f=>f.Name.String.StartsWith("CloseFollow"))){var target=NewField(main,f.Name,importer.Import(f.FieldSig.Type));map.Fields[f.DeclaringType.FullName+"::"+f.Name]=target;}
   var copies=new Dictionary<MethodDef,MethodDef>();var stubs=new[]{"OriginalPlanner","LoadCloseFollowOptions","ReadPointer","ReadWorld","ReadGrid","IsClearSegment","RawSolve","StopMove"};
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="CloseFollowTemplate.Owner"||t.FullName=="CloseFollowTemplate.Profile").SelectMany(t=>t.Methods).Where(m=>m.HasBody&&!m.IsConstructor&&!stubs.Contains(m.Name.String))){var owner=original.DeclaringType.Name=="Owner"?main:profile;var target=owner.Methods.SingleOrDefault(m=>m.Name==original.Name);if(target==null){target=new MethodDefUser(original.Name,importer.Import(original.MethodSig),original.ImplAttributes,original.Attributes);owner.Methods.Add(target);}else Need(target.MethodSig.ToString()==importer.Import(original.MethodSig).ToString(),"helper signature changed: "+original.Name);copies[original]=target;map.Methods[original.DeclaringType.FullName+"::"+original.Name]=target;}
   foreach(var item in copies)CopyBody(item.Key,item.Value,importer);
  }
  var rawMap=new Mapper();foreach(var pair in new[]{new{Old=terrain,New=main.Fields.Single(f=>f.Name=="CloseFollowSolverTerrain")},new{Old=dims[0],New=main.Fields.Single(f=>f.Name=="CloseFollowSolverWidth")},new{Old=dims[1],New=main.Fields.Single(f=>f.Name=="CloseFollowSolverHeight")},new{Old=dims[2],New=main.Fields.Single(f=>f.Name=="CloseFollowSolverPitch")}})rawMap.Fields[pair.Old.DeclaringType.FullName+"::"+pair.Old.Name]=pair.New;
  if(!dictionaryRoute)foreach(var pair in new[]{new{Old=nodes,Name="CloseFollowSolverNodes"},new{Old=visits,Name="CloseFollowSolverVisits"},new{Old=version,Name="CloseFollowSolverVersion"}})rawMap.Fields[pair.Old.DeclaringType.FullName+"::"+pair.Old.Name]=NewField(main,pair.Name,pair.Old.FieldSig.Type);
  rawMap.Methods[raw.DeclaringType.FullName+"::"+raw.Name]=newRaw;rawMap.Methods[tile.DeclaringType.FullName+"::"+tile.Name]=newTile;rawMap.Methods[restore.DeclaringType.FullName+"::"+restore.Name]=newRestore;rawMap.Methods[reload.DeclaringType.FullName+"::"+reload.Name]=main.Methods.Single(m=>m.Name=="CloseFollowIgnoreReload");
  var rawImporter=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),rawMap);CopyBody(raw,newRaw,rawImporter);CopyBody(tile,newTile,rawImporter);CopyBody(restore,newRestore,rawImporter);  foreach(var clone in new[]{newRaw,newTile,newRestore})foreach(var i in clone.Body.Instructions){var method=i.Operand as IMethod;if(method!=null){IMethod mapped;if(rawMap.Methods.TryGetValue(method.DeclaringType.FullName+"::"+method.Name,out mapped))i.Operand=mapped;}var field=i.Operand as IField;if(field!=null&&field.FieldSig!=null){IField mapped;if(rawMap.Fields.TryGetValue(field.DeclaringType.FullName+"::"+field.Name,out mapped))i.Operand=mapped;}}
  foreach(var pair in rawMap.Fields){Need(!newRaw.Body.Instructions.Concat(newTile.Body.Instructions).Concat(newRestore.Body.Instructions).Any(i=>i.Operand is IField&&((IField)i.Operand).DeclaringType.FullName+"::"+((IField)i.Operand).Name==pair.Key),"shared solver workspace leaked");}
  if(!profile.Fields.Any(f=>f.Name=="CloseFollowStabilitySchema")){var schema=new FieldDefUser("CloseFollowStabilitySchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);schema.Constant=new ConstantUser("1");profile.Fields.Add(schema);}
 }
 sealed class Mapper:ImportMapper {
  public readonly Dictionary<string,ITypeDefOrRef> Types=new Dictionary<string,ITypeDefOrRef>();public readonly Dictionary<string,IField> Fields=new Dictionary<string,IField>();public readonly Dictionary<string,IMethod> Methods=new Dictionary<string,IMethod>();
  public override ITypeDefOrRef Map(ITypeDefOrRef t){ITypeDefOrRef v;return Types.TryGetValue(t.FullName,out v)?v:null;}public override IField Map(FieldDef f){IField v;return Fields.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}public override IMethod Map(MethodDef f){IMethod v;return Methods.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
 }
 static void CopyBody(MethodDef source,MethodDef target,Importer importer) {
  target.Body=new CilBody{InitLocals=source.Body.InitLocals,MaxStack=source.Body.MaxStack};
  var locals=new Dictionary<Local,Local>();foreach(var l in source.Body.Variables){var n=new Local(importer.Import(l.Type));target.Body.Variables.Add(n);locals[l]=n;}
  var instructions=new Dictionary<Instruction,Instruction>();foreach(var i in source.Body.Instructions){var n=new Instruction(i.OpCode,null);target.Body.Instructions.Add(n);instructions[i]=n;}
  foreach(var i in source.Body.Instructions){object o=i.Operand;if(o is Instruction)o=instructions[(Instruction)o];else if(o is Instruction[])o=((Instruction[])o).Select(x=>instructions[x]).ToArray();else if(o is Local)o=locals[(Local)o];else if(o is Parameter)o=target.Parameters[((Parameter)o).Index];else if(o is IMethod)o=importer.Import((IMethod)o);else if(o is IField)o=importer.Import((IField)o);else if(o is ITypeDefOrRef)o=importer.Import((ITypeDefOrRef)o);else if(o is MethodSig)o=importer.Import((MethodSig)o);instructions[i].Operand=o;}
  foreach(var h in source.Body.ExceptionHandlers)target.Body.ExceptionHandlers.Add(new ExceptionHandler(h.HandlerType){TryStart=h.TryStart==null?null:instructions[h.TryStart],TryEnd=h.TryEnd==null?null:instructions[h.TryEnd],HandlerStart=h.HandlerStart==null?null:instructions[h.HandlerStart],HandlerEnd=h.HandlerEnd==null?null:instructions[h.HandlerEnd],FilterStart=h.FilterStart==null?null:instructions[h.FilterStart],CatchType=h.CatchType==null?null:importer.Import(h.CatchType)});
  target.Body.SimplifyBranches();
 }

}
