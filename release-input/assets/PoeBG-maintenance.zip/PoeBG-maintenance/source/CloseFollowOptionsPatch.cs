using System;using System.Linq;using System.Collections.Generic;using dnlib.DotNet;using dnlib.DotNet.Emit;
public static class CloseFollowOptionsPatch {
 static void Need(bool ok,string message){if(!ok)throw new Exception("Close follow options: "+message);}
 public static void Apply(ModuleDef module) {
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(!profile.Fields.Any(f=>f.Name=="CloseFollowEnabled"),"already patched");
  var constructor=main.Methods.Single(m=>m.IsInstanceConstructor&&m.MethodSig.Params.Count==0);
  var returns=constructor.Body.Instructions.Where(i=>i.OpCode==OpCodes.Ret).ToArray();Need(returns.Length==1,"unexpected main constructor returns");
  var initializer=main.Methods.Single(m=>m.HasBody&&m.Body.Instructions.Count(i=>i.OpCode==OpCodes.Newobj&&i.Operand is IMethod&&((IMethod)i.Operand).DeclaringType.FullName=="System.Windows.Forms.CheckBox")>5&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="cbOptIn")&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="cbAutoFollow"));
  Need(constructor.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==initializer.FullName),"follow controls initializer is not called by constructor");
  using(var source=ModuleDefMD.Load(typeof(CloseFollowOptionsPatch).Module.FullyQualifiedName)) {
   var map=new Mapper();map.Types["CloseFollowOptionsTemplate.Profile"]=profile;map.Types["CloseFollowOptionsTemplate.Owner"]=main;
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="CloseFollowOptionsTemplate.Profile"||t.FullName=="CloseFollowOptionsTemplate.Owner").SelectMany(t=>t.Fields)) {
    var target=new FieldDefUser(original.Name,new FieldSig(new Importer(module).Import(original.FieldSig.Type)),original.Attributes);var owner=original.DeclaringType.Name=="Profile"?profile:main;owner.Fields.Add(target);map.Fields[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   var importer=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),map);var copies=new Dictionary<MethodDef,MethodDef>();
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="CloseFollowOptionsTemplate.Profile"||t.FullName=="CloseFollowOptionsTemplate.Owner").SelectMany(t=>t.Methods).Where(m=>m.HasBody&&!m.IsConstructor)) {
    var target=new MethodDefUser(original.Name,importer.Import(original.MethodSig),original.ImplAttributes,original.Attributes);var owner=original.DeclaringType.Name=="Profile"?profile:main;owner.Methods.Add(target);copies[original]=target;map.Methods[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   foreach(var item in copies)CopyBody(item.Key,item.Value,importer);
  }
  var attach=main.Methods.Single(m=>m.Name=="AttachCloseFollowOption");var ret=returns[0];int at=constructor.Body.Instructions.IndexOf(ret);ret.OpCode=OpCodes.Ldarg_0;ret.Operand=null;constructor.Body.Instructions.Insert(++at,Instruction.Create(OpCodes.Call,attach));constructor.Body.Instructions.Insert(++at,Instruction.Create(OpCodes.Ret));constructor.Body.SimplifyBranches();
  var schema=new FieldDefUser("CloseFollowOptionsSchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);schema.Constant=new ConstantUser("1");profile.Fields.Add(schema);StampLayout(module);Validate(module);
 }
 public static void ReplaceExisting(ModuleDef module) {
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(profile.Fields.Any(f=>f.Name=="CloseFollowEnabled")&&main.Methods.Any(m=>m.Name=="AttachCloseFollowOption"),"existing option was not found");
  using(var source=ModuleDefMD.Load(typeof(CloseFollowOptionsPatch).Module.FullyQualifiedName)) {
   var map=new Mapper();map.Types["CloseFollowOptionsTemplate.Profile"]=profile;map.Types["CloseFollowOptionsTemplate.Owner"]=main;
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="CloseFollowOptionsTemplate.Profile"||t.FullName=="CloseFollowOptionsTemplate.Owner").SelectMany(t=>t.Fields)) {
    var owner=original.DeclaringType.Name=="Profile"?profile:main;var target=owner.Fields.SingleOrDefault(f=>f.Name==original.Name);
    if(target==null){target=new FieldDefUser(original.Name,new FieldSig(new Importer(module).Import(original.FieldSig.Type)),original.Attributes);owner.Fields.Add(target);}map.Fields[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   var importer=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),map);var copies=new Dictionary<MethodDef,MethodDef>();
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="CloseFollowOptionsTemplate.Profile"||t.FullName=="CloseFollowOptionsTemplate.Owner").SelectMany(t=>t.Methods).Where(m=>m.HasBody&&!m.IsConstructor)) {
    var owner=original.DeclaringType.Name=="Profile"?profile:main;var target=owner.Methods.SingleOrDefault(m=>m.Name==original.Name);
    if(target==null){Need(owner==main,"missing existing persistence helper");target=new MethodDefUser(original.Name,importer.Import(original.MethodSig),original.ImplAttributes,original.Attributes);owner.Methods.Add(target);}
    map.Methods[original.DeclaringType.FullName+"::"+original.Name]=target;
    if(owner==main)copies[original]=target;
   }
   foreach(var item in copies)CopyBody(item.Key,item.Value,importer);
  }
  StampLayout(module);Validate(module);
 }
 static void StampLayout(ModuleDef module) {
  var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");var stamp=profile.Fields.SingleOrDefault(f=>f.Name=="CloseFollowOptionsLayoutSchema");
  if(stamp==null){stamp=new FieldDefUser("CloseFollowOptionsLayoutSchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);profile.Fields.Add(stamp);}stamp.Constant=new ConstantUser("2");
 }
 public static void Validate(ModuleDef module) {
  var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");
  Need(profile.Fields.Single(f=>f.Name=="CloseFollowOptionsSchema").Constant.Value.ToString()=="1","schema missing");Need(profile.Fields.Single(f=>f.Name=="CloseFollowOptionsLayoutSchema").Constant.Value.ToString()=="2","layout schema missing");
  Need(main.Fields.Single(f=>f.Name=="CloseFollowOptionBox").FieldSig.Type.FullName=="System.Windows.Forms.CheckBox","checkbox field missing");
  var all=module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).ToArray();var attach=main.Methods.Single(m=>m.Name=="AttachCloseFollowOption");
  Need(all.Sum(m=>m.Body.Instructions.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==attach.FullName))==1,"main attach hook missing/duplicated");
  Need(!all.Where(m=>m.Name.Contains("CloseFollowOption")).SelectMany(m=>m.Body.Instructions).Any(i=>i.Operand!=null&&i.Operand.ToString().Contains("CloseFollowOptionsTemplate")),"template reference leaked");
 }
 sealed class Mapper:ImportMapper {
  public readonly Dictionary<string,ITypeDefOrRef> Types=new Dictionary<string,ITypeDefOrRef>();
  public readonly Dictionary<string,IField> Fields=new Dictionary<string,IField>();
  public readonly Dictionary<string,IMethod> Methods=new Dictionary<string,IMethod>();
  public override ITypeDefOrRef Map(ITypeDefOrRef t){ITypeDefOrRef v;return Types.TryGetValue(t.FullName,out v)?v:null;}
  public override IField Map(FieldDef f){IField v;return Fields.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
  public override IMethod Map(MethodDef f){IMethod v;return Methods.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
 }
 static void CopyBody(MethodDef source,MethodDef target,Importer importer) {
  target.Body=new CilBody{InitLocals=source.Body.InitLocals,MaxStack=source.Body.MaxStack};
  var locals=new Dictionary<Local,Local>();foreach(var l in source.Body.Variables){var n=new Local(importer.Import(l.Type));target.Body.Variables.Add(n);locals[l]=n;}
  var instructions=new Dictionary<Instruction,Instruction>();foreach(var i in source.Body.Instructions){var n=new Instruction(i.OpCode,null);target.Body.Instructions.Add(n);instructions[i]=n;}
  foreach(var i in source.Body.Instructions){object o=i.Operand;if(o is Instruction)o=instructions[(Instruction)o];else if(o is Instruction[])o=((Instruction[])o).Select(x=>instructions[x]).ToArray();else if(o is Local)o=locals[(Local)o];else if(o is Parameter)o=target.Parameters[((Parameter)o).Index];else if(o is IMethod)o=importer.Import((IMethod)o);else if(o is IField)o=importer.Import((IField)o);else if(o is ITypeDefOrRef)o=importer.Import((ITypeDefOrRef)o);else if(o is MethodSig)o=importer.Import((MethodSig)o);instructions[i].Operand=o;}
  foreach(var h in source.Body.ExceptionHandlers)target.Body.ExceptionHandlers.Add(new ExceptionHandler(h.HandlerType){TryStart=h.TryStart==null?null:instructions[h.TryStart],TryEnd=h.TryEnd==null?null:instructions[h.TryEnd],HandlerStart=h.HandlerStart==null?null:instructions[h.HandlerStart],HandlerEnd=h.HandlerEnd==null?null:instructions[h.HandlerEnd],FilterStart=h.FilterStart==null?null:instructions[h.FilterStart],CatchType=h.CatchType==null?null:importer.Import(h.CatchType)});
  target.Body.SimplifyBranches();
 }
}
