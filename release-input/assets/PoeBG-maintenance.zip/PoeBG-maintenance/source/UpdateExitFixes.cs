using System;
using System.Linq;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

public static class UpdateExitFixes {
    public static void Apply(ModuleDef module) {
        var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
        if(profile.Fields.Any(f=>f.Name=="UpdateHandoffPending")||profile.Methods.Any(m=>m.Name=="ExitAfterUpdateHandoff"))throw new Exception("Update exit guard already present");
        var machine=module.GetTypes().Single(t=>t.FullName.Contains("PoeBG.Main/<CheckUpdate>"));
        var move=machine.Methods.Single(m=>m.Name=="MoveNext");var il=move.Body.Instructions;
        var exits=Enumerable.Range(0,il.Count).Where(i=>il[i].OpCode==OpCodes.Call&&il[i].Operand is IMethod&&((IMethod)il[i].Operand).FullName=="System.Void System.Windows.Forms.Application::Exit()").ToArray();
        // ServiceFixes must already have removed the empty-version-response exit.
        if(exits.Length!=1)throw new Exception("Expected exactly one update-success Application.Exit after service repair");
        int at=exits[0];
        var start=at>=2?il[at-2].Operand as IMethod:null;
        if(at<2||il[at-1].OpCode!=OpCodes.Pop||start==null||start.DeclaringType.FullName!="System.Diagnostics.Process"||start.Name!="Start"||start.MethodSig.RetType.FullName!="System.Diagnostics.Process"||start.MethodSig.Params.Count!=1||start.MethodSig.Params[0].FullName!="System.Diagnostics.ProcessStartInfo")throw new Exception("Unrecognized update handoff start/exit sequence");
        if(!il.Skip(Math.Max(0,at-72)).Take(Math.Min(72,at)).Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="PoeBGUpdateGuard.exe"))throw new Exception("Update exit is not preceded by the trusted guard launch path");
        var entry=module.EntryPoint;
        if(entry==null||!entry.HasBody)throw new Exception("Missing managed entry point");
        var returns=entry.Body.Instructions.Where(i=>i.OpCode==OpCodes.Ret).ToArray();
        if(returns.Length!=1)throw new Exception("Unsupported entry-point return shape");
        var runHosts=module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody&&m.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).DeclaringType.FullName=="System.Windows.Forms.Application"&&((IMethod)i.Operand).Name=="Run")).ToArray();
        if(!entry.Body.Instructions.Any(i=>i.Operand is IMethod&&runHosts.Any(host=>((IMethod)i.Operand).FullName==host.FullName)))throw new Exception("Entry point does not call the verified WinForms message-loop wrapper");
        var pending=new FieldDefUser("UpdateHandoffPending",new FieldSig(module.CorLibTypes.Boolean),FieldAttributes.Public|FieldAttributes.Static);profile.Fields.Add(pending);
        var complete=new MethodDefUser("ExitAfterUpdateHandoff",MethodSig.CreateStatic(module.CorLibTypes.Void),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Public|MethodAttributes.Static|MethodAttributes.HideBySig);profile.Methods.Add(complete);
        complete.Body=new CilBody();var done=Instruction.Create(OpCodes.Ret);
        complete.Body.Instructions.Add(Instruction.Create(OpCodes.Ldsfld,pending));complete.Body.Instructions.Add(Instruction.Create(OpCodes.Brfalse,done));
        complete.Body.Instructions.Add(Instruction.Create(OpCodes.Ldc_I4_0));complete.Body.Instructions.Add(Instruction.Create(OpCodes.Call,new Importer(module).Import(typeof(Environment).GetMethod("Exit",new[]{typeof(int)}))));complete.Body.Instructions.Add(done);
        il.Insert(at,Instruction.Create(OpCodes.Ldc_I4_1));il.Insert(at+1,Instruction.Create(OpCodes.Stsfld,pending));move.Body.SimplifyBranches();
        // Preserve the ret object so any existing branch to the return executes this hook.
        var ret=returns[0];ret.OpCode=OpCodes.Call;ret.Operand=complete;entry.Body.Instructions.Insert(entry.Body.Instructions.IndexOf(ret)+1,Instruction.Create(OpCodes.Ret));entry.Body.SimplifyBranches();
    }
}

