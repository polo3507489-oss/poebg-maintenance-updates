using System;
using System.Threading;
namespace FollowMoveInputTemplate {
 public static class Profile {
  public static volatile bool CloseFollowEnabled;
  public static void LoadCloseFollowOptions(){throw new NotSupportedException();}
  public static bool IsCloseFollowMoveLetter(int key){return key>=65&&key<=90;}
  public static int CloseFollowMoveKeyData(uint scan,bool up,bool repeated){return unchecked((int)(1u|((scan&255u)<<16)|(up?0xC0000000u:(repeated?0x40000000u:0u))));}
 }
 public static class Native {
  public static int Post(IntPtr window,int message,int key,int data){throw new NotSupportedException();}
  public static int State(int key){throw new NotSupportedException();}
  public static int Pid(IntPtr window,out int pid){throw new NotSupportedException();}
  public static uint Scan(uint key,uint kind){throw new NotSupportedException();}
 }
 public class Owner {
  private object CloseFollowMoveSync;
  public bool CloseFollowMoveOwned;
  public IntPtr CloseFollowMoveWindow;
  public int CloseFollowMoveKey;
  public int CloseFollowMoveProcess;
  public uint CloseFollowMoveScan;
  private object CloseFollowMoveGate(){if(CloseFollowMoveSync==null)Interlocked.CompareExchange(ref CloseFollowMoveSync,new object(),null);return CloseFollowMoveSync;}
  private void ClearCloseFollowMoveOwnership(){CloseFollowMoveOwned=false;CloseFollowMoveWindow=IntPtr.Zero;CloseFollowMoveKey=0;CloseFollowMoveProcess=0;CloseFollowMoveScan=0;}
  private bool StopOwnedCloseFollowMove() {
   if(!CloseFollowMoveOwned)return true;
   int process;
   if(CloseFollowMoveWindow==IntPtr.Zero||!Profile.IsCloseFollowMoveLetter(CloseFollowMoveKey)||Native.Pid(CloseFollowMoveWindow,out process)==0||process!=CloseFollowMoveProcess||(Native.State(CloseFollowMoveKey)&0x8000)!=0){ClearCloseFollowMoveOwnership();return true;}
   int sent=Native.Post(CloseFollowMoveWindow,257,CloseFollowMoveKey,Profile.CloseFollowMoveKeyData(CloseFollowMoveScan,true,false));
   if(sent==0)return false;
   ClearCloseFollowMoveOwnership();return true;
  }
  public void StopCloseFollowMove(){lock(CloseFollowMoveGate()){StopOwnedCloseFollowMove();}}
  public int SendCloseFollowMove(IntPtr window,int message,int key,int data) {
   Profile.LoadCloseFollowOptions();
   lock(CloseFollowMoveGate()) {
    if(!Profile.CloseFollowEnabled){if(!StopOwnedCloseFollowMove())return 0;return Native.Post(window,message,key,data);}
    if(window==IntPtr.Zero||message!=256||!Profile.IsCloseFollowMoveLetter(key)){StopOwnedCloseFollowMove();return 0;}
    int process;
    if(Native.Pid(window,out process)==0||process<=0){StopOwnedCloseFollowMove();return 0;}
    if((Native.State(key)&0x8000)!=0){StopOwnedCloseFollowMove();return 0;}
    if(CloseFollowMoveOwned&&(CloseFollowMoveWindow!=window||CloseFollowMoveKey!=key||CloseFollowMoveProcess!=process))if(!StopOwnedCloseFollowMove())return 0;
    uint scan=CloseFollowMoveOwned?CloseFollowMoveScan:Native.Scan((uint)key,0);
    int sent=Native.Post(window,256,key,Profile.CloseFollowMoveKeyData(scan,false,CloseFollowMoveOwned));
    if(sent!=0){CloseFollowMoveOwned=true;CloseFollowMoveWindow=window;CloseFollowMoveKey=key;CloseFollowMoveProcess=process;CloseFollowMoveScan=scan;}
    return sent;
   }
  }
 }
}
