using System;
using System.Linq;
using System.Collections.Generic;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class FollowMoveInputPatch {
 static void Need(bool value,string message){if(!value)throw new Exception("Close-follow input: "+message);}
 static bool Text(MethodDef method,string value){return method.HasBody&&method.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand==value);}
 public static Instruction FindLoopDelayResult(MethodDef worker){
  Need(worker!=null&&worker.HasBody,"follow worker body missing");
  var il=worker.Body.Instructions;
  FieldDef follow;var loopDelay=CloseFollowPatch.FindLoopCadence(worker,out follow);
  var awaitTest=il.Skip(il.IndexOf(loopDelay)+1).Take(12).ToArray();
  var completed=awaitTest.FirstOrDefault(i=>i.OpCode==OpCodes.Brtrue||i.OpCode==OpCodes.Brtrue_S||i.OpCode==OpCodes.Brfalse||i.OpCode==OpCodes.Brfalse_S);
  Need(completed!=null&&completed.Operand is Instruction,"loop-delay completion target missing");
  Need(il.Contains((Instruction)completed.Operand),"loop-delay completion target outside worker");
  int resume=completed.OpCode==OpCodes.Brfalse||completed.OpCode==OpCodes.Brfalse_S?il.IndexOf(completed)+1:il.IndexOf((Instruction)completed.Operand);
  Need(resume>=0&&resume<il.Count,"loop-delay completion path outside worker");
  Need(awaitTest.Take(Array.IndexOf(awaitTest,completed)).Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName=="System.Boolean System.Runtime.CompilerServices.TaskAwaiter::get_IsCompleted()"),"loop-delay awaiter completion check missing");
  var results=il.Skip(resume).Take(4).Where(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName=="System.Void System.Runtime.CompilerServices.TaskAwaiter::GetResult()").ToArray();
  Need(results.Length==1,"loop-delay resume GetResult missing/ambiguous");
  return results[0];
 }
 public static void Apply(ModuleDef module){
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(!profile.Fields.Any(f=>f.Name=="CloseFollowInputSchema"),"already patched");
  var native=module.GetTypes().Single(t=>t.FullName=="PoeBG.API");
  var post=native.Methods.Single(m=>m.ImplMap!=null&&m.ImplMap.Name=="PostMessage"&&m.MethodSig.Params.Count==4&&m.MethodSig.Params[3].ElementType==ElementType.I4);
  var state=native.Methods.Single(m=>m.ImplMap!=null&&m.ImplMap.Name=="GetAsyncKeyState");
  var pid=native.Methods.Single(m=>m.ImplMap!=null&&m.ImplMap.Name=="GetWindowThreadProcessId"&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[1].ElementType==ElementType.ByRef);
  var worker=module.GetTypes().SelectMany(t=>t.Methods).Single(m=>Text(m,"無跟隨路徑  ")&&Text(m,"原地不動多次  "));var il=worker.Body.Instructions;
  var owner=worker.DeclaringType.Fields.Single(f=>f.FieldSig.Type.FullName==main.FullName);
  var init=main.Methods.Single(m=>Text(m,"tbAutoFollowMoveKey")&&m.Body.Instructions.Count(i=>i.OpCode==OpCodes.Newobj&&i.Operand is IMethod&&((IMethod)i.Operand).DeclaringType.FullName=="System.Windows.Forms.CheckBox")>5);var ci=init.Body.Instructions;
  var controls=Enumerable.Range(1,ci.Count-1).Where(n=>ci[n].OpCode==OpCodes.Ldstr&&(string)ci[n].Operand=="tbAutoFollowMoveKey"&&ci[n-1].Operand is IField).Select(n=>(IField)ci[n-1].Operand).Distinct().ToArray();Need(controls.Length==1,"walk-key control ambiguous");
  var candidates=Enumerable.Range(0,il.Count).Where(n=>il[n].Operand is IMethod&&((IMethod)il[n].Operand).FullName==post.FullName&&il.Skip(Math.Max(0,n-16)).Take(Math.Min(16,n)).Any(i=>i.OpCode==OpCodes.Ldfld&&i.Operand is IField&&((IField)i.Operand).FullName==controls[0].FullName)).ToArray();Need(candidates.Length==1,"walk-key input call missing/ambiguous");
  var walkCall=il[candidates[0]];
  var releaseAt=FindLoopDelayResult(worker);
  var closings=main.Methods.Where(m=>m.HasBody&&!m.IsConstructor&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[1].FullName=="System.Windows.Forms.FormClosingEventArgs").ToArray();Need(closings.Length==1,"main closing cleanup ambiguous");
  var scan=new MethodDefUser("CloseFollowMoveMapVirtualKey",MethodSig.CreateStatic(module.CorLibTypes.UInt32,module.CorLibTypes.UInt32,module.CorLibTypes.UInt32),MethodImplAttributes.PreserveSig,MethodAttributes.Private|MethodAttributes.Static|MethodAttributes.HideBySig|MethodAttributes.PinvokeImpl);
  scan.ImplMap=new ImplMapUser(new ModuleRefUser(module,"user32.dll"),"MapVirtualKeyW",PInvokeAttributes.CallConvWinapi|PInvokeAttributes.CharSetUnicode);main.Methods.Add(scan);
  using(var source=ModuleDefMD.Load(typeof(FollowMoveInputPatch).Module.FullyQualifiedName)){
   var map=new Mapper();map.Types["FollowMoveInputTemplate.Owner"]=main;map.Types["FollowMoveInputTemplate.Profile"]=profile;
   map.Fields["FollowMoveInputTemplate.Profile::CloseFollowEnabled"]=profile.Fields.Single(f=>f.Name=="CloseFollowEnabled");
   map.Methods["FollowMoveInputTemplate.Profile::LoadCloseFollowOptions"]=profile.Methods.Single(m=>m.Name=="LoadCloseFollowOptions");
   map.Methods["FollowMoveInputTemplate.Native::Post"]=post;map.Methods["FollowMoveInputTemplate.Native::State"]=state;map.Methods["FollowMoveInputTemplate.Native::Pid"]=pid;map.Methods["FollowMoveInputTemplate.Native::Scan"]=scan;
   var importer=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),map);
   foreach(var original in source.GetTypes().Single(t=>t.FullName=="FollowMoveInputTemplate.Owner").Fields){var target=new FieldDefUser(original.Name,new FieldSig(importer.Import(original.FieldSig.Type)),original.Attributes);main.Fields.Add(target);map.Fields[original.DeclaringType.FullName+"::"+original.Name]=target;}
   var copies=new Dictionary<MethodDef,MethodDef>();
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="FollowMoveInputTemplate.Owner"||t.FullName=="FollowMoveInputTemplate.Profile").SelectMany(t=>t.Methods).Where(m=>m.HasBody&&!m.IsConstructor&&m.Name!="LoadCloseFollowOptions")){
    var target=new MethodDefUser(original.Name,importer.Import(original.MethodSig),original.ImplAttributes,original.Attributes);(original.DeclaringType.Name=="Owner"?main:profile).Methods.Add(target);copies[original]=target;map.Methods[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   foreach(var pair in copies)CopyBody(pair.Key,pair.Value,importer);
  }
  var send=main.Methods.Single(m=>m.Name=="SendCloseFollowMove");var stop=main.Methods.Single(m=>m.Name=="StopCloseFollowMove");
  var h=new Local(module.CorLibTypes.IntPtr);var msg=new Local(module.CorLibTypes.Int32);var key=new Local(module.CorLibTypes.Int32);var data=new Local(module.CorLibTypes.Int32);foreach(var local in new[]{h,msg,key,data})worker.Body.Variables.Add(local);worker.Body.InitLocals=true;
  walkCall.OpCode=OpCodes.Stloc;walkCall.Operand=data;int at=il.IndexOf(walkCall);
  foreach(var instruction in new[]{Instruction.Create(OpCodes.Stloc,key),Instruction.Create(OpCodes.Stloc,msg),Instruction.Create(OpCodes.Stloc,h),Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,owner),Instruction.Create(OpCodes.Ldloc,h),Instruction.Create(OpCodes.Ldloc,msg),Instruction.Create(OpCodes.Ldloc,key),Instruction.Create(OpCodes.Ldloc,data),Instruction.Create(OpCodes.Call,send)})il.Insert(++at,instruction);
  worker.Body.SimplifyBranches();
  at=il.IndexOf(releaseAt);foreach(var instruction in new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,owner),Instruction.Create(OpCodes.Call,stop)})il.Insert(++at,instruction);
  worker.Body.SimplifyBranches();
  var close=closings[0];close.Body.Instructions.Insert(0,Instruction.Create(OpCodes.Ldarg_0));close.Body.Instructions.Insert(1,Instruction.Create(OpCodes.Call,stop));close.Body.SimplifyBranches();
  var schema=new FieldDefUser("CloseFollowInputSchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);schema.Constant=new ConstantUser("1");profile.Fields.Add(schema);Validate(module);
 }
 public static void Validate(ModuleDef module){
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");Need(profile.Fields.Single(f=>f.Name=="CloseFollowInputSchema").Constant.Value.ToString()=="1","input schema missing");
  var send=main.Methods.Single(m=>m.Name=="SendCloseFollowMove");var stop=main.Methods.Single(m=>m.Name=="StopCloseFollowMove");
  var methods=module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).ToArray();Need(methods.Sum(m=>m.Body.Instructions.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==send.FullName))==1,"walk input hook missing/duplicated");
  Need(main.Methods.Any(m=>m.MethodSig.Params.Count==2&&m.MethodSig.Params[1].FullName=="System.Windows.Forms.FormClosingEventArgs"&&m.HasBody&&m.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==stop.FullName)),"closing release hook missing");
  var worker=methods.Single(m=>Text(m,"無跟隨路徑  ")&&Text(m,"原地不動多次  "));var il=worker.Body.Instructions;
  var getResult=FindLoopDelayResult(worker);
  Need(il.Skip(il.IndexOf(getResult)+1).Take(3).Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==stop.FullName),"per-loop leased-input release missing");
  Need(!methods.Where(m=>m.Name.Contains("CloseFollowMove")).SelectMany(m=>m.Body.Instructions).Any(i=>i.Operand!=null&&i.Operand.ToString().Contains("FollowMoveInputTemplate")),"template reference leaked");
 }
 sealed class Mapper:ImportMapper {
  public readonly Dictionary<string,ITypeDefOrRef> Types=new Dictionary<string,ITypeDefOrRef>();public readonly Dictionary<string,IField> Fields=new Dictionary<string,IField>();public readonly Dictionary<string,IMethod> Methods=new Dictionary<string,IMethod>();
  public override ITypeDefOrRef Map(ITypeDefOrRef t){ITypeDefOrRef v;return Types.TryGetValue(t.FullName,out v)?v:null;}public override IField Map(FieldDef f){IField v;return Fields.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}public override IMethod Map(MethodDef f){IMethod v;return Methods.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
 }
 static void CopyBody(MethodDef source,MethodDef target,Importer importer) {
  target.Body=new CilBody{InitLocals=source.Body.InitLocals,MaxStack=source.Body.MaxStack};
  var locals=new Dictionary<Local,Local>();foreach(var l in source.Body.Variables){var n=new Local(importer.Import(l.Type));target.Body.Variables.Add(n);locals[l]=n;}
  var instructions=new Dictionary<Instruction,Instruction>();foreach(var i in source.Body.Instructions){var n=new Instruction(i.OpCode,null);target.Body.Instructions.Add(n);instructions[i]=n;}
  foreach(var i in source.Body.Instructions){object o=i.Operand;if(o is Instruction)o=instructions[(Instruction)o];else if(o is Instruction[])o=((Instruction[])o).Select(x=>instructions[x]).ToArray();else if(o is Local)o=locals[(Local)o];else if(o is Parameter)o=target.Parameters[((Parameter)o).Index];else if(o is IMethod)o=importer.Import((IMethod)o);else if(o is IField)o=importer.Import((IField)o);else if(o is ITypeDefOrRef)o=importer.Import((ITypeDefOrRef)o);else if(o is MethodSig)o=importer.Import((MethodSig)o);instructions[i].Operand=o;}
  foreach(var h in source.Body.ExceptionHandlers)target.Body.ExceptionHandlers.Add(new ExceptionHandler(h.HandlerType){TryStart=h.TryStart==null?null:instructions[h.TryStart],TryEnd=h.TryEnd==null?null:instructions[h.TryEnd],HandlerStart=h.HandlerStart==null?null:instructions[h.HandlerStart],HandlerEnd=h.HandlerEnd==null?null:instructions[h.HandlerEnd],FilterStart=h.FilterStart==null?null:instructions[h.FilterStart],CatchType=h.CatchType==null?null:importer.Import(h.CatchType)});
  target.Body.SimplifyBranches();
 }


}
