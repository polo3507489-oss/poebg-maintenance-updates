using System;
using System.Reflection;
public static class CloseFollowStabilityVerification {
 public static void Run(Assembly assembly) {
  var profile=assembly.GetType("PoeBG.LocalPatchProfile",true);var schema=profile.GetField("CloseFollowStabilitySchema");
  var step=profile.GetMethod("CloseFollowStepLength");var hold=profile.GetMethod("CloseFollowHoldAllowed");var relevant=profile.GetMethod("CloseFollowRouteStillRelevant");
  if(schema==null||(string)schema.GetRawConstantValue()!="1"||step==null||hold==null||relevant==null)throw new Exception("Missing bounded close-follow stability maintenance");
  int checks=0;Action<bool> need=ok=>{if(!ok)throw new Exception("Close-follow path stability regression");checks++;};
  Func<float,float,float> distance=(available,limit)=>(float)step.Invoke(null,new object[]{available,limit});
  need(distance(500,80)==80);need(distance(32,80)==32);need(distance(0,80)==0);need(distance(-1,80)==0);
  need(distance(float.NaN,80)==0);need(distance(float.PositiveInfinity,80)==0);need(distance(80,float.NaN)==0);
  Func<bool,float,float,bool> staying=(on,shift,gap)=>(bool)hold.Invoke(null,new object[]{on,shift,gap});
  need(staying(true,2,8));need(!staying(false,0,3));need(!staying(true,2.1f,3));need(!staying(true,0,8.1f));need(!staying(true,float.NaN,3));
  Func<float,float,float,float,bool> route=(a,b,c,d)=>(bool)relevant.Invoke(null,new object[]{a,b,c,d});
  need(route(10,0,5,1));need(!route(10,0,0,10));need(!route(10,0,-10,0));need(!route(0,0,1,0));need(!route(float.NaN,0,1,0));
  Console.WriteLine("PASS: "+checks+" bounded-step, arrival-hold and turn-relevance checks; no game memory or input invoked.");
 }
}
