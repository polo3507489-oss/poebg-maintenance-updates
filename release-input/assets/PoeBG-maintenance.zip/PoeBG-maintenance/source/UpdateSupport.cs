using System;
using System.IO;
using System.Diagnostics;
public static class PoeBGUpdateSupport {
    static int checkedFriends;
    static void CheckFriends() {
        if(System.Threading.Interlocked.Exchange(ref checkedFriends,1)!=0 || Environment.GetEnvironmentVariable("POEBG_CUSTOM_UPDATE_CHECKED")=="1")return;
        try {
            string root=AppDomain.CurrentDomain.BaseDirectory;
            string updater=Path.Combine(root,"PoeBGFriendsUpdater.exe");
            if(File.Exists(updater))Process.Start(new ProcessStartInfo(updater,"--check"){WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden});
        } catch { }
    }
    public static string Filter(string response,string command,string parameter) {
        if(command!="GetVerInfo" || parameter!="AppInfo") return response;
        CheckFriends();
        if(string.IsNullOrEmpty(response)||response.Split('@').Length<2)return response;
        bool skip=Environment.GetEnvironmentVariable("POEBG_SKIP_UPDATE_ONCE")=="1";
        try {
            string marker=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PoeBG-maintenance","blocked-version.txt");
            if(File.Exists(marker) && response.Split('@')[0].Trim()==File.ReadAllText(marker).Trim())skip=true;
            if(skip) {
                string main=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PoeBG.exe");
                var fields=response.Split('@');
                Version current;
                if(File.Exists(main)&&Version.TryParse(FileVersionInfo.GetVersionInfo(main).FileVersion,out current)) {
                    fields[0]=current.ToString();
                    return string.Join("@",fields);
                }
                // An unknown current version must not be reported as a failed connection.
                fields[0]="0.0.0.0";
                return string.Join("@",fields);
            }
        } catch { }
        return response;
    }
}

