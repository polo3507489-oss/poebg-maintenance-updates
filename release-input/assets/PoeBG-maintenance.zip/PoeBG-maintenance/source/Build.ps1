$ErrorActionPreference = 'Stop'
if (Get-Process PoeBG -ErrorAction SilentlyContinue) { throw 'Close PoeBG before rebuilding maintenance components.' }
$maintenance = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$appRoot = [IO.Path]::GetFullPath((Join-Path $maintenance '..'))
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'The .NET Framework C# compiler is unavailable.' }
function Compile([string[]]$arguments) {
    & $compiler /nologo /optimize+ @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
}
Compile @('/target:library',"/out:$maintenance\PoeBG.MemoryReadSupport.dll",(Join-Path $PSScriptRoot 'MemoryReadSupport.cs'))
Compile @('/target:library',"/out:$maintenance\PoeBG.UpdateSupport.dll",(Join-Path $PSScriptRoot 'UpdateSupport.cs'))
Compile @('/r:System.Windows.Forms.dll','/r:System.Drawing.dll',"/r:$maintenance\dnlib.dll","/r:$maintenance\PoeBG.MemoryReadSupport.dll","/r:$maintenance\PoeBG.UpdateSupport.dll","/out:$maintenance\Patch.exe",(Join-Path $PSScriptRoot 'Patch.cs'),(Join-Path $PSScriptRoot 'CharacterScanPatch.cs'),(Join-Path $PSScriptRoot 'FontSafetyPatch.cs'),(Join-Path $PSScriptRoot 'GameplayFixes.cs'),(Join-Path $PSScriptRoot 'ServiceFixes.cs'),(Join-Path $PSScriptRoot 'DataToolFixes.cs'),(Join-Path $PSScriptRoot 'UpdateExitFixes.cs'),(Join-Path $PSScriptRoot 'LegionRadarPatch.cs'),(Join-Path $PSScriptRoot 'LegionRadarTemplate.cs'),(Join-Path $PSScriptRoot 'LegionRadarOptionsPatch.cs'),(Join-Path $PSScriptRoot 'LegionRadarOptionsTemplate.cs'),(Join-Path $PSScriptRoot 'CloseFollowOptionsPatch.cs'),(Join-Path $PSScriptRoot 'CloseFollowOptionsTemplate.cs'),(Join-Path $PSScriptRoot 'CloseFollowPatch.cs'),(Join-Path $PSScriptRoot 'CloseFollowTemplate.cs'),(Join-Path $PSScriptRoot 'FollowMoveInputPatch.cs'),(Join-Path $PSScriptRoot 'FollowMoveInputTemplate.cs'))
Compile @('/r:System.Windows.Forms.dll','/r:System.Drawing.dll',"/out:$maintenance\Verify.exe",(Join-Path $PSScriptRoot 'Verify.cs'),(Join-Path $PSScriptRoot 'LegionRadarVerification.cs'),(Join-Path $PSScriptRoot 'LegionRadarOptionsVerification.cs'),(Join-Path $PSScriptRoot 'CloseFollowOptionsVerification.cs'),(Join-Path $PSScriptRoot 'CloseFollowVerification.cs'),(Join-Path $PSScriptRoot 'CloseFollowLayoutVerification.cs'),(Join-Path $PSScriptRoot 'FollowMoveInputVerification.cs'),(Join-Path $PSScriptRoot 'CloseFollowStabilityVerification.cs'),(Join-Path $PSScriptRoot 'CloseFollowTerrainVerification.cs'))
Compile @('/target:winexe','/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll',"/out:$appRoot\PoeBGUpdateGuard.exe",(Join-Path $PSScriptRoot 'UpdateGuard.cs'))
Copy-Item -LiteralPath "$maintenance\PoeBG.MemoryReadSupport.dll" -Destination "$appRoot\Lib\PoeBG.MemoryReadSupport.dll" -Force
Copy-Item -LiteralPath "$maintenance\PoeBG.UpdateSupport.dll" -Destination "$appRoot\Lib\PoeBG.UpdateSupport.dll" -Force
Compile @('/target:winexe','/main:FriendsUpdater','/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.Web.Extensions.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll',"/resource:$PSScriptRoot\ReleasePublicKey.xml,ReleasePublicKey","/out:$appRoot\PoeBGFriendsUpdater.exe",(Join-Path $PSScriptRoot 'FriendsUpdater.cs'),(Join-Path $PSScriptRoot 'UpdateGuard.cs'))
Compile @('/target:winexe','/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll',"/out:$appRoot\PoeBG-更新紀錄收集.exe",(Join-Path $PSScriptRoot 'UpdateLogCollector.cs'))
'Maintenance components rebuilt; GitHub release updater and diagnostic collector included.'



