using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

public static class CloseFollowLayoutVerification {
 public static void Run(Form form) {
  var field=form.GetType().BaseType.GetField("CloseFollowOptionBox",BindingFlags.Instance|BindingFlags.Public);
  if(field==null)throw new Exception("Close-follow checkbox field missing");
  int checks=0;
  Action check=()=>{
   Application.DoEvents();
   var box=field.GetValue(form) as CheckBox;
   if(box==null||box.Parent==null)throw new Exception("Close-follow checkbox missing");
   if(box.ForeColor.ToArgb()!=Color.Yellow.ToArgb()||box.BackColor.GetBrightness()>.4f)throw new Exception("Close-follow checkbox contrast regression");
   if(!box.Parent.ClientRectangle.Contains(box.Bounds))throw new Exception("Close-follow checkbox clipped");
   Rectangle bounds=box.Bounds;bounds.Inflate(-1,-1);
   foreach(Control control in box.Parent.Controls){
    if(control==box)continue;
    Rectangle occupied=control.Bounds;occupied.Inflate(-1,-1);
    if(bounds.IntersectsWith(occupied))throw new Exception("Close-follow checkbox overlap: "+control.Name);
   }
   checks++;
  };
  check();form.Scale(new SizeF(1.25f,1.25f));check();form.Scale(new SizeF(1.2f,1.2f));check();
  Console.WriteLine("PASS: "+checks+" close-follow checkbox layout/contrast checks at original, 125% and 150% size; original Load/Shown handlers suppressed.");
 }
}
