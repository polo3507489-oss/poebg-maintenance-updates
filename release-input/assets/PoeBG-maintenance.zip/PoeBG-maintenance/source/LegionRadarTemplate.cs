using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
namespace LegionRadarTemplate {
 public struct VectorKey { }
 public class Marker { public uint ID {get;set;} public string Metapath {get;set;} }
 public class Entity { public long EntityAddress {get;set;} public string MetaPath {get;set;} }
 public static class Profile {
  public static bool IsLegionRadarPath(string meta) {return meta!=null&&(meta=="Metadata/Terrain/Leagues/Legion/Objects/LegionInitiator"||meta.StartsWith("Metadata/Monsters/LegionLeague/",StringComparison.Ordinal)||meta.StartsWith("Metadata/Chests/LegionChests/",StringComparison.Ordinal));}
  public static bool LegionRadarShouldShow(string meta,Dictionary<string,int> states) {
   if(!IsLegionRadarPath(meta))return true;
   if(meta=="Metadata/Terrain/Leagues/Legion/Objects/LegionInitiator"||states==null)return false;
   int present,breakout,activated;
   if(!states.TryGetValue("present",out present)||present!=1)return false;
   states.TryGetValue("breakout",out breakout);states.TryGetValue("activated",out activated);
   return breakout!=1||activated!=0;
  }
 }
 public class Owner {
  public ConcurrentDictionary<uint,Entity> Active,Other;
  public ConcurrentDictionary<VectorKey,Marker> Cached;
  public Dictionary<string,int> StateReader(long address,int index){throw new NotSupportedException();}
  private Dictionary<string,int> LegionRadarReadStates(uint id,string meta) {
   try {
    Entity entity=null;
    if(Active==null||!Active.TryGetValue(id,out entity))if(Other==null||!Other.TryGetValue(id,out entity))return null;
    if(entity==null||entity.EntityAddress<=0||entity.MetaPath!=meta)return null;
    return StateReader(entity.EntityAddress,-1);
   }catch(Exception){return null;}
  }
  private void LegionRadarFilterOne(ConcurrentDictionary<VectorKey,Marker> markers) {
   if(markers==null)return;
   foreach(var pair in markers.ToArray()) {
    var marker=pair.Value;
    if(marker==null||!Profile.IsLegionRadarPath(marker.Metapath))continue;
    var states=LegionRadarReadStates(marker.ID,marker.Metapath);
    if(!Profile.LegionRadarShouldShow(marker.Metapath,states)) {Marker removed;markers.TryRemove(pair.Key,out removed);}
   }
  }
  public ConcurrentDictionary<VectorKey,Marker> FilterLegionRadar(ConcurrentDictionary<VectorKey,Marker> markers) {LegionRadarFilterOne(Cached);LegionRadarFilterOne(markers);return markers;}
 }
}
