using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

class UpdateGuard {
    const string Maintenance = "PoeBG-maintenance";
    static string log;
    static string upstreamVersion;
    static void Report(string message) {
        try { if(log!=null) File.AppendAllText(log, DateTime.Now.ToString("s")+" "+message+Environment.NewLine); } catch { }
        Console.WriteLine(message);
    }
    static string Within(string root, string relative) {
        if (Path.IsPathRooted(relative) || relative.IndexOf(':') >= 0) throw new Exception("Invalid update path");
        string full = Path.GetFullPath(Path.Combine(root,relative));
        if (!full.StartsWith(Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase)) throw new Exception("Update path escapes staging directory");
        return full;
    }
    static void RunTool(string executable, string arguments, string cwd, int seconds) {
        var start = new ProcessStartInfo(executable,arguments) {
            WorkingDirectory=cwd,UseShellExecute=false,CreateNoWindow=true,
            RedirectStandardOutput=true,RedirectStandardError=true,WindowStyle=ProcessWindowStyle.Hidden
        };
        using(var process=Process.Start(start)) {
            var stdout=process.StandardOutput.ReadToEndAsync();
            var stderr=process.StandardError.ReadToEndAsync();
            if(!process.WaitForExit(seconds*1000)) {
                try { process.Kill(); } catch { }
                throw new Exception("Update verification timed out; current version retained");
            }
            Task.WaitAll(stdout,stderr);
            File.AppendAllText(log,stdout.Result+stderr.Result);
            if(process.ExitCode != 0) throw new Exception(Path.GetFileName(executable)+" failed; current version retained. See update.log");
        }
    }
    static string Quote(string path) {
        if(path.IndexOf('"')>=0 || path.EndsWith("\\")) throw new Exception("Invalid argument path");
        return "\""+path+"\"";
    }
    static void Extract(string archive,string destination) {
        long total=0;
        var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using(var zip=ZipFile.OpenRead(archive)) {
            if(zip.Entries.Count>20000) throw new Exception("Update archive contains too many files");
            foreach(var entry in zip.Entries) {
                string relative=entry.FullName.Replace('/',Path.DirectorySeparatorChar);
                string target=Within(destination,relative);
                if(!paths.Add(target)) throw new Exception("Duplicate update path");
                total=checked(total+entry.Length);
                if(total>512L*1024*1024) throw new Exception("Update archive exceeds size limit");
                if(((entry.ExternalAttributes>>16)&0xF000)==0xA000 || (entry.ExternalAttributes&0x400)!=0) throw new Exception("Update links are unsupported");
                if(string.IsNullOrEmpty(entry.Name)) { Directory.CreateDirectory(target); continue; }
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                entry.ExtractToFile(target,false);
            }
        }
    }
    static void WaitForExit(string target) {
        for(int n=0;n<120;n++) {
            bool running=false;
            foreach(var process in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(target)))using(process) {
                try {if(string.Equals(process.MainModule.FileName,target,StringComparison.OrdinalIgnoreCase))running=true;}
                catch {running=true;}
            }
            if(running){Thread.Sleep(250);continue;}
            try { using(var file=File.Open(target,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) { return; } }
            catch(IOException) { Thread.Sleep(250); }
        }
        throw new Exception("PoeBG is still running; update was not installed");
    }
    static void ReplaceFile(string source,string destination) {
        string pending=destination+".poebg-pending-"+Guid.NewGuid().ToString("N");
        try {
            File.Copy(source,pending,false);
            if(File.Exists(destination))File.Replace(pending,destination,null);
            else File.Move(pending,destination);
        } finally {
            try {if(File.Exists(pending))File.Delete(pending);}catch(Exception ex){Report("Retaining temporary update file: "+ex.Message);}
        }
    }
    static void CheckTarget(string appRoot,string path) {
        string current=Path.GetDirectoryName(path);
        while(current.Length>=appRoot.Length) {
            if(Directory.Exists(current) && (File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0) throw new Exception("Update destination contains a directory link");
            if(string.Equals(current,appRoot,StringComparison.OrdinalIgnoreCase)) break;
            current=Path.GetDirectoryName(current);
        }
        if(File.Exists(path) && (File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0) throw new Exception("Update destination contains a file link");
    }
    static void Install(string appRoot,string stage,List<string> files,string rollback) {
        var touched=new List<string>();
        var existed=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        // The executable is copied last, after every new payload file is available.
        files=files.OrderBy(p=>string.Equals(p,"PoeBG.exe",StringComparison.OrdinalIgnoreCase)?1:0).ToList();
        foreach(string relative in files) {
            string destination=Within(appRoot,relative);
            CheckTarget(appRoot,destination);
            if(File.Exists(destination)) {
                string backup=Within(rollback,relative);
                Directory.CreateDirectory(Path.GetDirectoryName(backup));
                File.Copy(destination,backup,false); existed.Add(relative);
            }
        }
        try {
            foreach(string relative in files) {
                string destination=Within(appRoot,relative);
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                ReplaceFile(Within(stage,relative),destination);
                touched.Add(relative);
            }
        } catch {
            var errors=new List<string>();
            foreach(string relative in touched.AsEnumerable().Reverse()) {
                try {
                    string destination=Within(appRoot,relative);
                    if(existed.Contains(relative)) ReplaceFile(Within(rollback,relative),destination);
                    else if(File.Exists(destination)) File.Delete(destination);
                } catch(Exception ex) { errors.Add(relative+": "+ex.Message); }
            }
            if(errors.Count>0) throw new Exception("Rollback needs attention. Backups: "+rollback+"; "+string.Join("; ",errors));
            throw;
        }
    }
    static void Update(string appRoot,bool test) {
        string support=Path.Combine(Path.GetFullPath(appRoot),Maintenance);Directory.CreateDirectory(support);
        using(var updateLock=new FileStream(Path.Combine(support,".update-lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))UpdateCore(appRoot,test);
    }
    static void UpdateCore(string appRoot,bool test) {
        appRoot=Path.GetFullPath(appRoot).TrimEnd(Path.DirectorySeparatorChar);
        string support=Within(appRoot,Maintenance);
        Directory.CreateDirectory(support);
        log=Within(support,"update.log");
        string archive=Within(appRoot,"PBUpdate.zip");
        string current=Within(appRoot,"PoeBG.exe");
        if(!File.Exists(archive)||!File.Exists(current)) throw new Exception("Missing PBUpdate.zip or PoeBG.exe");
        if(!test) WaitForExit(current);
        string transaction=Within(support,"transactions\\"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N"));
        string stage=Within(transaction,"stage"), rollback=Within(transaction,"rollback");
        Directory.CreateDirectory(stage); Directory.CreateDirectory(rollback);
        Report("Extracting update into "+transaction);
        Extract(archive,stage);
        if(!File.Exists(Within(stage,"PoeBG.exe"))) {
            var roots=Directory.GetDirectories(stage);
            if(roots.Length!=1 || !File.Exists(Within(roots[0],"PoeBG.exe"))) throw new Exception("Unrecognized update archive layout");
            stage=roots[0];
        }
        var payload=Directory.GetFiles(stage,"*",SearchOption.AllDirectories).Select(p=>p.Substring(stage.Length+1)).ToList();
        if(payload.Any(p=>p.Split(Path.DirectorySeparatorChar)[0].Equals(Maintenance,StringComparison.OrdinalIgnoreCase) || p.Equals("PoeBGUpdateGuard.exe",StringComparison.OrdinalIgnoreCase) || p.Equals("PoeBGFriendsUpdater.exe",StringComparison.OrdinalIgnoreCase) || p.Equals("Lib\\PoeBG.UpdateSupport.dll",StringComparison.OrdinalIgnoreCase) || p.Equals("Lib\\PoeBG.MemoryReadSupport.dll",StringComparison.OrdinalIgnoreCase))) throw new Exception("Update tries to overwrite local update guard");
        payload=payload.Where(p=>!(p.StartsWith("Role\\",StringComparison.OrdinalIgnoreCase)||p.StartsWith("Log\\",StringComparison.OrdinalIgnoreCase))||!File.Exists(Within(appRoot,p))).ToList();
        string lib=Within(appRoot,"Lib");
        if(Directory.Exists(lib)) foreach(string file in Directory.GetFiles(lib,"*.dll")) {
            string destination=Within(stage,"Lib\\"+Path.GetFileName(file));
            Directory.CreateDirectory(Path.GetDirectoryName(destination));
            if(!File.Exists(destination)) File.Copy(file,destination);
        }
        string webViewLoader=Within(appRoot,"WebView2Loader.dll");
        if(File.Exists(webViewLoader)&&!File.Exists(Within(stage,"WebView2Loader.dll")))File.Copy(webViewLoader,Within(stage,"WebView2Loader.dll"));
        string input=Within(stage,"PoeBG.exe");
        string upstream=Within(transaction,"upstream.exe"); File.Move(input,upstream);
        upstreamVersion=FileVersionInfo.GetVersionInfo(upstream).FileVersion;
        Report("Decrypting and checking the new version; current files are unchanged");
        RunTool(Within(support,"reactor\\NETReactorSlayer.CLI.exe"),Quote(upstream)+" --dont-rename True --preserve-all True --no-pause True",stage,600);
        string decrypted=Within(transaction,"upstream_Slayed.exe");
        if(!File.Exists(decrypted)) throw new Exception("Decrypted update was not produced");
        Report("Applying compatible license changes and resource loader repair");
        RunTool(Within(support,"Patch.exe"),Quote(decrypted)+" "+Quote(input),stage,60);
        Report("Checking startup resource loading, window construction and license methods");
        RunTool(Within(support,"Verify.exe"),Quote(input)+" --ui "+Quote(Within(transaction,"startup.png")),stage,60);
        if(!test) WaitForExit(current);
        Report("Verification passed; installing with rollback backups");
        Install(appRoot,stage,payload,rollback);
        string blocked=Within(support,"blocked-version.txt");
        try {if(File.Exists(blocked)) File.Delete(blocked);} catch(Exception ex) {Report("Retaining previous blocked-version marker: "+ex.Message);}
        try { File.Move(archive,Within(transaction,"installed-update.zip")); }
        catch(Exception ex) { Report("Update installed; retaining downloaded archive: "+ex.Message); }
        Report("Update installed. Rollback backups: "+rollback);
    }
    static void Restart(string root,bool skip) {
        if(skip) Environment.SetEnvironmentVariable("POEBG_SKIP_UPDATE_ONCE","1");
        Process.Start(new ProcessStartInfo(Within(root,"PoeBG.exe")) {WorkingDirectory=root,UseShellExecute=true});
    }
    [STAThread]
    static void Main(string[] args) {
        bool test=args.Length==2 && args[0]=="--test-update";
        string root=test?args[1]:AppDomain.CurrentDomain.BaseDirectory;
        if(test) {
            try { Update(root,true); } catch(Exception ex) { Console.Error.WriteLine(ex.Message); Environment.ExitCode=1; }
            return;
        }
        Application.EnableVisualStyles();
        using(var form=new Form {Text="PoeBG 更新驗證",Width=490,Height=150,StartPosition=FormStartPosition.CenterScreen,FormBorderStyle=FormBorderStyle.FixedDialog,ControlBox=false}) {
            var label=new Label {Left=20,Top=20,Width=440,Height=45,Text="正在處理新版並驗證啟動與授權設定。\n可能需要數分鐘，請勿關閉電腦。"};
            form.Controls.Add(label);
            form.Controls.Add(new ProgressBar {Left=20,Top=72,Width=440,Style=ProgressBarStyle.Marquee});
            form.Shown+=async (s,e)=>{
                bool skip=false;
                try { await Task.Run(()=>Update(root,false)); }
                catch(Exception ex) {
                    if(log!=null) Report("FAILED: "+ex.Message);
                    if(!string.IsNullOrEmpty(upstreamVersion)) {
                        try {File.WriteAllText(Path.Combine(root,Maintenance,"blocked-version.txt"),upstreamVersion);} catch {skip=true;}
                    } else skip=true;
                    MessageBox.Show("更新未安裝，保留目前版本。\n"+ex.Message+"\n\n診斷記錄："+Path.Combine(root,Maintenance,"update.log"),"PoeBG 更新驗證",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }
                finally {
                    try { Restart(root,skip); } catch(Exception ex) { MessageBox.Show("請手動重新啟動 PoeBG。\n"+ex.Message); }
                    form.Close();
                }
            };
            Application.Run(form);
        }
    }
}


