using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

public static class GameplayFixes {
    // Keep the original cache, prefixes, keypad mapping, and error handling.
    // Only treat the last '+' segment as the key and all preceding segments as modifiers.
    public static void Apply(ModuleDef module) {
        var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");
        var parser=main.Methods.Single(m=>m.HasBody&&m.MethodSig.RetType.FullName=="System.Windows.Forms.Keys"&&m.MethodSig.Params.Count==1&&m.MethodSig.Params[0].FullName=="System.String"&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="Mouse"));
        var il=parser.Body.Instructions;var import=new Importer(module);
        int first=-1,second=-1;
        for(int n=0;n+3<il.Count;n++) {
            if(il[n].IsLdloc()&&il[n+1].IsLdcI4()&&il[n+2].OpCode==OpCodes.Ldelem_Ref&&il[n+3].IsStloc()) {
                if(il[n+1].GetLdcI4Value()==0) {if(first>=0)throw new Exception("Ambiguous hotkey modifier assignment");first=n;}
                if(il[n+1].GetLdcI4Value()==1) {if(second>=0)throw new Exception("Ambiguous hotkey key assignment");second=n;}
            }
        }
        if(first<0||second!=first+4)throw new Exception("Unsupported hotkey parser shape");
        var array=il[first].GetLocal(parser.Body.Variables);
        if(array==null||array.Type.FullName!="System.String[]"||il[second].GetLocal(parser.Body.Variables)!=array)throw new Exception("Unexpected hotkey split array");
        var join=import.Import(typeof(string).GetMethod("Join",new[]{typeof(string),typeof(string[]),typeof(int),typeof(int)}));
        var replace=import.Import(typeof(Regex).GetMethod("Replace",new[]{typeof(string),typeof(string),typeof(string)}));
        // Patch the second segment first, preserving existing branch/EH instruction objects.
        il[second+1].OpCode=OpCodes.Ldloc;il[second+1].Operand=array;
        var suffix=new[]{Instruction.Create(OpCodes.Ldlen),Instruction.Create(OpCodes.Conv_I4),Instruction.Create(OpCodes.Ldc_I4_1),Instruction.Create(OpCodes.Sub)};
        for(int n=0;n<suffix.Length;n++)il.Insert(second+2+n,suffix[n]);
        il[first].OpCode=OpCodes.Ldstr;il[first].Operand=",";
        il[first+1].OpCode=OpCodes.Ldloc;il[first+1].Operand=array;
        il[first+2].OpCode=OpCodes.Ldc_I4_0;il[first+2].Operand=null;
        var prefix=new[]{Instruction.Create(OpCodes.Ldloc,array),Instruction.Create(OpCodes.Ldlen),Instruction.Create(OpCodes.Conv_I4),Instruction.Create(OpCodes.Ldc_I4_1),Instruction.Create(OpCodes.Sub),Instruction.Create(OpCodes.Call,join),Instruction.Create(OpCodes.Ldstr,@"(?i)\bCtrl\b"),Instruction.Create(OpCodes.Ldstr,"Control"),Instruction.Create(OpCodes.Call,replace)};
        for(int n=0;n<prefix.Length;n++)il.Insert(first+3+n,prefix[n]);
        parser.Body.SimplifyBranches();
        GuardProfileDelete(module,main);
    }
    static void GuardProfileDelete(ModuleDef module,TypeDef main) {
        var handler=main.Methods.Single(m=>m.HasBody&&m.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).Name=="get_DeleteProfileConfirm"));
        var names=handler.Body.Instructions.Select(i=>i.Operand as IField).Where(f=>f!=null&&f.FieldSig!=null&&f.FieldSig.Type.FullName=="System.Windows.Forms.ComboBox").Select(f=>f.ResolveFieldDef()).Distinct().ToArray();
        if(names.Length!=1)throw new Exception("Unexpected profile deletion control");
        var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
        if(profile.Methods.Any(m=>m.Name=="IsValidProfileName"))throw new Exception("Profile name guard already exists");
        var import=new Importer(module);
        var guard=new MethodDefUser("IsValidProfileName",MethodSig.CreateStatic(module.CorLibTypes.Boolean,module.CorLibTypes.String),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Public|MethodAttributes.Static|MethodAttributes.HideBySig);
        guard.Body=new CilBody {InitLocals=true};var text=new Local(module.CorLibTypes.String);guard.Body.Variables.Add(text);profile.Methods.Add(guard);
        var bad=Instruction.Create(OpCodes.Ldc_I4_0);
        var code=new List<Instruction> {
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Call,import.Import(typeof(string).GetMethod("IsNullOrWhiteSpace"))),Instruction.Create(OpCodes.Brtrue,bad),
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Callvirt,import.Import(typeof(string).GetMethod("Trim",Type.EmptyTypes))),Instruction.Create(OpCodes.Stloc,text)
        };
        foreach(string value in new[]{".",".."})code.AddRange(new[]{Instruction.Create(OpCodes.Ldloc,text),Instruction.Create(OpCodes.Ldstr,value),Instruction.Create(OpCodes.Call,import.Import(typeof(string).GetMethod("op_Equality",new[]{typeof(string),typeof(string)}))),Instruction.Create(OpCodes.Brtrue,bad)});
        code.AddRange(new[]{Instruction.Create(OpCodes.Ldloc,text),Instruction.Create(OpCodes.Call,import.Import(typeof(Path).GetMethod("GetInvalidFileNameChars"))),Instruction.Create(OpCodes.Callvirt,import.Import(typeof(string).GetMethod("IndexOfAny",new[]{typeof(char[])}))),Instruction.Create(OpCodes.Ldc_I4_0),Instruction.Create(OpCodes.Bge,bad)});
        foreach(string slash in new[]{"/","\\"})code.AddRange(new[]{Instruction.Create(OpCodes.Ldloc,text),Instruction.Create(OpCodes.Ldstr,slash),Instruction.Create(OpCodes.Callvirt,import.Import(typeof(string).GetMethod("Contains",new[]{typeof(string)}))),Instruction.Create(OpCodes.Brtrue,bad)});
        code.AddRange(new[]{Instruction.Create(OpCodes.Ldc_I4_1),Instruction.Create(OpCodes.Ret),bad,Instruction.Create(OpCodes.Ret)});
        foreach(var instruction in code)guard.Body.Instructions.Add(instruction);
        var original=handler.Body.Instructions[0];
        var getter=handler.Body.Instructions.Select(i=>i.Operand as IMethod).First(m=>m!=null&&m.MethodSig!=null&&m.Name=="get_Text"&&m.MethodSig.RetType.FullName=="System.String");
        var prefix=new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,names[0]),Instruction.Create(OpCodes.Callvirt,getter),Instruction.Create(OpCodes.Call,guard),Instruction.Create(OpCodes.Brtrue,original),Instruction.Create(OpCodes.Ret)};
        for(int n=0;n<prefix.Length;n++)handler.Body.Instructions.Insert(n,prefix[n]);
        handler.Body.SimplifyBranches();
    }
}

