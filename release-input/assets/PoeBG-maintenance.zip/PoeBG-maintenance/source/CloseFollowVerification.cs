using System;
using System.Reflection;

public static class CloseFollowVerification {
 public static void Run(Assembly assembly) {
  var profile=assembly.GetType("PoeBG.LocalPatchProfile",true);
  var schema=profile.GetField("CloseFollowSchema",BindingFlags.Public|BindingFlags.Static);
  if(schema==null||(string)schema.GetRawConstantValue()!="1")throw new Exception("Missing close-follow maintenance profile");
  var delay=profile.GetMethod("CloseFollowLoopDelay");var move=profile.GetMethod("CloseFollowShouldMove");
  var stuck=profile.GetMethod("CloseFollowStuckLimit");var repath=profile.GetMethod("CloseFollowRepathInterval");
  if(delay==null||move==null||stuck==null||repath==null)throw new Exception("Missing close-follow control helpers");
  int checks=0;Action<bool> need=ok=>{if(!ok)throw new Exception("Close-follow control regression");checks++;};
  Func<bool,bool,int,int> loop=(enabled,following,original)=>(int)delay.Invoke(null,new object[]{enabled,following,original});
  Func<bool,float,bool> chasing=(active,distance)=>(bool)move.Invoke(null,new object[]{active,distance});
  Func<bool,int,int> limit=(enabled,original)=>(int)stuck.Invoke(null,new object[]{enabled,original});
  Func<bool,long,int> refresh=(enabled,cost)=>(int)repath.Invoke(null,new object[]{enabled,cost});
  need(loop(false,true,100)==100);need(loop(true,false,200)==200);need(loop(true,true,100)==40);
  need(!chasing(false,6f));need(chasing(false,6.1f));need(!chasing(false,5f));
  need(chasing(true,5f));need(!chasing(true,3f));need(chasing(true,3.1f));
  need(!chasing(true,float.NaN));need(!chasing(true,float.PositiveInfinity));need(!chasing(false,-1f));
  need(limit(false,7)==7);need(limit(false,10)==10);need(limit(true,7)==18);need(limit(true,10)==25);
  need(refresh(false,30L)==500);need(refresh(true,30L)==120);need(refresh(true,600L)>=600);
  Console.WriteLine("PASS: "+checks+" close-follow cadence, stop/resume hysteresis, invalid-position, stuck-timing and route-refresh checks; no game input sent.");
 }
}
