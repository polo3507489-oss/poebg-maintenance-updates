using System;
using System.Linq;
using System.Diagnostics;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class CharacterScanPatch {
    static int Count(System.Collections.Generic.IEnumerable<Instruction> ins,int value){return ins.Count(i=>i.IsLdcI4()&&i.GetLdcI4Value()==value);}
    static void Marker(ModuleDef module,string name,string value) {
        var p=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
        var field=p.Fields.SingleOrDefault(f=>f.Name==name);
        if(field==null){field=new FieldDefUser(name,new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);p.Fields.Add(field);}
        field.Constant=new ConstantUser(value);
    }
    static IField FindAssignment(MethodDef method,string type,int expectedValue,int otherValue) {
        var ins=method.Body.Instructions;var found=new System.Collections.Generic.List<IField>();int start=0;
        for(int n=0;n<ins.Count;n++)if(ins[n].OpCode==OpCodes.Stfld||ins[n].OpCode==OpCodes.Stsfld){
            var f=ins[n].Operand as IField;var segment=ins.Skip(start).Take(n-start);
            if(f!=null&&f.FieldSig.Type.FullName==type&&Count(segment,expectedValue)==2&&(otherValue<0||Count(segment,otherValue)==2))found.Add(f);
            start=n+1;
        }
        if(found.Count!=1)throw new Exception("Unrecognized character assignment for "+type+" / "+expectedValue);
        return found[0];
    }
    static void Assignment(MethodDef method,string fieldName,int oldValue,int newValue,int expected) {
        var ins=method.Body.Instructions;
        int end=Enumerable.Range(0,ins.Count).Single(i=>(ins[i].OpCode==OpCodes.Stfld||ins[i].OpCode==OpCodes.Stsfld)&&ins[i].Operand is IField&&((IField)ins[i].Operand).Name==fieldName);
        int start=end-1;while(start>=0&&ins[start].OpCode!=OpCodes.Stfld&&ins[start].OpCode!=OpCodes.Stsfld)start--;
        var hits=ins.Skip(start+1).Take(end-start-1).Where(i=>i.IsLdcI4()&&i.GetLdcI4Value()==oldValue).ToArray();
        if(hits.Length==0&&Count(ins.Skip(start+1).Take(end-start-1),newValue)==expected)return;
        if(hits.Length!=expected)throw new Exception("Unsupported character offset assignment: "+fieldName);
        foreach(var hit in hits){hit.OpCode=OpCodes.Ldc_I4;hit.Operand=newValue;}
    }
    public static MethodDef[] Apply(ModuleDef module) {
        var type=module.GetTypes().Single(t=>t.FullName=="dotNetMemoryScan");
        var method=type.Methods.Single(m=>m.HasBody && m.MethodSig.RetType.FullName=="System.IntPtr" &&
            m.MethodSig.Params.Count==4 && m.MethodSig.Params[0].FullName=="System.Diagnostics.Process" &&
            m.MethodSig.Params[1].FullName=="System.String" && m.MethodSig.Params[2].ElementType==ElementType.I4 &&
            m.MethodSig.Params[3].ElementType==ElementType.I4);
        var resolver=type.Methods.Single(m=>m.MethodSig.RetType.FullName=="System.Diagnostics.ProcessModule" &&
            m.MethodSig.Params.Count==2 && m.MethodSig.Params[0].FullName=="System.Diagnostics.Process" && m.MethodSig.Params[1].FullName=="System.String");
        var handle=type.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.FullName=="System.IntPtr");
        var pattern=type.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.FullName=="System.Byte[]");
        var mask=type.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.FullName=="System.String");
        var body=new CilBody();
        body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));body.Instructions.Add(Instruction.Create(OpCodes.Ldfld,handle));
        body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_1));body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_2));
        body.Instructions.Add(Instruction.Create(OpCodes.Call,resolver));
        body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));body.Instructions.Add(Instruction.Create(OpCodes.Ldfld,pattern));
        body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));body.Instructions.Add(Instruction.Create(OpCodes.Ldfld,mask));
        body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_3));body.Instructions.Add(Instruction.Create(OpCodes.Ldarg,method.Parameters[4]));
        body.Instructions.Add(Instruction.Create(OpCodes.Call,new Importer(module).Import(typeof(PoeBGMemoryReadSupport).GetMethod("Scan"))));
        body.Instructions.Add(Instruction.Create(OpCodes.Ret));method.Body=body;
        var game=module.GetTypes().Single(t=>t.FullName=="PoeBG.Scanner");
        var gameMethod=game.Methods.Single(m=>m.HasBody&&m.MethodSig.RetType.FullName=="System.IntPtr"&&m.MethodSig.Params.Count==0&&m.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).Name=="get_ModuleMemorySize"));
        var gameHandle=game.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.FullName=="System.IntPtr");
        var gameModule=game.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.FullName=="System.Diagnostics.ProcessModule");
        var gamePattern=game.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.FullName=="System.String");
        var gameStart=game.Fields.Single(f=>!f.IsStatic&&f.FieldSig.Type.ElementType==ElementType.I4);
        var gameBody=new CilBody();
        foreach(var field in new[]{gameHandle,gameModule,gamePattern,gameStart}){
            gameBody.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));gameBody.Instructions.Add(Instruction.Create(OpCodes.Ldfld,field));
        }
        gameBody.Instructions.Add(Instruction.Create(OpCodes.Call,new Importer(module).Import(typeof(PoeBGMemoryReadSupport).GetMethod("ScanText"))));
        gameBody.Instructions.Add(Instruction.Create(OpCodes.Ret));gameMethod.Body=gameBody;
        var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");
        var root=main.Methods.Single(m=>m.HasBody&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="48 83 EC ?? 48 8B F1 33 ED 48 39 2D ?? ?? ?? ?? 0F 85 ?? ?? ?? ??"));
        var rootHits=root.Body.Instructions.Where(i=>i.IsLdcI4()&&i.GetLdcI4Value()==136).ToArray();
        if(rootHits.Length==1){rootHits[0].OpCode=OpCodes.Ldc_I4;rootHits[0].Operand=144;}
        else if(rootHits.Length!=0||Count(root.Body.Instructions,144)!=2)throw new Exception("Unsupported POE1 root layout");
        var offsets=main.Methods.Single(m=>m.HasBody&&(Count(m.Body.Instructions,50080)==2||Count(m.Body.Instructions,51224)==2));
        bool old=Count(offsets.Body.Instructions,50080)==2;
        var player=FindAssignment(offsets,"System.Int32[]",old?2416:2432,1496);
        var state=FindAssignment(offsets,"System.Int32[][]",old?2408:2424,-1);
        var network=FindAssignment(offsets,"System.Int32[]",old?50080:51224,192);
        // Layout verified against the current Taiwan POE1 build; unfamiliar layouts fail closed.
        Assignment(offsets,player.Name,2416,2432,2);
        Assignment(offsets,state.Name,2408,2424,2);
        Assignment(offsets,network.Name,50080,51224,2);
        Marker(module,"OffsetInitMethod",offsets.Name);Marker(module,"PlayerChainField",player.Name);Marker(module,"StatusChainField",state.Name);Marker(module,"NetworkStateField",network.Name);
        var fields=root.Body.Instructions.Select(i=>i.Operand as IField).Where(f=>f!=null&&f.FieldSig!=null&&f.DeclaringType.FullName==main.FullName).ToArray();
        Marker(module,"ModeField",fields.Where(f=>f.FieldSig.Type.ElementType==ElementType.Boolean).Select(f=>f.Name.String).Distinct().Single());
        Marker(module,"ProcessHandleField",fields.Where(f=>f.FieldSig.Type.FullName=="System.IntPtr").Select(f=>f.Name.String).Distinct().Single());
        var calls=root.Body.Instructions.Select(i=>i.Operand as IMethod).Where(m=>m!=null&&m.MethodSig!=null&&m.DeclaringType.FullName==main.FullName).ToArray();
        Marker(module,"IntReadMethod",calls.Single(m=>m.MethodSig.RetType.ElementType==ElementType.I4&&m.MethodSig.Params.Count==4).Name);
        Marker(module,"LongChainMethod",calls.Where(m=>m.MethodSig.RetType.ElementType==ElementType.I8&&m.MethodSig.Params.Count==2).Select(m=>m.Name.String).Distinct().Single());
        Marker(module,"PointerChainMethod",calls.Where(m=>m.MethodSig.RetType.ElementType==ElementType.I8&&m.MethodSig.Params.Count==3).Select(m=>m.Name.String).Distinct().Single());
        Marker(module,"StatusReadMethod",main.Methods.Single(m=>m.MethodSig.RetType.ElementType==ElementType.I4&&m.MethodSig.Params.Count==3&&m.MethodSig.Params[0].ElementType==ElementType.I8&&m.MethodSig.Params[1].FullName=="System.Int32[]").Name);
        return new[]{method,gameMethod,root,offsets};
    }
}

