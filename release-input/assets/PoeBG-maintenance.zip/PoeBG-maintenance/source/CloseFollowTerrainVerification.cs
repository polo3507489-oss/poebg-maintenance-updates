using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
public static class CloseFollowTerrainVerification {
 public static void Run(Assembly assembly) {
  var main=assembly.GetType("PoeBG.Main",true);var flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
  var solve=main.GetMethod("SolveRawCloseFollow",flags);var blocked=main.GetMethod("CloseFollowTileBlocked",flags);
  if(solve==null||blocked==null)throw new Exception("Missing private close-follow terrain solver");
  var vector=solve.GetParameters()[0].ParameterType;
  Func<int,int,object> point=(x,y)=>Activator.CreateInstance(vector,new object[]{x*10.875f,y*10.875f,0f});
  Func<object,string,float> coordinate=(p,name)=>(float)vector.GetField(name).GetValue(p);
  int checks=0;Action<bool> need=ok=>{if(!ok)throw new Exception("Close-follow synthetic terrain regression");checks++;};
  Func<byte[],int,int,object> owner=(terrain,width,height)=>{
   var obj=FormatterServices.GetUninitializedObject(main);
   foreach(var setting in new[]{new object[]{"CloseFollowSolverTerrain",terrain},new object[]{"CloseFollowSolverWidth",width},new object[]{"CloseFollowSolverHeight",height},new object[]{"CloseFollowSolverPitch",(width+1)/2}})main.GetField((string)setting[0],flags).SetValue(obj,setting[1]);
   return obj;
  };
  const int w=48,h=32,pitch=24;
  var open=Enumerable.Repeat((byte)0x11,pitch*h).ToArray();var clearOwner=owner(open,w,h);
  var clear=((IEnumerable)solve.Invoke(clearOwner,new[]{point(8,10),point(36,10),(object)0})).Cast<object>().ToArray();
  need(clear.Length>1);need(Math.Abs(coordinate(clear[clear.Length-1],"X")/10.875f-36)<=1.01f);
  var wall=(byte[])open.Clone();
  for(int y=0;y<h;y++)if(y!=23){int n=y*pitch+24/2;wall[n]=(byte)(wall[n]&0xF0);}
  var wallOwner=owner(wall,w,h);
  need((bool)blocked.Invoke(wallOwner,new object[]{wall,24,10}));need(!(bool)blocked.Invoke(wallOwner,new object[]{wall,24,23}));
  var detour=((IEnumerable)solve.Invoke(wallOwner,new[]{point(8,10),point(36,10),(object)1})).Cast<object>().ToArray();
  need(detour.Length>1);need(detour.Any(p=>Math.Abs(coordinate(p,"X")/10.875f-24)<.01f&&Math.Abs(coordinate(p,"Y")/10.875f-23)<.01f));
  foreach(var p in detour){int x=(int)Math.Round(coordinate(p,"X")/10.875f),y=(int)Math.Round(coordinate(p,"Y")/10.875f);need(!(bool)blocked.Invoke(wallOwner,new object[]{wall,x,y}));}
  var sealedTerrain=new byte[pitch*h];var sealedOwner=owner(sealedTerrain,w,h);
  var none=solve.Invoke(sealedOwner,new[]{point(8,10),point(36,10),(object)1}) as IEnumerable;
  need(none==null||!none.Cast<object>().Any());
  Console.WriteLine("PASS: "+checks+" real cloned terrain-solver checks on non-square open, wall-gap and blocked maps; synthetic memory only, no game read/input.");
 }
}
