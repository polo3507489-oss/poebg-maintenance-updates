using System;
using System.Collections.Generic;
using System.Reflection;

public static class LegionRadarVerification {
 public static void Run(Assembly assembly) {
  var profile=assembly.GetType("PoeBG.LocalPatchProfile",true);
  var schema=profile.GetField("LegionRadarSchema",BindingFlags.Public|BindingFlags.Static);
  if(schema==null||(string)schema.GetRawConstantValue()!="1")throw new Exception("Missing compatible Legion radar maintenance profile");
  var predicate=profile.GetMethod("LegionRadarShouldShow",BindingFlags.Public|BindingFlags.Static);
  if(predicate==null||predicate.ReturnType!=typeof(bool))throw new Exception("Missing Legion radar visibility predicate");
  string monster="Metadata/Monsters/LegionLeague/LegionTemplarGeneral", chest="Metadata/Chests/LegionChests/LegionChest";
  var absent=new Dictionary<string,int>{{"present",0}};
  var frozen=new Dictionary<string,int>{{"present",1},{"breakout",0},{"activated",0}};
  var transitioning=new Dictionary<string,int>{{"present",1},{"breakout",1},{"activated",0}};
  var active=new Dictionary<string,int>{{"present",1},{"breakout",1},{"activated",1}};
  int checks=0;
  Action<string,Dictionary<string,int>,bool> check=(path,state,expected)=>{
   bool actual=(bool)predicate.Invoke(null,new object[]{path,state});
   if(actual!=expected)throw new Exception("Legion visibility regression: "+path);
   checks++;
  };
  check("Metadata/Monsters/Other/Monster",null,true);
  check("Metadata/Monsters/LegionLeagueImpostor/Monster",null,true);
  check("Metadata/Terrain/Leagues/Legion/Objects/LegionInitiator",active,false);
  check(monster,null,false);check(monster,new Dictionary<string,int>(),false);
  check(monster,absent,false);check(monster,frozen,true);
  check(monster,transitioning,false);check(monster,active,true);
  check(chest,absent,false);check(chest,frozen,true);
  check(chest,active,true);check(chest,transitioning,false);
  check(monster,new Dictionary<string,int>{{"present",2}},false);
  // Each entity is evaluated independently; no shared activation flag can reveal B.
  check(monster,frozen,true);check(monster,absent,false);check(monster,active,true);
  Console.WriteLine("PASS: "+checks+" Legion radar visibility cases, including independent active/inactive encounters; no game memory read.");
 }
}
