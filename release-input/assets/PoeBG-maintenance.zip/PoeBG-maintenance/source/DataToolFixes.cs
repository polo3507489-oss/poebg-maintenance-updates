using System;
using System.IO;
using System.Linq;
using System.Diagnostics;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

// Applies only to the observed desktop-runtime check and process working directory.
public static class DataToolFixes {
    public static void Apply(ModuleDef module) {
        const string helperName="PoeBG.LocalEnvironmentSupport";
        if(module.GetTypes().Any(t=>t.FullName==helperName))throw new Exception("Environment fixes already applied");
        var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");
        var check=main.Methods.Single(m=>m.HasBody&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&((string)i.Operand).Contains("必要元件【.NET Desktop Runtime")));
        var il=check.Body.Instructions;
        var matches=Enumerable.Range(0,il.Count-8).Where(n=>
            il[n].Operand is IMethod&&((IMethod)il[n].Operand).FullName=="System.String System.IO.Path::GetFileName(System.String)"&&
            il[n+1].IsLdcI4()&&il[n+1].GetLdcI4Value()==0&&
            il[n+2].IsLdcI4()&&il[n+2].GetLdcI4Value()==1&&
            il[n+3].Operand is IMethod&&((IMethod)il[n+3].Operand).FullName=="System.String System.String::Substring(System.Int32,System.Int32)"&&
            il[n+4].Operand is IMethod&&((IMethod)il[n+4].Operand).FullName=="System.Int32 System.Convert::ToInt32(System.String)"&&
            il[n+5].IsLdcI4()&&il[n+5].GetLdcI4Value()==6&&
            il[n+6].OpCode==OpCodes.Clt&&il[n+7].IsLdcI4()&&il[n+7].GetLdcI4Value()==0&&il[n+8].OpCode==OpCodes.Ceq).ToArray();
        if(matches.Length!=1)throw new Exception("Unrecognized desktop runtime detection shape");
        var entry=module.EntryPoint;
        if(entry==null||!entry.HasBody)throw new Exception("Missing managed entry point");
        var importer=new Importer(module);
        var helper=new TypeDefUser("PoeBG","LocalEnvironmentSupport",module.CorLibTypes.Object.TypeDefOrRef){Attributes=TypeAttributes.Public|TypeAttributes.Abstract|TypeAttributes.Sealed};
        module.Types.Add(helper);
        var assemblyCheck=new MethodDefUser("HasDesktop8Assembly",MethodSig.CreateStatic(module.CorLibTypes.Boolean,module.CorLibTypes.String,module.CorLibTypes.String),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Private|MethodAttributes.Static);
        helper.Methods.Add(assemblyCheck);assemblyCheck.Body=new CilBody{InitLocals=true};
        var path=new Local(module.CorLibTypes.String);assemblyCheck.Body.Variables.Add(path);
        var noAssembly=Instruction.Create(OpCodes.Ldc_I4_0);
        foreach(var i in new[]{
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldarg_1),Instruction.Create(OpCodes.Call,importer.Import(typeof(Path).GetMethod("Combine",new[]{typeof(string),typeof(string)}))),Instruction.Create(OpCodes.Stloc,path),
            Instruction.Create(OpCodes.Ldloc,path),Instruction.Create(OpCodes.Call,importer.Import(typeof(File).GetMethod("Exists",new[]{typeof(string)}))),Instruction.Create(OpCodes.Brfalse,noAssembly),
            Instruction.Create(OpCodes.Ldloc,path),Instruction.Create(OpCodes.Call,importer.Import(typeof(FileVersionInfo).GetMethod("GetVersionInfo",new[]{typeof(string)}))),Instruction.Create(OpCodes.Callvirt,importer.Import(typeof(FileVersionInfo).GetProperty("FileMajorPart").GetGetMethod())),Instruction.Create(OpCodes.Ldc_I4_8),Instruction.Create(OpCodes.Ceq),Instruction.Create(OpCodes.Ret),noAssembly,Instruction.Create(OpCodes.Ret)
        })assemblyCheck.Body.Instructions.Add(i);
        var runtime=new MethodDefUser("IsDesktopRuntime8Folder",MethodSig.CreateStatic(module.CorLibTypes.Boolean,module.CorLibTypes.String),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Public|MethodAttributes.Static);
        helper.Methods.Add(runtime);runtime.Body=new CilBody{InitLocals=true};
        var version=new Local(importer.ImportAsTypeSig(typeof(Version)));runtime.Body.Variables.Add(version);
        var noRuntime=Instruction.Create(OpCodes.Ldc_I4_0);
        foreach(var i in new[]{
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Call,importer.Import(typeof(Path).GetMethod("GetFileName",new[]{typeof(string)}))),Instruction.Create(OpCodes.Ldloca,version),Instruction.Create(OpCodes.Call,importer.Import(typeof(Version).GetMethod("TryParse",new[]{typeof(string),typeof(Version).MakeByRefType()}))),Instruction.Create(OpCodes.Brfalse,noRuntime),
            Instruction.Create(OpCodes.Ldloc,version),Instruction.Create(OpCodes.Callvirt,importer.Import(typeof(Version).GetProperty("Major").GetGetMethod())),Instruction.Create(OpCodes.Ldc_I4_8),Instruction.Create(OpCodes.Bne_Un,noRuntime),
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldstr,"System.Windows.Forms.dll"),Instruction.Create(OpCodes.Call,assemblyCheck),Instruction.Create(OpCodes.Brfalse,noRuntime),
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldstr,"PresentationFramework.dll"),Instruction.Create(OpCodes.Call,assemblyCheck),Instruction.Create(OpCodes.Ret),noRuntime,Instruction.Create(OpCodes.Ret)
        })runtime.Body.Instructions.Add(i);
        int position=matches[0];il[position].OpCode=OpCodes.Call;il[position].Operand=runtime;
        for(int n=1;n<=8;n++){il[position+n].OpCode=OpCodes.Nop;il[position+n].Operand=null;}
        var cwd=new MethodDefUser("SetWorkingDirectory",MethodSig.CreateStatic(module.CorLibTypes.Void),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Public|MethodAttributes.Static);
        helper.Methods.Add(cwd);cwd.Body=new CilBody();
        cwd.Body.Instructions.Add(Instruction.Create(OpCodes.Call,importer.Import(typeof(AppDomain).GetProperty("CurrentDomain").GetGetMethod())));
        cwd.Body.Instructions.Add(Instruction.Create(OpCodes.Callvirt,importer.Import(typeof(AppDomain).GetProperty("BaseDirectory").GetGetMethod())));
        cwd.Body.Instructions.Add(Instruction.Create(OpCodes.Call,importer.Import(typeof(Directory).GetMethod("SetCurrentDirectory",new[]{typeof(string)}))));
        cwd.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));
        entry.Body.Instructions.Insert(0,Instruction.Create(OpCodes.Call,cwd));
    }
}
