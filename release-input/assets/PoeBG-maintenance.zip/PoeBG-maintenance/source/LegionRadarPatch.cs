using System;
using System.Linq;
using System.Collections.Generic;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class LegionRadarPatch {
 sealed class Mapper:ImportMapper {
  public readonly Dictionary<string,ITypeDefOrRef> Types=new Dictionary<string,ITypeDefOrRef>();
  public readonly Dictionary<string,IField> Fields=new Dictionary<string,IField>();
  public readonly Dictionary<string,IMethod> Methods=new Dictionary<string,IMethod>();
  public override ITypeDefOrRef Map(ITypeDefOrRef t){ITypeDefOrRef v;return Types.TryGetValue(t.FullName,out v)?v:null;}
  public override IField Map(FieldDef f){IField v;return Fields.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
  public override IMethod Map(MethodDef f){IMethod v;return Methods.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
 }
 static bool Text(MethodDef m,string s){return m.HasBody&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand==s);}
 static bool IsRadar(IField f){return f!=null&&f.FieldSig!=null&&f.DeclaringType.FullName=="PoeBG.Main"&&f.FieldSig.Type.FullName=="System.Collections.Concurrent.ConcurrentDictionary`2<SharpDX.Vector2,PoeBG.RadarValue>";}
 static void Need(bool v,string s){if(!v)throw new Exception("Legion radar: "+s);}
 public static void Apply(ModuleDef module) {
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(!profile.Fields.Any(f=>f.Name=="LegionRadarSchema")&&!main.Methods.Any(m=>m.Name=="FilterLegionRadar"),"already patched");
  var methods=module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).ToArray();
  var worker=methods.Single(m=>Text(m,"Metadata/Terrain/Leagues/Legion/Objects/LegionInitiator")&&Text(m,"frozen_in_time")&&Text(m,"present")&&Text(m,"breakout")&&Text(m,"activated"));
  var refs=worker.Body.Instructions.Select(i=>i.Operand as IField).Where(f=>f!=null&&f.FieldSig!=null&&f.DeclaringType.FullName==main.FullName).GroupBy(f=>f.FullName).ToArray();
  var radarRefs=refs.Where(g=>IsRadar(g.First())).OrderByDescending(g=>g.Count()).ToArray();
  Need(radarRefs.Length>=2&&radarRefs[0].Count()>=15&&radarRefs[0].Count()>radarRefs[1].Count()*2,"ambiguous persistent radar cache");
  var cache=radarRefs[0].First().ResolveFieldDef();
  var entityRefs=refs.Where(g=>g.First().FieldSig.Type.FullName=="System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,PoeBG.MonsterInfo>").ToArray();
  var active=entityRefs.Select(g=>g.First().ResolveFieldDef()).Single(f=>f.IsPrivate);
  var publicEntities=entityRefs.Where(g=>g.First().ResolveFieldDef().IsPublic).OrderByDescending(g=>g.Count()).ToArray();
  Need(publicEntities.Length>=2&&publicEntities[0].Count()>=8&&publicEntities[0].Count()>publicEntities[1].Count()*2,"ambiguous ordinary entity cache");
  var other=publicEntities[0].First().ResolveFieldDef();
  var display=main.Methods.Single(m=>Text(m,"showRadar"));var displayIL=display.Body.Instructions;
  int showIndex=Enumerable.Range(0,displayIL.Count).Single(n=>displayIL[n].OpCode==OpCodes.Ldstr&&(string)displayIL[n].Operand=="showRadar");
  var displayFields=displayIL.Skip(Math.Max(0,showIndex-8)).Take(Math.Min(showIndex,8)).Select(i=>i.Operand as IField).Where(IsRadar).ToArray();
  Need(displayFields.Length==1,"ambiguous displayed radar field");var published=displayFields[0].ResolveFieldDef();Need(published!=cache,"display and persistent cache unexpectedly identical");
  var sites=methods.SelectMany(m=>Enumerable.Range(1,m.Body.Instructions.Count-1).Where(n=>m.Body.Instructions[n].OpCode==OpCodes.Stfld&&m.Body.Instructions[n].Operand is IField&&((IField)m.Body.Instructions[n].Operand).FullName==published.FullName&&m.Body.Instructions[n-1].OpCode==OpCodes.Newobj&&m.Body.Instructions[n-1].Operand is IMethod&&((IMethod)m.Body.Instructions[n-1].Operand).MethodSig.Params.Count==1).Select(n=>new{Method=m,Index=n})).ToArray();
  Need(sites.Length==1,"ambiguous completed-frame publication");var site=sites[0];
  var reader=main.Methods.Single(m=>m.HasBody&&m.MethodSig.RetType.FullName=="System.Collections.Generic.Dictionary`2<System.String,System.Int32>"&&m.MethodSig.Params.Count==2&&m.MethodSig.Params[0].ElementType==ElementType.I8&&m.MethodSig.Params[1].ElementType==ElementType.I4&&Text(m,"StateMachine"));
  Need(worker.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==reader.FullName),"reader not used by original legion branch");
  var entity=module.GetTypes().Single(t=>t.FullName=="PoeBG.MonsterInfo");var marker=module.GetTypes().Single(t=>t.FullName=="PoeBG.RadarValue");
  using(var source=ModuleDefMD.Load(typeof(LegionRadarPatch).Module.FullyQualifiedName)) {
   var map=new Mapper();map.Types["LegionRadarTemplate.Owner"]=main;map.Types["LegionRadarTemplate.Profile"]=profile;map.Types["LegionRadarTemplate.Entity"]=entity;map.Types["LegionRadarTemplate.Marker"]=marker;map.Types["LegionRadarTemplate.VectorKey"]=((GenericInstSig)cache.FieldSig.Type).GenericArguments[0].ToTypeDefOrRef();
   map.Fields["LegionRadarTemplate.Owner::Active"]=active;map.Fields["LegionRadarTemplate.Owner::Other"]=other;map.Fields["LegionRadarTemplate.Owner::Cached"]=cache;map.Methods["LegionRadarTemplate.Owner::StateReader"]=reader;
   foreach(var name in new[]{"get_EntityAddress","get_MetaPath"})map.Methods["LegionRadarTemplate.Entity::"+name]=entity.Methods.Single(m=>m.Name==name);
   foreach(var name in new[]{"get_ID","get_Metapath"})map.Methods["LegionRadarTemplate.Marker::"+name]=marker.Methods.Single(m=>m.Name==name);
   var importer=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),map);
   var copies=new Dictionary<MethodDef,MethodDef>();
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="LegionRadarTemplate.Owner"||t.FullName=="LegionRadarTemplate.Profile").SelectMany(t=>t.Methods).Where(m=>m.HasBody&&!m.IsConstructor&&m.Name!="StateReader")) {
    var target=new MethodDefUser(original.Name,importer.Import(original.MethodSig),original.ImplAttributes,original.Attributes);var owner=original.DeclaringType.Name=="Owner"?main:profile;owner.Methods.Add(target);copies[original]=target;map.Methods[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   foreach(var item in copies)CopyBody(item.Key,item.Value,importer);
  }
  var filter=main.Methods.Single(m=>m.Name=="FilterLegionRadar");
  var body=site.Method.Body;var temp=new Local(published.FieldSig.Type);body.Variables.Add(temp);body.InitLocals=true;
  var originalStore=body.Instructions[site.Index];originalStore.OpCode=OpCodes.Stloc;originalStore.Operand=temp;
  int insertion=site.Index;foreach(var ins in new[]{Instruction.Create(OpCodes.Dup),Instruction.Create(OpCodes.Ldloc,temp),Instruction.Create(OpCodes.Call,filter),Instruction.Create(OpCodes.Stfld,published)})body.Instructions.Insert(++insertion,ins);
  body.SimplifyBranches();
  var schema=new FieldDefUser("LegionRadarSchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);schema.Constant=new ConstantUser("1");profile.Fields.Add(schema);
  Validate(module);
 }
 static void CopyBody(MethodDef source,MethodDef target,Importer importer) {
  target.Body=new CilBody{InitLocals=source.Body.InitLocals,MaxStack=source.Body.MaxStack};
  var locals=new Dictionary<Local,Local>();foreach(var l in source.Body.Variables){var n=new Local(importer.Import(l.Type));target.Body.Variables.Add(n);locals[l]=n;}
  var instructions=new Dictionary<Instruction,Instruction>();foreach(var i in source.Body.Instructions){var n=new Instruction(i.OpCode,null);target.Body.Instructions.Add(n);instructions[i]=n;}
  foreach(var i in source.Body.Instructions){object o=i.Operand;if(o is Instruction)o=instructions[(Instruction)o];else if(o is Instruction[])o=((Instruction[])o).Select(x=>instructions[x]).ToArray();else if(o is Local)o=locals[(Local)o];else if(o is Parameter)o=target.Parameters[((Parameter)o).Index];else if(o is IMethod)o=importer.Import((IMethod)o);else if(o is IField)o=importer.Import((IField)o);else if(o is ITypeDefOrRef)o=importer.Import((ITypeDefOrRef)o);else if(o is MethodSig)o=importer.Import((MethodSig)o);instructions[i].Operand=o;}
  foreach(var h in source.Body.ExceptionHandlers)target.Body.ExceptionHandlers.Add(new ExceptionHandler(h.HandlerType){TryStart=h.TryStart==null?null:instructions[h.TryStart],TryEnd=h.TryEnd==null?null:instructions[h.TryEnd],HandlerStart=h.HandlerStart==null?null:instructions[h.HandlerStart],HandlerEnd=h.HandlerEnd==null?null:instructions[h.HandlerEnd],FilterStart=h.FilterStart==null?null:instructions[h.FilterStart],CatchType=h.CatchType==null?null:importer.Import(h.CatchType)});
  target.Body.SimplifyBranches();
 }
 public static void Validate(ModuleDef module) {
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  Need(profile.Fields.Single(f=>f.Name=="LegionRadarSchema").Constant.Value.ToString()=="1","schema missing");
  Need(Text(profile.Methods.Single(m=>m.Name=="LegionRadarShouldShow"),"present")&&Text(profile.Methods.Single(m=>m.Name=="LegionRadarShouldShow"),"breakout")&&Text(profile.Methods.Single(m=>m.Name=="LegionRadarShouldShow"),"activated"),"predicate missing");
  var filter=main.Methods.Single(m=>m.Name=="FilterLegionRadar");Need(module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).Sum(m=>m.Body.Instructions.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==filter.FullName))==1,"publication call missing/duplicated");
  Need(!main.Methods.Where(m=>m.Name=="FilterLegionRadar"||m.Name=="LegionRadarReadStates"||m.Name=="LegionRadarFilterOne").SelectMany(m=>m.Body.Instructions).Any(i=>i.Operand!=null&&i.Operand.ToString().Contains("LegionRadarTemplate")),"template reference leaked");
 }
}
