using System;
using System.IO;
using System.Reflection;

public static class LegionRadarOptionsVerification {
 public static void Run(Assembly assembly) {
  var profile=assembly.GetType("PoeBG.LocalPatchProfile",true);
  var read=profile.GetMethod("ReadLegionRadarOption",BindingFlags.Public|BindingFlags.Static);
  var save=profile.GetMethod("TrySaveLegionRadarOption",BindingFlags.Public|BindingFlags.Static);
  if(read==null||save==null)throw new Exception("Missing Legion checkbox persistence helpers");
  string root=Path.Combine(Path.GetTempPath(),"PoeBG-legion-options-"+Guid.NewGuid().ToString("N"));
  string maintenance=Path.Combine(root,"PoeBG-maintenance"), setting=Path.Combine(maintenance,"legion-radar.settings"), blocked=Path.Combine(root,"blocked");
  int checks=0;
  Action<bool> need=condition=>{if(!condition)throw new Exception("Legion checkbox persistence regression");checks++;};
  Func<string,bool> readAt=path=>(bool)read.Invoke(null,new object[]{path});
  Func<string,bool,bool> saveAt=(path,value)=>(bool)save.Invoke(null,new object[]{path,value});
  try {
   need(!readAt(root));need(!Directory.Exists(root));
   need(saveAt(root,true));need(readAt(root));
   need(saveAt(root,false));need(!readAt(root));
   File.WriteAllText(setting,"invalid");need(!readAt(root));
   File.WriteAllText(blocked,"block directory creation");need(!saveAt(blocked,true));
   need(!readAt(blocked));
  } finally {
   foreach(string file in new[]{setting,setting+".tmp",blocked})if(File.Exists(file))File.Delete(file);
   if(Directory.Exists(maintenance))Directory.Delete(maintenance,false);
   if(Directory.Exists(root))Directory.Delete(root,false);
  }
  Console.WriteLine("PASS: "+checks+" Legion checkbox persistence checks; default disabled, saved on/off, invalid settings and write failure; isolated temporary files only.");
 }
}
