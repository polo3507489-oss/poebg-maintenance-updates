using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
using dnlib.DotNet.Writer;

class Patch {
    static MethodDef Async(TypeDef t, string name) {
        return t.Methods.Single(m => m.CustomAttributes.Any(a => a.TypeFullName == "System.Runtime.CompilerServices.AsyncStateMachineAttribute" && a.ConstructorArguments.Count == 1 && a.ConstructorArguments[0].Value.ToString().Contains("/" + name + ">")));
    }
    static TypeDef Machine(ModuleDef m, MethodDef method) {
        var a = method.CustomAttributes.Single(c => c.TypeFullName == "System.Runtime.CompilerServices.AsyncStateMachineAttribute");
        return m.GetTypes().Single(t => t.FullName == a.ConstructorArguments[0].Value.ToString());
    }
    static void Marker(ModuleDef m, string name, string value, TypeDef profile) {
        var field = new FieldDefUser(name, new FieldSig(m.CorLibTypes.String), FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);
        field.Constant = new ConstantUser(value); profile.Fields.Add(field);
    }
    static void Require(bool ok, string message) { if (!ok) throw new Exception(message); }
    static void SetField(CilBody b, TypeDef t, string name, int value) {
        b.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));
        b.Instructions.Add(Instruction.Create(OpCodes.Ldc_I4, value));
        b.Instructions.Add(Instruction.Create(OpCodes.Stfld, t.Fields.Single(f => f.Name == name)));
    }
    static string Fingerprint(TypeDef t) {
        return string.Join("\n", t.Methods.Where(m => m.HasBody).Select(m => m.Name + ":" + string.Join("|", m.Body.Instructions.Select(i => {
            var branch=i.Operand as Instruction;
            var branches=i.Operand as Instruction[];
            var local=i.Operand as Local;
            var parameter=i.Operand as Parameter;
            string operand=branch!=null?"branch:"+m.Body.Instructions.IndexOf(branch):branches!=null?"branches:"+string.Join(",",branches.Select(b=>m.Body.Instructions.IndexOf(b))):local!=null?"local:"+local.Index:parameter!=null?"arg:"+parameter.Index:Convert.ToString(i.Operand);
            return i.OpCode.Name+":"+operand;
        }))));
    }
    static void Main(string[] args) {
        try { Run(args); } catch(Exception ex) { Console.Error.WriteLine(ex.ToString()); Environment.ExitCode=1; }
    }
    static void Run(string[] args) {
        var module = ModuleDefMD.Load(args[0]);
        var main = module.GetTypes().Single(t => t.FullName == "PoeBG.Main");
        var updater = Machine(module, Async(main, "<CheckUpdate"));
        var updateIL = updater.Methods.Single(m => m.Name == "MoveNext").Body.Instructions;
        var updaterLiterals = updateIL.Where(i => i.OpCode == OpCodes.Ldstr && (string)i.Operand == "Updater.exe").ToArray();
        Require(updaterLiterals.Length == 3, "Unrecognized update flow; refusing patch");
        updaterLiterals[1].Operand = "PoeBGUpdateGuard.exe";
        ServiceFixes.Apply(module);
        var profile = new TypeDefUser("PoeBG", "LocalPatchProfile", module.CorLibTypes.Object.TypeDefOrRef);
        profile.Attributes = TypeAttributes.Public|TypeAttributes.Abstract|TypeAttributes.Sealed;
        module.Types.Add(profile);
        UpdateExitFixes.Apply(module);
        var updateBefore = Fingerprint(updater);
        var license = Async(main, "<GetLicenseDate");
        var originalLicense = Machine(module, license).Methods.Single(m => m.Name == "MoveNext");
        var assignments = originalLicense.Body.Instructions.Where(i => i.OpCode == OpCodes.Stfld && ((IField)i.Operand).DeclaringType.FullName == main.FullName).Select(i => ((IField)i.Operand).ResolveFieldDef()).ToArray();
        var licensedFlag = assignments.Where(f => f.FieldSig.Type.ElementType == ElementType.Boolean).Distinct().Single();
        var intFields = assignments.Where(f => f.FieldSig.Type.ElementType == ElementType.I4).GroupBy(f => f).ToArray();
        Require(intFields.Length == 2, "Unrecognized license fields; refusing patch");
        var tierField = intFields.Single(g => g.Count() > 1).Key;
        var limitField = intFields.Single(g => g.Count() == 1).Key;
        var valid = main.Methods.Single(m => m.HasBody && m.MethodSig.RetType.ElementType == ElementType.Boolean && m.MethodSig.Params.Count == 0 && m.Body.Instructions.Count(i => i.Operand is IMethod && ((IMethod)i.Operand).FullName.Contains("System.Convert::FromBase64String")) >= 2 && m.Body.Instructions.Any(i => i.Operand is IMethod && ((IMethod)i.Operand).FullName.Contains("System.DateTime::op_GreaterThan")));
        var api = Async(main, "<SendWebApiAsync");
        var apiMachine = Machine(module,api);
        var commandField = apiMachine.Fields.Single(f => f.Name == "CmdStr");
        var parameterField = apiMachine.Fields.Single(f => f.Name == "ParamStr");
        var trial = Async(main, "<ApplyTry7Day");
        var handlers = new[] { Async(main, "<btCreateACC_Click"), Async(main, "<btTryAgain_Click") };
        var initialize = main.Methods.Single(m => m.HasBody && m.Body.Instructions.Any(i => i.OpCode == OpCodes.Ldstr && (string)i.Operand == "btCreateACC") && m.Body.Instructions.Any(i => i.OpCode == OpCodes.Ldstr && (string)i.Operand == "btTryAgain"));
        var paymentFields = new List<string>();
        for (int n=1; n<initialize.Body.Instructions.Count; n++) {
            var il = initialize.Body.Instructions;
            if (il[n].OpCode == OpCodes.Ldstr && new[] { "btCreateACC", "btTryAgain", "btNothing" }.Contains((string)il[n].Operand)) {
                Require(il[n-1].OpCode == OpCodes.Ldfld, "Unrecognized payment control");
                paymentFields.Add(((IField)il[n-1].Operand).Name.String);
            }
        }
        paymentFields = paymentFields.Distinct().ToList();
        Require(paymentFields.Count == 3, "Missing payment controls: "+paymentFields.Count);
        var import = new Importer(module);
        int resourceFixes = 0;
        foreach (var type in module.GetTypes()) foreach (var method in type.Methods.Where(m => m.HasBody)) {
            foreach (var instruction in method.Body.Instructions) {
                var called = instruction.Operand as IMethod;
                if(type.FullName=="LegendTool.LoadResoureDll"&&instruction.OpCode==OpCodes.Call&&instruction.Operand==null) {
                    int at=method.Body.Instructions.IndexOf(instruction);var body=method.Body;
                    Require(at>0&&at+1<body.Instructions.Count&&body.Instructions[at-1].IsLdloc()&&body.Instructions[at+1].IsStloc(),"Unrecognized unresolved resource call");
                    Require(body.Instructions[at-1].GetLocal(body.Variables).Type.FullName=="System.Reflection.Assembly"&&body.Instructions[at+1].GetLocal(body.Variables).Type.FullName=="System.String[]","Unresolved resource call types changed");
                    instruction.OpCode=OpCodes.Callvirt;instruction.Operand=import.Import(typeof(System.Reflection.Assembly).GetMethod("GetManifestResourceNames"));resourceFixes++;
                }
                if (type.FullName == "LegendTool.LoadResoureDll" && called != null && called.MethodSig.RetType.FullName == "System.String[]" && called.MethodSig.Params.Count == 1 && called.MethodSig.Params[0].FullName == "System.Reflection.Assembly" && called.DeclaringType.DefinitionAssembly.Name == module.Assembly.Name) {
                    instruction.OpCode = OpCodes.Callvirt;
                    instruction.Operand = import.Import(typeof(System.Reflection.Assembly).GetMethod("GetManifestResourceNames"));
                    resourceFixes++;
                }
            }
        }
        Require(resourceFixes <= 1, "Unexpected resource loader shape");
        var taskResult = (IMethodDefOrRef)import.Import(typeof(Task).GetMethods().Single(m => m.Name == "FromResult"));
        var stringTask = new MethodSpecUser(taskResult, new GenericInstMethodSig(module.CorLibTypes.String));
        var boolTask = new MethodSpecUser(taskResult, new GenericInstMethodSig(module.CorLibTypes.Boolean));
        license.Body = new CilBody();
        SetField(license.Body, main, licensedFlag.Name, 1);
        SetField(license.Body, main, tierField.Name, 3);
        SetField(license.Body, main, limitField.Name, 24);
        license.Body.Instructions.Add(Instruction.Create(OpCodes.Ldstr, "9999-12-31 23:59:59"));
        license.Body.Instructions.Add(Instruction.Create(OpCodes.Call, stringTask));
        license.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));
        valid.Body = new CilBody();
        valid.Body.Instructions.Add(Instruction.Create(OpCodes.Ldc_I4_1));
        valid.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));
        trial.Body = new CilBody();
        trial.Body.Instructions.Add(Instruction.Create(OpCodes.Ldc_I4_1));
        trial.Body.Instructions.Add(Instruction.Create(OpCodes.Call, boolTask));
        trial.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));
        foreach (var handler in handlers) {
            handler.Body = new CilBody(); handler.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));
        }
        int initial = 0, hidden = 0;
        foreach (var method in main.Methods.Where(m => m.HasBody)) {
            var il = method.Body.Instructions;
            for (int n = 1; n < il.Count; n++) {
                var field = il[n].Operand as IField;
                if (method.IsInstanceConstructor && il[n].OpCode == OpCodes.Stfld && field != null && field.Name == licensedFlag.Name) {
                    Require(il[n-1].IsLdcI4(), "Unexpected initial license flag");
                    il[n-1].OpCode = OpCodes.Ldc_I4_1; il[n-1].Operand = null; initial++;
                }
            }
        }
        Require(initial == 1, "Expected one initial license flag");
        foreach (var type in module.GetTypes()) foreach (var method in type.Methods.Where(m => m.HasBody)) {
            var il = method.Body.Instructions;
            for (int n = 0; n + 2 < il.Count; n++) {
                var field = il[n].Operand as IField;
                var call = il[n+2].Operand as IMethod;
                if (il[n].OpCode == OpCodes.Ldfld && field != null && field.DeclaringType.FullName == "PoeBG.Main" && paymentFields.Contains(field.Name.String) && il[n+1].IsLdcI4() && call != null && call.Name == "set_Visible") {
                    il[n+1].OpCode = OpCodes.Ldc_I4_0; il[n+1].Operand = null; hidden++;
                }
            }
        }
        Require(hidden > 5, "Missing payment visibility updates");
        var visibility = module.GetMemberRefs().Single(r => r.FullName == "System.Void System.Windows.Forms.ToolStripItem::set_Visible(System.Boolean)");
        var end = initialize.Body.Instructions.Last();
        Require(end.OpCode == OpCodes.Ret, "Unexpected UI initializer");
        foreach (var name in paymentFields) {
            var il = initialize.Body.Instructions;
            il.Insert(il.Count-1, Instruction.Create(OpCodes.Ldarg_0));
            il.Insert(il.Count-1, Instruction.Create(OpCodes.Ldfld, main.Fields.Single(f => f.Name == name)));
            il.Insert(il.Count-1, Instruction.Create(OpCodes.Ldc_I4_0));
            il.Insert(il.Count-1, Instruction.Create(OpCodes.Callvirt, visibility));
        }
        // Keep the original network helper for updates; only its time query is local.
        var start = api.Body.Instructions[0];
        var now = new Local(import.ImportAsTypeSig(typeof(DateTime)));
        api.Body.Variables.Add(now); api.Body.InitLocals = true;
        var prefix = new[] {
            Instruction.Create(OpCodes.Ldarg_1),
            Instruction.Create(OpCodes.Ldstr, "qrySysDateTime"),
            Instruction.Create(OpCodes.Call, import.Import(typeof(string).GetMethod("op_Equality", new[] {typeof(string),typeof(string)}))),
            Instruction.Create(OpCodes.Brfalse, start),
            Instruction.Create(OpCodes.Call, import.Import(typeof(DateTime).GetProperty("Now").GetGetMethod())),
            Instruction.Create(OpCodes.Stloc, now), Instruction.Create(OpCodes.Ldloca, now),
            Instruction.Create(OpCodes.Ldstr, "yyyy-MM-dd HH:mm:ss"),
            Instruction.Create(OpCodes.Call, import.Import(typeof(DateTime).GetMethod("ToString", new[] {typeof(string)}))),
            Instruction.Create(OpCodes.Call, stringTask), Instruction.Create(OpCodes.Ret)
        };
        for (int n=0; n<prefix.Length; n++) api.Body.Instructions.Insert(n,prefix[n]);
        var apiBody=apiMachine.Methods.Single(m=>m.Name=="MoveNext").Body;
        var setResults=apiBody.Instructions.Where(i=>i.Operand is IMethod && ((IMethod)i.Operand).Name=="SetResult").ToArray();
        Require(setResults.Length==1,"Unrecognized API completion flow");
        int resultIndex=apiBody.Instructions.IndexOf(setResults[0]);
        foreach(var instruction in new[] {
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,commandField),
            Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,parameterField),
            Instruction.Create(OpCodes.Call,import.Import(typeof(PoeBGUpdateSupport).GetMethod("Filter")))
        }) apiBody.Instructions.Insert(resultIndex++,instruction);
        Marker(module,"LicenseMethod",license.Name,profile); Marker(module,"ValidMethod",valid.Name,profile);
        Marker(module,"FlagField",licensedFlag.Name,profile); Marker(module,"ApiMethod",api.Name,profile);
        Marker(module,"TrialMethod",trial.Name,profile); Marker(module,"BuyHandler",handlers[0].Name,profile);
        Marker(module,"TrialHandler",handlers[1].Name,profile); Marker(module,"Schema","2",profile);
        CharacterScanPatch.Apply(module);
        FontSafetyPatch.Apply(module);
        GameplayFixes.Apply(module);
        DataToolFixes.Apply(module);
        LegionRadarPatch.Apply(module);
        LegionRadarOptionsPatch.Apply(module);
        CloseFollowOptionsPatch.Apply(module);
        FollowMoveInputPatch.Apply(module);
        CloseFollowPatch.Apply(module);
        Require(Fingerprint(updater) == updateBefore, "Update logic changed");
        var options = new ModuleWriterOptions(module);
        options.MetadataOptions.Flags |= MetadataFlags.PreserveAll;
        module.Write(args[1], options);
        using (var check = ModuleDefMD.Load(args[1])) {
            LegionRadarPatch.Validate(check);
            LegionRadarOptionsPatch.Validate(check);
            CloseFollowOptionsPatch.Validate(check);
            FollowMoveInputPatch.Validate(check);
            CloseFollowPatch.Validate(check);
            Require(Fingerprint(check.GetTypes().Single(t => t.FullName == updater.FullName)) == updateBefore, "Written update logic changed");
            Require(check.GetTypes().Single(t => t.FullName == main.FullName).Methods.Single(m => m.Name == valid.Name).Body.Instructions[0].OpCode == OpCodes.Ldc_I4_1, "Written patch missing");
        }
        Console.WriteLine("Verified: license provider replaced; expiry check removed; " + hidden + " payment visibility writes disabled; update handoff exits after normal shutdown; remaining update state machine preserved.");
    }
}


