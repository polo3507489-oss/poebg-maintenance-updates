using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
namespace LegionRadarOptionsTemplate {
 public static class Profile {
  public static volatile bool LegionRadarEnabled;
  public static volatile bool LegionRadarOptionsLoaded;
  public static bool ReadLegionRadarOption(string root) {
   try {return File.ReadAllText(Path.Combine(root,"PoeBG-maintenance","legion-radar.settings")).Trim()=="1";}catch(Exception){return false;}
  }
  public static bool TrySaveLegionRadarOption(string root,bool enabled) {
   string pending=null;
   try {
    string dir=Path.Combine(root,"PoeBG-maintenance");Directory.CreateDirectory(dir);
    string path=Path.Combine(dir,"legion-radar.settings");pending=path+".pending-"+Guid.NewGuid().ToString("N");
    File.WriteAllText(pending,enabled?"1":"0");
    if(File.Exists(path))File.Replace(pending,path,null);else File.Move(pending,path);
    return true;
   }catch(Exception){return false;}finally{try{if(pending!=null&&File.Exists(pending))File.Delete(pending);}catch(Exception){}}
  }
  public static void LoadLegionRadarOptions() {
   if(LegionRadarOptionsLoaded)return;
   LegionRadarEnabled=ReadLegionRadarOption(AppDomain.CurrentDomain.BaseDirectory);
   LegionRadarOptionsLoaded=true;
  }
 }
 public class Dialog:Form {
  public CheckBox LegionRadarActiveOnlyBox;
  public void AttachLegionRadarOption() {
   if(LegionRadarActiveOnlyBox!=null)return;
   Profile.LoadLegionRadarOptions();
   Control[] buttons=Controls.Find("btOK",true);
   if(buttons.Length!=1)throw new InvalidOperationException("Radar confirmation button was not found");
   Control button=buttons[0];int row=Math.Max(button.Height,28);int top=button.Top;
   SuspendLayout();
   ClientSize=new Size(ClientSize.Width,ClientSize.Height+row);
   button.Top=top+row;
   var box=new CheckBox();box.Name="cbLegionActiveOnly";box.Text="戰亂啟動後才顯示";box.AutoSize=true;
   box.Font=Font;box.Location=new Point(button.Left,top+Math.Max(0,(row-box.PreferredSize.Height)/2));
   box.Checked=Profile.LegionRadarEnabled;box.TabIndex=button.TabIndex;button.TabIndex++;
   LegionRadarActiveOnlyBox=box;Controls.Add(box);box.BringToFront();ResumeLayout(true);
  }
  public bool CommitLegionRadarOption() {
   if(LegionRadarActiveOnlyBox==null)return false;
   bool enabled=LegionRadarActiveOnlyBox.Checked;
   if(!Profile.TrySaveLegionRadarOption(AppDomain.CurrentDomain.BaseDirectory,enabled)) {
    MessageBox.Show(this,"無法儲存戰亂顯示設定，請確認程式資料夾的寫入權限，再按確定。","設定未儲存",MessageBoxButtons.OK,MessageBoxIcon.Warning);
    return false;
   }
   Profile.LegionRadarEnabled=enabled;Profile.LegionRadarOptionsLoaded=true;return true;
  }
 }
}
