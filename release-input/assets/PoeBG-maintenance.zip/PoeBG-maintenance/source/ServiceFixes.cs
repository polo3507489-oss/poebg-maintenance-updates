using System;
using System.Linq;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class ServiceFixes {
 static MethodDef FindAsync(TypeDef type,string originalName) {
   return type.Methods.Single(m=>m.HasBody&&m.CustomAttributes.Any(a=>a.TypeFullName=="System.Runtime.CompilerServices.AsyncStateMachineAttribute"&&a.ConstructorArguments.Count==1&&a.ConstructorArguments[0].Value.ToString().Contains("/<"+originalName+">")));
 }
 public static MethodDef[] Apply(ModuleDef module) {
   var search=module.GetTypes().Single(t=>t.FullName=="PoeBG.TradeSearch");
   var wrapper=FindAsync(search,"btReloadSettings_Click");
   if(wrapper.MethodSig.RetType.ElementType!=ElementType.Void||wrapper.MethodSig.Params.Count!=2||wrapper.MethodSig.Params[0].FullName!="System.Object"||wrapper.MethodSig.Params[1].FullName!="System.EventArgs")throw new Exception("Unsupported TradeSearch reload signature");
   var attribute=wrapper.CustomAttributes.Single(a=>a.TypeFullName=="System.Runtime.CompilerServices.AsyncStateMachineAttribute");
   string stateName=attribute.ConstructorArguments[0].Value.ToString();
   var state=module.GetTypes().Single(t=>t.FullName==stateName);
   var ins=state.Methods.Single(m=>m.Name=="MoveNext").Body.Instructions;
   var sites=Enumerable.Range(0,ins.Count).Where(n=>ins[n].Operand is IMethod&&((IMethod)ins[n].Operand).Name=="get_SelectedItem").ToArray();
   if(sites.Length!=2)throw new Exception("Unrecognized TradeSearch league selection flow");
   int selected=sites[0];
   var combo=ins.Take(selected).Reverse().Select(i=>i.Operand as IField).FirstOrDefault(f=>f!=null&&f.FieldSig!=null&&f.DeclaringType.FullName==search.FullName&&f.FieldSig.Type.FullName=="System.Windows.Forms.ComboBox");
   if(combo==null)throw new Exception("TradeSearch league control was not identified");
   if(wrapper.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).Name=="get_SelectedItem"))throw new Exception("TradeSearch league guard is already present");
   var first=wrapper.Body.Instructions[0];var done=Instruction.Create(OpCodes.Ret);
   var prefix=new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,combo),Instruction.Create(OpCodes.Brfalse,done),Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldfld,combo),Instruction.Create(OpCodes.Callvirt,(IMethod)ins[selected].Operand),Instruction.Create(OpCodes.Brtrue,first),done};
   for(int n=0;n<prefix.Length;n++)wrapper.Body.Instructions.Insert(n,prefix[n]);
   var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");
   var update=FindAsync(main,"CheckUpdate");
   if(update.MethodSig.Params.Count!=2||update.MethodSig.Params[0].FullName!="System.String"||update.MethodSig.Params[1].FullName!="System.Boolean")throw new Exception("Unsupported update signature");
   var updateAttribute=update.CustomAttributes.Single(a=>a.TypeFullName=="System.Runtime.CompilerServices.AsyncStateMachineAttribute");
   var updateState=module.GetTypes().Single(t=>t.FullName==updateAttribute.ConstructorArguments[0].Value.ToString());
   var move=updateState.Methods.Single(m=>m.Name=="MoveNext");var body=move.Body.Instructions;
   var errorSites=Enumerable.Range(0,body.Count).Where(n=>body[n].OpCode==OpCodes.Ldstr&&(string)body[n].Operand=="XX").ToArray();
   if(errorSites.Length!=1)throw new Exception("Unrecognized empty-update error flow");
   int error=errorSites[0];
   var resource=error>0?body[error-1].Operand as IMethod:null;
   if(resource==null||resource.Name!="get_UnableConnectPoeBG")throw new Exception("Unrecognized empty-update message");
   var exits=body.Skip(error+1).TakeWhile(i=>i.OpCode.FlowControl!=FlowControl.Branch&&i.OpCode.FlowControl!=FlowControl.Return).Where(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName=="System.Void System.Windows.Forms.Application::Exit()").ToArray();
   if(exits.Length!=1)throw new Exception("Unrecognized empty-update exit branch");
   int before=body.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName=="System.Void System.Windows.Forms.Application::Exit()");
   exits[0].OpCode=OpCodes.Nop;exits[0].Operand=null;
   int after=body.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName=="System.Void System.Windows.Forms.Application::Exit()");
   if(after!=before-1)throw new Exception("Unexpected update exit changes");
   return new[]{wrapper,move};
 }
}


