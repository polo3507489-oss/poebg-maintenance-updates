using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;

public static class PoeBGMemoryReadSupport
{
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ReadProcessMemory(IntPtr process, IntPtr address,
        [Out] byte[] buffer, UIntPtr size, out UIntPtr bytesRead);

    public static IntPtr ScanText(IntPtr handle, ProcessModule module, string pattern, int start)
    {
        byte[] bytes;
        string mask;
        if (!TryParsePattern(pattern, out bytes, out mask)) return IntPtr.Zero;
        return Scan(handle, module, bytes, mask, start, 0);
    }

    private static bool TryParsePattern(string text, out byte[] pattern, out string mask)
    {
        pattern = null;
        mask = null;
        if (string.IsNullOrWhiteSpace(text)) return false;
        string[] parts = text.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
        byte[] bytes = new byte[parts.Length];
        char[] masks = new char[parts.Length];
        for (int index = 0; index < parts.Length; index++)
        {
            if (parts[index] == "??") masks[index] = '?';
            else
            {
                if (parts[index].Length != 2 || !byte.TryParse(parts[index], NumberStyles.HexNumber,
                    CultureInfo.InvariantCulture, out bytes[index])) return false;
                masks[index] = 'x';
            }
        }
        pattern = bytes;
        mask = new string(masks);
        return true;
    }

    public static IntPtr Scan(IntPtr handle, ProcessModule module, byte[] pattern,
        string mask, int start, int length)
    {
        if (module == null) return IntPtr.Zero;
        try
        {
            return ScanRegion(handle, module.BaseAddress, module.ModuleMemorySize,
                pattern, mask, start, length);
        }
        catch (InvalidOperationException) { return IntPtr.Zero; }
        catch (Win32Exception) { return IntPtr.Zero; }
    }

    // A zero length retains the existing scanner's "remaining image" convention.
    public static IntPtr ScanRegion(IntPtr handle, IntPtr imageBase, int imageSize,
        byte[] pattern, string mask, int start, int length)
    {
        if (handle == IntPtr.Zero || imageBase == IntPtr.Zero || imageSize <= 0 ||
            pattern == null || pattern.Length == 0 || mask == null ||
            mask.Length != pattern.Length || start < 0 || start >= imageSize || length < 0)
            return IntPtr.Zero;

        int available = imageSize - start;
        int count = length == 0 ? available : length;
        if (count > available || pattern.Length > count) return IntPtr.Zero;

        ulong baseAddress = Address(imageBase);
        ulong pointerMaximum = IntPtr.Size == 8 ? ulong.MaxValue : uint.MaxValue;
        if ((ulong)(imageSize - 1) > pointerMaximum - baseAddress) return IntPtr.Zero;

        byte[] window = new byte[count];
        UIntPtr read;
        if (ReadProcessMemory(handle, Pointer(baseAddress + (ulong)start), window,
            new UIntPtr((uint)count), out read) && read.ToUInt64() == (ulong)count)
        {
            int match = Find(window, pattern, mask);
            return match < 0 ? IntPtr.Zero : Pointer(baseAddress + (ulong)start + (ulong)match);
        }

        // Failed reads are discarded. Only adjacent successful page slices may overlap.
        int pageSize = Environment.SystemPageSize;
        byte[] carry = new byte[0];
        int processed = 0;
        while (processed < count)
        {
            ulong address = baseAddress + (ulong)start + (ulong)processed;
            int pageRemaining = pageSize - (int)(address % (ulong)pageSize);
            int sliceLength = Math.Min(pageRemaining, count - processed);
            byte[] slice = new byte[sliceLength];
            if (ReadProcessMemory(handle, Pointer(address), slice,
                new UIntPtr((uint)sliceLength), out read) && read.ToUInt64() == (ulong)sliceLength)
            {
                byte[] joined = new byte[carry.Length + slice.Length];
                Buffer.BlockCopy(carry, 0, joined, 0, carry.Length);
                Buffer.BlockCopy(slice, 0, joined, carry.Length, slice.Length);
                int match = Find(joined, pattern, mask);
                if (match >= 0) return Pointer(address - (ulong)carry.Length + (ulong)match);
                int keep = Math.Min(pattern.Length - 1, joined.Length);
                carry = new byte[keep];
                Buffer.BlockCopy(joined, joined.Length - keep, carry, 0, keep);
            }
            else
            {
                carry = new byte[0];
            }
            processed += sliceLength;
        }
        return IntPtr.Zero;
    }

    private static int Find(byte[] bytes, byte[] pattern, string mask)
    {
        for (int offset = 0; offset <= bytes.Length - pattern.Length; offset++)
        {
            int index = 0;
            while (index < pattern.Length &&
                (mask[index] == '?' || bytes[offset + index] == pattern[index])) index++;
            if (index == pattern.Length) return offset;
        }
        return -1;
    }

    private static ulong Address(IntPtr pointer)
    {
        return IntPtr.Size == 8 ? unchecked((ulong)pointer.ToInt64()) : unchecked((uint)pointer.ToInt32());
    }

    private static IntPtr Pointer(ulong address)
    {
        return IntPtr.Size == 8 ? new IntPtr(unchecked((long)address)) : new IntPtr(unchecked((int)address));
    }
}
