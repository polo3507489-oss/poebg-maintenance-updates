using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
namespace CloseFollowOptionsTemplate {
 public static class Profile {
  public static volatile bool CloseFollowEnabled;
  public static volatile bool CloseFollowOptionsLoaded;
  public static bool ReadCloseFollowOption(string root) {
   try{return File.ReadAllText(Path.Combine(root,"PoeBG-maintenance","close-follow.settings")).Trim()=="1";}catch(Exception){return false;}
  }
  public static bool TrySaveCloseFollowOption(string root,bool enabled) {
   string pending=null;
   try {
    string dir=Path.Combine(root,"PoeBG-maintenance");Directory.CreateDirectory(dir);
    string path=Path.Combine(dir,"close-follow.settings");pending=path+".pending-"+Guid.NewGuid().ToString("N");
    File.WriteAllText(pending,enabled?"1":"0");
    if(File.Exists(path))File.Replace(pending,path,null);else File.Move(pending,path);
    return true;
   }catch(Exception){return false;}finally{try{if(pending!=null&&File.Exists(pending))File.Delete(pending);}catch(Exception){}}
  }
  public static void LoadCloseFollowOptions() {
   if(CloseFollowOptionsLoaded)return;
   CloseFollowEnabled=ReadCloseFollowOption(AppDomain.CurrentDomain.BaseDirectory);
   CloseFollowOptionsLoaded=true;
  }
 }
 public class Owner:Form {
  public CheckBox CloseFollowOptionBox;
  private bool CloseFollowOptionChanging;
  private bool CloseFollowOptionArranging;
  private bool CloseFollowOptionLayoutPending;
  private int CloseFollowOptionFallbackTop;
  private Control CloseFollowOptionAnchor;
  public void AttachCloseFollowOption() {
   if(CloseFollowOptionBox!=null)return;
   Profile.LoadCloseFollowOptions();
   Control[] anchors=Controls.Find("cbOptIn",true);
   if(anchors.Length!=1||anchors[0].Parent==null)return;
   Control anchor=anchors[0],parent=anchor.Parent;
   var box=new CheckBox();box.Name="cbCloseFollow";box.Text="貼身跟隨";box.AutoSize=true;box.Font=anchor.Font;
   box.ForeColor=Color.Yellow;box.BackColor=Color.FromArgb(40,40,40);box.UseVisualStyleBackColor=false;box.Cursor=Cursors.Hand;
   box.Checked=Profile.CloseFollowEnabled;box.TabIndex=anchor.TabIndex+1;
   CloseFollowOptionBox=box;CloseFollowOptionAnchor=anchor;parent.Controls.Add(box);box.BringToFront();
   box.CheckedChanged+=CloseFollowOptionChanged;
   parent.Layout+=CloseFollowOptionLayout;
   parent.SizeChanged+=CloseFollowOptionBoundsChanged;
   anchor.SizeChanged+=CloseFollowOptionBoundsChanged;
   anchor.LocationChanged+=CloseFollowOptionBoundsChanged;
   anchor.FontChanged+=CloseFollowOptionBoundsChanged;
   anchor.TextChanged+=CloseFollowOptionBoundsChanged;
   box.SizeChanged+=CloseFollowOptionBoundsChanged;
   Shown+=CloseFollowOptionBoundsChanged;
   RepositionCloseFollowOption();
  }
  private void CloseFollowOptionLayout(object sender,LayoutEventArgs args){QueueCloseFollowOptionLayout();}
  private void CloseFollowOptionBoundsChanged(object sender,EventArgs args){QueueCloseFollowOptionLayout();}
  private void QueueCloseFollowOptionLayout() {
   if(CloseFollowOptionArranging||CloseFollowOptionLayoutPending||IsDisposed)return;
   if(IsHandleCreated){CloseFollowOptionLayoutPending=true;BeginInvoke(new MethodInvoker(ApplyQueuedCloseFollowOptionLayout));}
   else RepositionCloseFollowOption();
  }
  private void ApplyQueuedCloseFollowOptionLayout(){try{if(!IsDisposed)RepositionCloseFollowOption();}finally{CloseFollowOptionLayoutPending=false;}}
  private bool CloseFollowOptionFits(Control parent,Rectangle bounds) {
   if(bounds.Left<0||bounds.Top<0||bounds.Right>parent.ClientSize.Width||bounds.Bottom>parent.ClientSize.Height)return false;
   Rectangle inside=bounds;inside.Inflate(-1,-1);
   foreach(Control control in parent.Controls) {
    if(control==CloseFollowOptionBox)continue;
    Rectangle occupied=control.Bounds;occupied.Inflate(-1,-1);
    if(inside.IntersectsWith(occupied))return false;
   }
   return true;
  }
  public void RepositionCloseFollowOption() {
   if(CloseFollowOptionArranging||CloseFollowOptionBox==null||CloseFollowOptionAnchor==null)return;
   CloseFollowOptionArranging=true;
   try {
    Control anchor=CloseFollowOptionAnchor,parent=anchor.Parent;CheckBox box=CloseFollowOptionBox;
    if(parent==null||parent.IsDisposed||box.IsDisposed)return;
    if(box.Font!=anchor.Font)box.Font=anchor.Font;
    box.ForeColor=Color.Yellow;box.BackColor=Color.FromArgb(40,40,40);box.UseVisualStyleBackColor=false;
    int gap=Math.Max(10,anchor.Font.Height);
    int anchorWidth=Math.Max(anchor.Width,TextRenderer.MeasureText(anchor.Text,anchor.Font).Width+24);
    Size size=box.GetPreferredSize(Size.Empty);
    int y=Math.Max(0,anchor.Top+(anchor.Height-size.Height)/2);
    int minimum=anchor.Left+anchorWidth+gap;
    int preferred=Math.Max(minimum,parent.ClientSize.Width/2);
    Rectangle bounds=new Rectangle(preferred,y,size.Width,size.Height);
    if(!CloseFollowOptionFits(parent,bounds)) {
     bool found=false;
     for(int x=parent.ClientSize.Width-size.Width-gap;x>=minimum;x-=4) {
      bounds=new Rectangle(x,y,size.Width,size.Height);
      if(CloseFollowOptionFits(parent,bounds)){found=true;break;}
     }
     if(!found) {
      if(CloseFollowOptionFallbackTop==0)CloseFollowOptionFallbackTop=anchor.Bottom+gap;
      bounds=new Rectangle(anchor.Left,CloseFollowOptionFallbackTop,size.Width,size.Height);
      int needed=bounds.Bottom+gap;
      if(parent.Height<needed) {
       Control[] controls=new Control[parent.Controls.Count];Rectangle[] positions=new Rectangle[controls.Length];
       for(int i=0;i<controls.Length;i++){controls[i]=parent.Controls[i];positions[i]=controls[i].Bounds;}
       parent.SuspendLayout();
       try{parent.Height=needed;for(int i=0;i<controls.Length;i++)if(controls[i]!=box)controls[i].Bounds=positions[i];}
       finally{parent.ResumeLayout(false);}
      }
     }
    }
    if(box.Bounds!=bounds)box.Bounds=bounds;
   }finally{CloseFollowOptionArranging=false;}
  }
  public bool TryCommitCloseFollowOption(string root) {
   if(CloseFollowOptionBox==null)return false;
   bool enabled=CloseFollowOptionBox.Checked;
   if(!Profile.TrySaveCloseFollowOption(root,enabled)) {
    CloseFollowOptionChanging=true;
    try{CloseFollowOptionBox.Checked=Profile.CloseFollowEnabled;}finally{CloseFollowOptionChanging=false;}
    return false;
   }
   Profile.CloseFollowEnabled=enabled;Profile.CloseFollowOptionsLoaded=true;return true;
  }
  private void CloseFollowOptionChanged(object sender,EventArgs args) {
   if(CloseFollowOptionChanging)return;
   if(!TryCommitCloseFollowOption(AppDomain.CurrentDomain.BaseDirectory))MessageBox.Show(this,"無法儲存貼身跟隨設定，已還原先前選擇。請確認程式資料夾的寫入權限。","設定未儲存",MessageBoxButtons.OK,MessageBoxIcon.Warning);
  }
 }
}
