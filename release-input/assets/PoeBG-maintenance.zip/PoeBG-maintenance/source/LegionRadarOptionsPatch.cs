using System;
using System.Linq;
using System.Collections.Generic;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class LegionRadarOptionsPatch {
 static void Need(bool ok,string message){if(!ok)throw new Exception("Legion radar options: "+message);}
 public static void Apply(ModuleDef module) {
  var main=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main");
  var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");
  var dialog=module.GetTypes().Single(t=>t.FullName=="PoeBG.SetRadar");
  Need(!profile.Fields.Any(f=>f.Name=="LegionRadarEnabled"),"already patched");
  var filter=main.Methods.Single(m=>m.Name=="FilterLegionRadar");
  var constructor=dialog.Methods.Single(m=>m.IsInstanceConstructor&&m.MethodSig.Params.Count==1&&m.MethodSig.Params[0].FullName==main.FullName);
  var returns=constructor.Body.Instructions.Where(i=>i.OpCode==OpCodes.Ret).ToArray();Need(returns.Length==1,"unexpected dialog constructor returns");
  var confirm=dialog.Methods.Single(m=>m.HasBody&&!m.IsConstructor&&m.Body.Instructions.Count(i=>i.OpCode==OpCodes.Stfld&&i.Operand is IField&&((IField)i.Operand).DeclaringType.FullName==main.FullName)>10&&m.Body.Instructions.Any(i=>i.Operand is IMethod&&((IMethod)i.Operand).Name=="Close"));
  Need(dialog.Methods.Any(m=>m.HasBody&&m.Body.Instructions.Any(i=>i.OpCode==OpCodes.Ldstr&&(string)i.Operand=="btOK")),"confirmation button identity missing");
  using(var source=ModuleDefMD.Load(typeof(LegionRadarOptionsPatch).Module.FullyQualifiedName)) {
   var map=new Mapper();map.Types["LegionRadarOptionsTemplate.Profile"]=profile;map.Types["LegionRadarOptionsTemplate.Dialog"]=dialog;
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="LegionRadarOptionsTemplate.Profile"||t.FullName=="LegionRadarOptionsTemplate.Dialog").SelectMany(t=>t.Fields)) {
    var target=new FieldDefUser(original.Name,new FieldSig(new Importer(module).Import(original.FieldSig.Type)),original.Attributes);
    var owner=original.DeclaringType.Name=="Profile"?profile:dialog;owner.Fields.Add(target);map.Fields[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   var importer=new Importer(module,ImporterOptions.TryToUseTypeDefs,new GenericParamContext(),map);var copies=new Dictionary<MethodDef,MethodDef>();
   foreach(var original in source.GetTypes().Where(t=>t.FullName=="LegionRadarOptionsTemplate.Profile"||t.FullName=="LegionRadarOptionsTemplate.Dialog").SelectMany(t=>t.Methods).Where(m=>m.HasBody&&!m.IsConstructor)) {
    var target=new MethodDefUser(original.Name,importer.Import(original.MethodSig),original.ImplAttributes,original.Attributes);var owner=original.DeclaringType.Name=="Profile"?profile:dialog;owner.Methods.Add(target);copies[original]=target;map.Methods[original.DeclaringType.FullName+"::"+original.Name]=target;
   }
   foreach(var item in copies)CopyBody(item.Key,item.Value,importer);
  }
  var load=profile.Methods.Single(m=>m.Name=="LoadLegionRadarOptions");var flag=profile.Fields.Single(f=>f.Name=="LegionRadarEnabled");var originalFilter=filter.Body.Instructions[0];
  var gate=new[]{Instruction.Create(OpCodes.Call,load),Instruction.Create(OpCodes.Volatile),Instruction.Create(OpCodes.Ldsfld,flag),Instruction.Create(OpCodes.Brtrue,originalFilter),Instruction.Create(OpCodes.Ldarg_1),Instruction.Create(OpCodes.Ret)};
  for(int i=0;i<gate.Length;i++)filter.Body.Instructions.Insert(i,gate[i]);filter.Body.SimplifyBranches();
  var attach=dialog.Methods.Single(m=>m.Name=="AttachLegionRadarOption");var ret=returns[0];int at=constructor.Body.Instructions.IndexOf(ret);ret.OpCode=OpCodes.Ldarg_0;ret.Operand=null;constructor.Body.Instructions.Insert(++at,Instruction.Create(OpCodes.Call,attach));constructor.Body.Instructions.Insert(++at,Instruction.Create(OpCodes.Ret));constructor.Body.SimplifyBranches();
  var commit=dialog.Methods.Single(m=>m.Name=="CommitLegionRadarOption");var originalConfirm=confirm.Body.Instructions[0];var prefix=new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Call,commit),Instruction.Create(OpCodes.Brtrue,originalConfirm),Instruction.Create(OpCodes.Ret)};
  for(int i=0;i<prefix.Length;i++)confirm.Body.Instructions.Insert(i,prefix[i]);confirm.Body.SimplifyBranches();
  var schema=new FieldDefUser("LegionRadarOptionsSchema",new FieldSig(module.CorLibTypes.String),FieldAttributes.Public|FieldAttributes.Static|FieldAttributes.Literal|FieldAttributes.HasDefault);schema.Constant=new ConstantUser("1");profile.Fields.Add(schema);Validate(module);
 }
 public static void Validate(ModuleDef module) {
  var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");Need(profile.Fields.Single(f=>f.Name=="LegionRadarOptionsSchema").Constant.Value.ToString()=="1","schema missing");
  var dialog=module.GetTypes().Single(t=>t.FullName=="PoeBG.SetRadar");Need(dialog.Fields.Single(f=>f.Name=="LegionRadarActiveOnlyBox").FieldSig.Type.FullName=="System.Windows.Forms.CheckBox","checkbox field missing");
  var all=module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).ToArray();
  foreach(var name in new[]{"AttachLegionRadarOption","CommitLegionRadarOption"}) {var target=dialog.Methods.Single(m=>m.Name==name);Need(all.Sum(m=>m.Body.Instructions.Count(i=>i.Operand is IMethod&&((IMethod)i.Operand).FullName==target.FullName))==1,"UI hook missing/duplicated: "+name);}
  var filter=module.GetTypes().Single(t=>t.FullName=="PoeBG.Main").Methods.Single(m=>m.Name=="FilterLegionRadar");Need(filter.Body.Instructions[0].Operand is IMethod&&((IMethod)filter.Body.Instructions[0].Operand).Name=="LoadLegionRadarOptions","filter toggle gate missing");
  Need(!all.Where(m=>m.Name.StartsWith("LegionRadar")||m.Name.Contains("LegionRadarOption")).SelectMany(m=>m.Body.Instructions).Any(i=>i.Operand!=null&&i.Operand.ToString().Contains("LegionRadarOptionsTemplate")),"template reference leaked");
 }
 sealed class Mapper:ImportMapper {
  public readonly Dictionary<string,ITypeDefOrRef> Types=new Dictionary<string,ITypeDefOrRef>();
  public readonly Dictionary<string,IField> Fields=new Dictionary<string,IField>();
  public readonly Dictionary<string,IMethod> Methods=new Dictionary<string,IMethod>();
  public override ITypeDefOrRef Map(ITypeDefOrRef t){ITypeDefOrRef v;return Types.TryGetValue(t.FullName,out v)?v:null;}
  public override IField Map(FieldDef f){IField v;return Fields.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
  public override IMethod Map(MethodDef f){IMethod v;return Methods.TryGetValue(f.DeclaringType.FullName+"::"+f.Name,out v)?v:null;}
 }
 static void CopyBody(MethodDef source,MethodDef target,Importer importer) {
  target.Body=new CilBody{InitLocals=source.Body.InitLocals,MaxStack=source.Body.MaxStack};
  var locals=new Dictionary<Local,Local>();foreach(var l in source.Body.Variables){var n=new Local(importer.Import(l.Type));target.Body.Variables.Add(n);locals[l]=n;}
  var instructions=new Dictionary<Instruction,Instruction>();foreach(var i in source.Body.Instructions){var n=new Instruction(i.OpCode,null);target.Body.Instructions.Add(n);instructions[i]=n;}
  foreach(var i in source.Body.Instructions){object o=i.Operand;if(o is Instruction)o=instructions[(Instruction)o];else if(o is Instruction[])o=((Instruction[])o).Select(x=>instructions[x]).ToArray();else if(o is Local)o=locals[(Local)o];else if(o is Parameter)o=target.Parameters[((Parameter)o).Index];else if(o is IMethod)o=importer.Import((IMethod)o);else if(o is IField)o=importer.Import((IField)o);else if(o is ITypeDefOrRef)o=importer.Import((ITypeDefOrRef)o);else if(o is MethodSig)o=importer.Import((MethodSig)o);instructions[i].Operand=o;}
  foreach(var h in source.Body.ExceptionHandlers)target.Body.ExceptionHandlers.Add(new ExceptionHandler(h.HandlerType){TryStart=h.TryStart==null?null:instructions[h.TryStart],TryEnd=h.TryEnd==null?null:instructions[h.TryEnd],HandlerStart=h.HandlerStart==null?null:instructions[h.HandlerStart],HandlerEnd=h.HandlerEnd==null?null:instructions[h.HandlerEnd],FilterStart=h.FilterStart==null?null:instructions[h.FilterStart],CatchType=h.CatchType==null?null:importer.Import(h.CatchType)});
  target.Body.SimplifyBranches();
 }
}
