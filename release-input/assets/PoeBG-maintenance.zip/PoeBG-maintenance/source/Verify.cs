using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
class Verify {
    static Assembly target;
    static Type profile;
    static string Name(string key) { return (string)profile.GetField(key).GetRawConstantValue(); }
    static object Invoke(Type t, object obj, string name, params object[] args) {
        return t.GetMethod(name, BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).Invoke(obj,args);
    }
    [STAThread]
    static void Main(string[] args) {
        try { Run(args); } catch(Exception ex) { Console.Error.WriteLine(ex.ToString()); Environment.ExitCode=1; }
    }
    static void Run(string[] args) {
        AppDomain.CurrentDomain.AssemblyResolve += (s,e) => {
            string name = new AssemblyName(e.Name).Name + ".dll";
            string path = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[0])),"Lib",name);
            if (File.Exists(path)) return Assembly.LoadFrom(path);
            string resource = target.GetManifestResourceNames().FirstOrDefault(r => r.EndsWith("."+name,StringComparison.OrdinalIgnoreCase));
            if (resource == null) return null;
            using(var stream = target.GetManifestResourceStream(resource)) using(var mem = new MemoryStream()) { stream.CopyTo(mem); return Assembly.Load(mem.ToArray()); }
        };
        target = Assembly.LoadFrom(Path.GetFullPath(args[0]));
        profile = target.GetType("PoeBG.LocalPatchProfile",true);
        if (Name("Schema") != "2") throw new Exception("Unsupported patch profile");
        LegionRadarVerification.Run(target);
        LegionRadarOptionsVerification.Run(target);
        CloseFollowOptionsVerification.Run(target);
        CloseFollowVerification.Run(target);
        FollowMoveInputVerification.Run(target);
        CloseFollowStabilityVerification.Run(target);
        CloseFollowTerrainVerification.Run(target);
        int compiled=0;
        foreach(var type in target.GetTypes())foreach(var method in type.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly).Cast<MethodBase>().Concat(type.GetConstructors(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly))) {
            if(method.Name==".cctor"||method.IsAbstract||method.ContainsGenericParameters||method.GetMethodBody()==null)continue;
            RuntimeHelpers.PrepareMethod(method.MethodHandle);compiled++;
        }
        Console.WriteLine("PASS: "+compiled+" managed methods compile with all required managed dependencies; no game functions invoked.");
        Type t = target.GetType("PoeBG.Main",true);
        var fontFactory=profile.GetMethods(BindingFlags.Public|BindingFlags.Static).Single(m=>m.ReturnType==typeof(System.Drawing.Font)&&m.GetParameters().Select(p=>p.ParameterType).SequenceEqual(new[]{typeof(string),typeof(float),typeof(System.Drawing.FontStyle)}));
        foreach(float size in new[]{0f,-1f,float.NaN,float.PositiveInfinity,20f})using(var font=(System.Drawing.Font)fontFactory.Invoke(null,new object[]{"Arial",size,System.Drawing.FontStyle.Bold})) {
            if(font.Size!=(size==20f?20f:12f))throw new Exception("Font size validation failed");
        }
        Console.WriteLine("PASS: invalid font sizes recover to 12; normal font sizes remain unchanged.");
        RuntimeHelpers.PrepareMethod(target.GetType("LegendTool.LoadResoureDll",true).GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Single(m=>m.ReturnType==typeof(void)&&m.GetParameters().Select(p=>p.ParameterType).SequenceEqual(new[]{typeof(string)})).MethodHandle);
        RuntimeHelpers.PrepareMethod(target.EntryPoint.MethodHandle);
        var apiWrapper=t.GetMethod(Name("ApiMethod"));
        var asyncAttribute=(System.Runtime.CompilerServices.AsyncStateMachineAttribute)Attribute.GetCustomAttribute(apiWrapper,typeof(System.Runtime.CompilerServices.AsyncStateMachineAttribute));
        RuntimeHelpers.PrepareMethod(asyncAttribute.StateMachineType.GetMethod("MoveNext",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).MethodHandle);
        var scanner=target.GetType("dotNetMemoryScan");
        var scannerMethod=scanner.GetMethods(BindingFlags.Instance|BindingFlags.NonPublic).Single(m=>m.ReturnType==typeof(IntPtr)&&m.GetParameters().Length==4&&m.GetParameters()[0].ParameterType==typeof(System.Diagnostics.Process)&&m.GetParameters()[1].ParameterType==typeof(string)&&m.GetParameters()[2].ParameterType==typeof(int)&&m.GetParameters()[3].ParameterType==typeof(int));
        RuntimeHelpers.PrepareMethod(scannerMethod.MethodHandle);
        var gameScanner=target.GetType("PoeBG.Scanner");
        var gameScanMethod=gameScanner.GetMethods(BindingFlags.Instance|BindingFlags.Public|BindingFlags.DeclaredOnly).Single(m=>m.ReturnType==typeof(IntPtr)&&m.GetParameters().Length==0);
        RuntimeHelpers.PrepareMethod(gameScanMethod.MethodHandle);
        using(var self=System.Diagnostics.Process.GetCurrentProcess()) {
            var probe=Activator.CreateInstance(gameScanner,new object[]{self,self.Handle,"4D 5A",0});
            gameScanner.GetMethods(BindingFlags.Instance|BindingFlags.Public|BindingFlags.DeclaredOnly).Single(m=>m.GetParameters().Length==1&&m.GetParameters()[0].ParameterType==typeof(System.Diagnostics.ProcessModule)).Invoke(probe,new object[]{self.MainModule});
            if((IntPtr)gameScanMethod.Invoke(probe,null)!=self.MainModule.BaseAddress)throw new Exception("Game scanner self-process integration failed");
            var accountProbe=FormatterServices.GetUninitializedObject(scanner);
            var accountScanMethod=scanner.GetMethods(BindingFlags.Instance|BindingFlags.Public|BindingFlags.DeclaredOnly).Single(m=>m.ReturnType==typeof(IntPtr)&&m.GetParameters().Length==5&&m.GetParameters()[0].ParameterType==typeof(System.Diagnostics.Process)&&m.GetParameters()[1].ParameterType==typeof(string)&&m.GetParameters()[2].ParameterType==typeof(string)&&m.GetParameters()[3].ParameterType==typeof(int)&&m.GetParameters()[4].ParameterType==typeof(int));
            if((IntPtr)accountScanMethod.Invoke(accountProbe,new object[]{self,self.ProcessName,"4D 5A",0,4096})!=self.MainModule.BaseAddress)throw new Exception("Account scanner self-process integration failed");
        }
        object obj = FormatterServices.GetUninitializedObject(t);
        for(int mode=0;mode<2;mode++) {
            bool poe1=mode==0;
            t.GetField(Name("ModeField")).SetValue(obj,poe1);
            Invoke(t,obj,Name("OffsetInitMethod"));
            var state=(int[][])t.GetField(Name("StatusChainField")).GetValue(null);
            var player=(int[])t.GetField(Name("PlayerChainField")).GetValue(obj);
            var network=(int[])t.GetNestedType("osServerData",BindingFlags.Public|BindingFlags.NonPublic).GetField(Name("NetworkStateField")).GetValue(null);
            for(int server=0;server<2;server++) {
                if(poe1 && (!state[server].SequenceEqual(new[]{536,2424})||player[server]!=2432||network[server]!=51224))throw new Exception("POE1 character layout check failed");
                if(!poe1 && (!state[server].SequenceEqual(new[]{656,680,8})||player[server]!=1496||network[server]!=192))throw new Exception("POE2 character layout changed");
            }
        }
        t.GetField(Name("ModeField")).SetValue(obj,true);Invoke(t,obj,Name("OffsetInitMethod"));
        var memory=Marshal.AllocHGlobal(65536);
        try {
            Marshal.Copy(new byte[65536],0,memory,65536);
            long state=memory.ToInt64(),data=state+1024,server=state+4096,player=state+60000,components=state+60256,life=state+60512;
            Marshal.WriteInt64(new IntPtr(state+536),data);Marshal.WriteInt64(new IntPtr(data+2424),server);Marshal.WriteInt64(new IntPtr(data+2432),player);
            Marshal.WriteInt32(new IntPtr(server+51224),3);Marshal.WriteInt64(new IntPtr(player+16),components);Marshal.WriteInt64(new IntPtr(components+32),life);
            Marshal.WriteInt32(new IntPtr(life+392+32),213);Marshal.WriteInt32(new IntPtr(life+392+112),116);
            using(var self=System.Diagnostics.Process.GetCurrentProcess()) {
                t.GetField(Name("ProcessHandleField")).SetValue(obj,self.Handle);
                if((int)Invoke(t,obj,Name("StatusReadMethod"),state,new[]{536,2424,51224},4)!=3)throw new Exception("Role status chain integration failed");
                long local=(long)Invoke(t,obj,Name("LongChainMethod"),state,new[]{536,2432});
                long buffer=(long)Invoke(t,obj,Name("PointerChainMethod"),local+16,new[]{32},false);
                if((int)Invoke(t,obj,Name("IntReadMethod"),buffer+392+32,null,4,false)!=213 || (int)Invoke(t,obj,Name("IntReadMethod"),buffer+392+112,null,4,false)!=116)throw new Exception("Health/mana chain integration failed");
            }
        } finally {Marshal.FreeHGlobal(memory);}
        Console.WriteLine("PASS: character layouts for both games/servers and own-process role/HP/MP chain integration.");
        string date = ((Task<string>)Invoke(t,obj,Name("LicenseMethod"),"local-test")).GetAwaiter().GetResult();
        if (date != "9999-12-31 23:59:59" || !(bool)t.GetField(Name("FlagField")).GetValue(obj)) throw new Exception("License provider check failed");
        if (!(bool)Invoke(t,obj,Name("ValidMethod"))) throw new Exception("Expiry check failed");
        string now = ((Task<string>)Invoke(t,obj,Name("ApiMethod"),"qrySysDateTime","")).GetAwaiter().GetResult();
        if (Math.Abs((DateTime.Parse(now)-DateTime.Now).TotalSeconds)>5) throw new Exception("Local time check failed");
        if (!((Task<bool>)Invoke(t,obj,Name("TrialMethod"),false)).GetAwaiter().GetResult()) throw new Exception("Trial check failed");
        Invoke(t,obj,Name("BuyHandler"),null,EventArgs.Empty);
        Invoke(t,obj,Name("TrialHandler"),null,EventArgs.Empty);
        if (args.Length > 1 && args[1] == "--ui") {
            Application.EnableVisualStyles();
            var dynamicAssembly = AppDomain.CurrentDomain.DefineDynamicAssembly(new AssemblyName("StartupProbe"),AssemblyBuilderAccess.Run);
            var derived = dynamicAssembly.DefineDynamicModule("Probe").DefineType("ProbeMain",System.Reflection.TypeAttributes.Public,t);
            foreach (string name in new[] {"OnLoad","OnShown"}) {
                var method = derived.DefineMethod(name,MethodAttributes.Family|MethodAttributes.Virtual|MethodAttributes.HideBySig,typeof(void),new[]{typeof(EventArgs)});
                method.GetILGenerator().Emit(OpCodes.Ret);
                derived.DefineMethodOverride(method,typeof(Form).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic));
            }
            using (var form = (Form)Activator.CreateInstance(derived.CreateType())) {
                if (form.Controls.Count == 0) throw new Exception("No main window controls");
                form.ShowInTaskbar=false; form.StartPosition=FormStartPosition.Manual; form.Location=new System.Drawing.Point(-32000,-32000); form.Show();
                CloseFollowLayoutVerification.Run(form);
                using(var bitmap = new System.Drawing.Bitmap(form.Width, form.Height)) {
                    form.DrawToBitmap(bitmap,new System.Drawing.Rectangle(0,0,form.Width,form.Height));
                    bitmap.Save(args[2],System.Drawing.Imaging.ImageFormat.Png);
                }
                Console.WriteLine("PASS: startup resource loader JIT and main window construction/render ("+form.Controls.Count+" controls).");
            }
        }
        Console.WriteLine("PASS: runtime license result, full-feature flag, expiry, local time, disabled payment/trial handlers.");
        Console.WriteLine("The application entry point and game interaction were not run.");
    }
}




