using System;
using System.Reflection;
public static class FollowMoveInputVerification {
 public static void Run(Assembly assembly) {
  var profile=assembly.GetType("PoeBG.LocalPatchProfile",true);
  var schema=profile.GetField("CloseFollowInputSchema");
  var eligible=profile.GetMethod("IsCloseFollowMoveLetter");var data=profile.GetMethod("CloseFollowMoveKeyData");
  if(schema==null||(string)schema.GetRawConstantValue()!="1"||eligible==null||data==null)throw new Exception("Missing owned close-follow input maintenance");
  int checks=0;Action<bool> need=ok=>{if(!ok)throw new Exception("Close-follow input encoding regression");checks++;};
  foreach(int key in new[]{65,84,90})need((bool)eligible.Invoke(null,new object[]{key}));
  foreach(int key in new[]{1,2,16,17,18,32,48,64,91,97,112})need(!(bool)eligible.Invoke(null,new object[]{key}));
  Func<bool,bool,uint> encode=(up,repeated)=>unchecked((uint)(int)data.Invoke(null,new object[]{44u,up,repeated}));
  uint first=encode(false,false),repeat=encode(false,true),release=encode(true,false);
  need((first&0xFFFFu)==1u);need(((first>>16)&255u)==44u);need((first&0xC0000000u)==0);
  need((repeat&0xC0000000u)==0x40000000u);need((release&0xC0000000u)==0xC0000000u);
  Console.WriteLine("PASS: "+checks+" owned movement key and native-message encoding checks; no native input invoked.");
 }
}
