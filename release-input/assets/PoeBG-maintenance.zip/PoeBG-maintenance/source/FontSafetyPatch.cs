using System;
using System.Linq;
using System.Collections.Generic;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
public static class FontSafetyPatch {
 public static void Apply(ModuleDef module) {
    var profile=module.GetTypes().Single(t=>t.FullName=="PoeBG.LocalPatchProfile");var import=new Importer(module);
    var safe=new MethodDefUser("SafeFontSize",MethodSig.CreateStatic(module.CorLibTypes.Single,module.CorLibTypes.Single),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Public|MethodAttributes.Static|MethodAttributes.HideBySig);
    profile.Methods.Add(safe);safe.Body=new CilBody();
    var fallback=Instruction.Create(OpCodes.Ldc_R4,12f);
    foreach(var i in new[]{Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldc_R4,0f),Instruction.Create(OpCodes.Ble_Un,fallback),Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ldc_R4,512f),Instruction.Create(OpCodes.Bgt_Un,fallback),Instruction.Create(OpCodes.Ldarg_0),Instruction.Create(OpCodes.Ret),fallback,Instruction.Create(OpCodes.Ret)})safe.Body.Instructions.Add(i);
    var factories=new Dictionary<string,MethodDef>();
    foreach(var method in module.GetTypes().SelectMany(t=>t.Methods).Where(m=>m.HasBody).ToArray())foreach(var ins in method.Body.Instructions.ToArray()) {
        var ctor=ins.Operand as IMethod;
        if(ins.OpCode!=OpCodes.Newobj||ctor==null||ctor.DeclaringType.FullName!="System.Drawing.Font"||ctor.MethodSig.Params.Count<2||ctor.MethodSig.Params[1].ElementType!=ElementType.R4)continue;
        MethodDef factory;if(!factories.TryGetValue(ctor.FullName,out factory)) {
            factory=new MethodDefUser("CreateFont"+factories.Count,MethodSig.CreateStatic(ctor.DeclaringType.ToTypeSig(),ctor.MethodSig.Params.ToArray()),MethodImplAttributes.IL|MethodImplAttributes.Managed,MethodAttributes.Public|MethodAttributes.Static|MethodAttributes.HideBySig);
            factory.Body=new CilBody();profile.Methods.Add(factory);
            for(int n=0;n<ctor.MethodSig.Params.Count;n++){factory.Body.Instructions.Add(Instruction.Create(OpCodes.Ldarg,factory.Parameters[n]));if(n==1)factory.Body.Instructions.Add(Instruction.Create(OpCodes.Call,safe));}
            factory.Body.Instructions.Add(Instruction.Create(OpCodes.Newobj,ctor));factory.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));factories.Add(ctor.FullName,factory);
        }
        ins.OpCode=OpCodes.Call;ins.Operand=factory;
    }
    if(factories.Count==0)throw new Exception("No font constructors recognized");
 }
}

