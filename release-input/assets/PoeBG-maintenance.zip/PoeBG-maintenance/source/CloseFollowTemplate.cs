using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace CloseFollowTemplate {
 public struct Vector {public float X,Y,Z;}
 public struct Grid {public float X,Y;}
 public static class Profile {
  public static volatile bool CloseFollowEnabled;
  public static void LoadCloseFollowOptions(){throw new NotSupportedException();}
  public static int CloseFollowLoopDelay(bool enabled,bool following,int original){return enabled&&following?40:original;}
  public static bool CloseFollowShouldMove(bool chasing,float distance){return !float.IsNaN(distance)&&!float.IsInfinity(distance)&&distance>=0f&&distance>(chasing?3f:6f);}
  public static int CloseFollowStuckLimit(bool enabled,int original){return enabled?(int)Math.Ceiling(original*2.5):original;}
  public static int CloseFollowCurrentStuckLimit(int original,bool following){LoadCloseFollowOptions();return CloseFollowStuckLimit(CloseFollowEnabled&&following,original);}
  public static int CloseFollowRepathInterval(bool enabled,long cost){return (int)Math.Max(enabled?120L:500L,Math.Min(int.MaxValue,cost));}
  public static bool CloseFollowFinite(float value){return !float.IsNaN(value)&&!float.IsInfinity(value);}
  public static float CloseFollowStepLength(float available,float limit){return CloseFollowFinite(available)&&CloseFollowFinite(limit)&&available>0&&limit>0?Math.Min(available,limit):0;}
  public static bool CloseFollowHoldAllowed(bool hold,float leaderShift,float distance){return hold&&CloseFollowFinite(leaderShift)&&CloseFollowFinite(distance)&&leaderShift>=0&&leaderShift<=2&&distance>=0&&distance<=8;}
  public static bool CloseFollowRouteStillRelevant(float oldX,float oldY,float newX,float newY){double a=(double)oldX*oldX+(double)oldY*oldY,b=(double)newX*newX+(double)newY*newY;if(!CloseFollowFinite(oldX)||!CloseFollowFinite(oldY)||!CloseFollowFinite(newX)||!CloseFollowFinite(newY)||a<0.01||b<0.01)return false;return ((double)oldX*newX+(double)oldY*newY)/Math.Sqrt(a*b)>=0.5;}
 }
 public class Owner {
  public bool FollowActive;
  public long SelfEntity,LeaderEntity;
  public byte[] Terrain; public int WorldWidth,WorldHeight,WorldPitch;
  public byte[] CloseFollowSolverTerrain,CloseFollowRouteTerrain; public int CloseFollowSolverWidth,CloseFollowSolverHeight,CloseFollowSolverPitch,CloseFollowSolveKind; public Vector CloseFollowSolveFrom,CloseFollowSolveTo; public float CloseFollowSolverOffsetX,CloseFollowSolverOffsetY; public bool CloseFollowDiscardRoute; public bool CloseFollowProgressObserved; public Vector CloseFollowProgressSelf,CloseFollowProgressLeader; public DateTime CloseFollowProgressAt,CloseFollowRetryAt;
  public bool CloseFollowChasing,CloseFollowHolding,CloseFollowLeaderObserved;
  public Grid CloseFollowHoldLeader,CloseFollowObservedLeader;
  public DateTime CloseFollowLeaderMovedAt,CloseFollowRouteStarted;
  public Vector CloseFollowRouteTarget;
  public List<Vector> CloseFollowRoute;
  public Task<List<Vector>> CloseFollowRouteTask;
  public int CloseFollowRouteCursor;
  public long CloseFollowRouteCost;
  public Task<Vector> CloseFollowLastPlanTask;
  public DateTime CloseFollowLastInvoke,CloseFollowLastRepath;
  public Task<Vector> OriginalPlanner(Vector target,int kind){throw new NotSupportedException();}
  public long ReadPointer(long address,int[] offsets,bool flag){throw new NotSupportedException();}
  public Vector ReadWorld(long address,bool flag){throw new NotSupportedException();}
  public Grid ReadGrid(long address,bool flag){throw new NotSupportedException();}
  public bool IsClearSegment(byte[] terrain,Vector from,Vector to){throw new NotSupportedException();}
  public List<Vector> RawSolve(Vector from,Vector to,int kind){throw new NotSupportedException();}
  private void CloseFollowIgnoreReload(){}
  private List<Vector> RunCloseFollowSolver(){
   Vector from=CloseFollowSolveFrom,to=CloseFollowSolveTo;from.X-=CloseFollowSolverOffsetX;from.Y-=CloseFollowSolverOffsetY;to.X-=CloseFollowSolverOffsetX;to.Y-=CloseFollowSolverOffsetY;
   var clock=Stopwatch.StartNew();try{var result=RawSolve(from,to,CloseFollowSolveKind);if(result!=null)for(int i=0;i<result.Count;i++){Vector p=result[i];p.X+=CloseFollowSolverOffsetX+5.4375f;p.Y+=CloseFollowSolverOffsetY+5.4375f;result[i]=p;}return result;}finally{CloseFollowRouteCost=clock.ElapsedMilliseconds;}
  }
  private bool PrepareCloseFollowSolver(Vector from,Vector to){
   byte[] data=Terrain;int width=WorldWidth,height=WorldHeight,pitch=WorldPitch;
   if(data==null||width<=0||height<=0||width>131072||height>131072||pitch<(width+1)/2||(long)pitch*height>data.Length)return false;
   int sx=(int)(from.X/10.875f),sy=(int)(from.Y/10.875f),tx=(int)(to.X/10.875f),ty=(int)(to.Y/10.875f);
   if(sx<0||sy<0||tx<0||ty<0||sx>=width||tx>=width||sy>=height||ty>=height)return false;
   int left=Math.Max(0,Math.Min(sx,tx)-64),top=Math.Max(0,Math.Min(sy,ty)-64),right=Math.Min(width-1,Math.Max(sx,tx)+64),bottom=Math.Min(height-1,Math.Max(sy,ty)+64);
   int cw=right-left+1,ch=bottom-top+1,cp=(cw+1)/2;if((long)cw*ch>4194304)return false;
   byte[] crop=new byte[cp*ch];
   for(int y=0;y<ch;y++)for(int x=0;x<cw;x++){int originalX=x+left;int value=(data[(y+top)*pitch+(originalX>>1)]>>((originalX&1)*4))&15;crop[y*cp+(x>>1)]|=(byte)(value<<((x&1)*4));}
   if(!object.ReferenceEquals(Terrain,data)||WorldWidth!=width||WorldHeight!=height||WorldPitch!=pitch)return false;
   CloseFollowSolverTerrain=crop;CloseFollowSolverWidth=cw;CloseFollowSolverHeight=ch;CloseFollowSolverPitch=cp;CloseFollowSolverOffsetX=left*10.875f;CloseFollowSolverOffsetY=top*10.875f;
   return true;
  }
  public void StopMove(){throw new NotSupportedException();}
  private bool CloseFollowIsActive(){Profile.LoadCloseFollowOptions();return Profile.CloseFollowEnabled&&FollowActive;}
  private static float CloseFollowLength(Vector a,Vector b){double x=a.X-b.X,y=a.Y-b.Y;return (float)Math.Sqrt(x*x+y*y);}
  private static Vector CloseFollowAlong(Vector a,Vector b,float amount){float distance=CloseFollowLength(a,b);if(distance<=0)return a;float t=amount/distance;return new Vector{X=a.X+(b.X-a.X)*t,Y=a.Y+(b.Y-a.Y)*t,Z=a.Z+(b.Z-a.Z)*t};}
  private bool CloseFollowValidPoint(Vector p){return Profile.CloseFollowFinite(p.X)&&Profile.CloseFollowFinite(p.Y)&&Profile.CloseFollowFinite(p.Z)&&p.X>0&&p.Y>0;}
  private void ResetCloseFollowRoute(){CloseFollowRoute=null;if(CloseFollowRouteTask!=null&&!CloseFollowRouteTask.IsCompleted)CloseFollowDiscardRoute=true;else{CloseFollowRouteTask=null;CloseFollowDiscardRoute=false;}CloseFollowRouteCursor=0;CloseFollowRouteStarted=default(DateTime);CloseFollowLastPlanTask=null;CloseFollowLastInvoke=default(DateTime);CloseFollowLastRepath=default(DateTime);}
  private Grid CloseFollowLeaderGrid(){long p=ReadPointer(LeaderEntity+16,new int[1],false);return p>0?ReadGrid(p,false):default(Grid);}
  private void CloseFollowHold(){CloseFollowHolding=true;CloseFollowHoldLeader=CloseFollowObservedLeader;CloseFollowChasing=false;ResetCloseFollowRoute();StopMove();}
  public int CloseFollowTickDelay(int original){bool active=CloseFollowIsActive();if(!active){CloseFollowChasing=false;CloseFollowHolding=false;CloseFollowLeaderObserved=false;CloseFollowProgressObserved=false;CloseFollowRetryAt=default(DateTime);ResetCloseFollowRoute();StopMove();}return Profile.CloseFollowLoopDelay(active,FollowActive,original);}
  public float CloseFollowMoveThreshold(float original,float distance){
   if(!CloseFollowIsActive()){CloseFollowChasing=false;CloseFollowHolding=false;ResetCloseFollowRoute();StopMove();return original;}
   try{
    Grid leader=CloseFollowLeaderGrid();if(!Profile.CloseFollowFinite(leader.X)||!Profile.CloseFollowFinite(leader.Y)||leader.X<=0||leader.Y<=0||!Profile.CloseFollowFinite(distance)||distance<0){ResetCloseFollowRoute();StopMove();return float.PositiveInfinity;}
    float observed=(float)Math.Sqrt(Math.Pow(leader.X-CloseFollowObservedLeader.X,2)+Math.Pow(leader.Y-CloseFollowObservedLeader.Y,2));
    if(!CloseFollowLeaderObserved||observed>=1){CloseFollowObservedLeader=leader;CloseFollowLeaderMovedAt=DateTime.UtcNow;CloseFollowLeaderObserved=true;}
    float heldShift=(float)Math.Sqrt(Math.Pow(leader.X-CloseFollowHoldLeader.X,2)+Math.Pow(leader.Y-CloseFollowHoldLeader.Y,2));
    if(Profile.CloseFollowHoldAllowed(CloseFollowHolding,heldShift,distance)){StopMove();return float.PositiveInfinity;}
    if(CloseFollowHolding){CloseFollowHolding=false;CloseFollowChasing=false;}
    bool moving=(DateTime.UtcNow-CloseFollowLeaderMovedAt).TotalMilliseconds<200;
    CloseFollowChasing=Profile.CloseFollowShouldMove(CloseFollowChasing,distance)||(moving&&distance>4);
    if(!CloseFollowChasing){if(distance<=3)CloseFollowHold();else StopMove();return float.PositiveInfinity;}
    return 3f;
   }catch(Exception){ResetCloseFollowRoute();StopMove();return float.PositiveInfinity;}
  }
  public int CloseFollowCounterLimit(int original){return Profile.CloseFollowStuckLimit(CloseFollowIsActive(),original);}
  private List<Vector> CloseFollowTrimRoute(List<Vector> route){
   if(route==null||route.Count==0)return null;var result=new List<Vector>(route);float remaining=32.625f;
   while(result.Count>1){int i=result.Count-1;float length=CloseFollowLength(result[i-1],result[i]);if(length<=remaining){remaining-=length;result.RemoveAt(i);}else{result[i]=CloseFollowAlong(result[i],result[i-1],remaining);break;}}
   return result;
  }
  private Vector SelectCloseFollowWaypoint(Vector self,List<Vector> path){
   if(path==null||path.Count==0)return default(Vector);if(CloseFollowRouteCursor<0||CloseFollowRouteCursor>=path.Count)CloseFollowRouteCursor=0;
      double nearest=double.MaxValue;int projected=CloseFollowRouteCursor;
   for(int i=Math.Max(0,CloseFollowRouteCursor-1);i<path.Count-1;i++){
    Vector a=path[i],b=path[i+1];double dx=b.X-a.X,dy=b.Y-a.Y,length=dx*dx+dy*dy;if(length<0.0001)continue;
    double u=Math.Max(0,Math.Min(1,((self.X-a.X)*dx+(self.Y-a.Y)*dy)/length));double px=a.X+u*dx,py=a.Y+u*dy,error=(self.X-px)*(self.X-px)+(self.Y-py)*(self.Y-py);
    if(error<=nearest){nearest=error;projected=i+1;}
   }
   CloseFollowRouteCursor=Math.Max(CloseFollowRouteCursor,projected);
   while(CloseFollowRouteCursor<path.Count-1&&CloseFollowLength(self,path[CloseFollowRouteCursor])<=4)CloseFollowRouteCursor++;
   Vector selected=default(Vector);
   for(int i=CloseFollowRouteCursor;i<path.Count;i++){
    Vector point=path[i];if(!CloseFollowValidPoint(point))return default(Vector);float length=CloseFollowLength(self,point);if(length<=4)continue;
    Vector candidate=CloseFollowAlong(self,point,Profile.CloseFollowStepLength(length,80));
    if(!IsClearSegment(Terrain,self,candidate))break;
    selected=candidate;if(length>80)break;
   }
   return selected;
  }
  public Task<Vector> PlanCloseFollow(Vector target,int kind){
   if(!CloseFollowIsActive())return OriginalPlanner(target,kind);
   try{
    long pointer=ReadPointer(SelfEntity+16,new[]{80},false);Vector self=pointer>0?ReadWorld(pointer,false):default(Vector);
    if(!CloseFollowValidPoint(self)||!CloseFollowValidPoint(target)||Terrain==null){ResetCloseFollowRoute();StopMove();return Task.FromResult(default(Vector));}
    if(CloseFollowRouteTerrain!=null&&!object.ReferenceEquals(CloseFollowRouteTerrain,Terrain)){ResetCloseFollowRoute();CloseFollowRouteTerrain=Terrain;}
    float distance=CloseFollowLength(self,target);DateTime progressNow=DateTime.UtcNow;
    if(progressNow<CloseFollowRetryAt){StopMove();return Task.FromResult(default(Vector));}
    if(!CloseFollowProgressObserved||CloseFollowLength(self,CloseFollowProgressSelf)>=3||CloseFollowLength(target,CloseFollowProgressLeader)>=12){CloseFollowProgressObserved=true;CloseFollowProgressSelf=self;CloseFollowProgressLeader=target;CloseFollowProgressAt=progressNow;}
    else if((progressNow-CloseFollowProgressAt).TotalMilliseconds>=500&&distance<=87){CloseFollowHold();return Task.FromResult(default(Vector));}
    else if((progressNow-CloseFollowProgressAt).TotalMilliseconds>=1000){ResetCloseFollowRoute();CloseFollowRetryAt=progressNow.AddMilliseconds(250);CloseFollowProgressAt=progressNow;StopMove();return Task.FromResult(default(Vector));}
    if(distance<=32.625f){CloseFollowHold();return Task.FromResult(default(Vector));}
    if(IsClearSegment(Terrain,self,target)){
     Vector goal=CloseFollowAlong(self,target,distance-32.625f);Vector next=CloseFollowAlong(self,goal,Profile.CloseFollowStepLength(CloseFollowLength(self,goal),80));
     if(CloseFollowLength(self,next)<=4){CloseFollowHold();return Task.FromResult(default(Vector));}
     if(IsClearSegment(Terrain,self,next))return Task.FromResult(next);
    }
    DateTime now=DateTime.UtcNow;
    if(CloseFollowRouteTask!=null){
     if(!CloseFollowRouteTask.IsCompleted){StopMove();return Task.FromResult(default(Vector));}
     
     if(CloseFollowDiscardRoute||CloseFollowRouteTask.IsCanceled||CloseFollowRouteTask.IsFaulted){CloseFollowRoute=null;}else{CloseFollowRoute=CloseFollowTrimRoute(CloseFollowRouteTask.Result);CloseFollowRouteCursor=0;}CloseFollowDiscardRoute=false;
     CloseFollowRouteTask=null;
    }
    double age=(now-CloseFollowRouteStarted).TotalMilliseconds;float shift=CloseFollowLength(target,CloseFollowRouteTarget);
    bool refresh=CloseFollowRoute==null||(age>=Profile.CloseFollowRepathInterval(true,CloseFollowRouteCost)&&shift>=20);
    if(refresh&&(CloseFollowRouteStarted==default(DateTime)||age<0||age>=Profile.CloseFollowRepathInterval(true,CloseFollowRouteCost))){
     if(!PrepareCloseFollowSolver(self,target)){StopMove();return Task.FromResult(default(Vector));}
     CloseFollowRouteStarted=now;CloseFollowRouteTarget=target;CloseFollowSolveFrom=self;CloseFollowSolveTo=target;CloseFollowSolveKind=kind;CloseFollowRouteTerrain=Terrain;CloseFollowDiscardRoute=false;CloseFollowRouteTask=Task.Run(new Func<List<Vector>>(RunCloseFollowSolver));
     if(CloseFollowRouteTask==null){StopMove();return Task.FromResult(default(Vector));}
     if(CloseFollowRouteTask.IsCompleted&&!CloseFollowRouteTask.IsCanceled&&!CloseFollowRouteTask.IsFaulted){CloseFollowRoute=CloseFollowTrimRoute(CloseFollowRouteTask.Result);CloseFollowRouteCursor=0;CloseFollowRouteTask=null;}else{StopMove();return Task.FromResult(default(Vector));}
    }
    if(!Profile.CloseFollowRouteStillRelevant(CloseFollowRouteTarget.X-self.X,CloseFollowRouteTarget.Y-self.Y,target.X-self.X,target.Y-self.Y)){CloseFollowRoute=null;StopMove();return Task.FromResult(default(Vector));}
    Vector waypoint=SelectCloseFollowWaypoint(self,CloseFollowRoute);
    if(!CloseFollowValidPoint(waypoint)){
     if(CloseFollowRoute!=null&&CloseFollowRoute.Count>0&&CloseFollowLength(self,CloseFollowRoute[CloseFollowRoute.Count-1])<=4)CloseFollowHold();else{CloseFollowRoute=null;StopMove();}
     return Task.FromResult(default(Vector));
    }
    return Task.FromResult(waypoint);
   }catch(Exception){ResetCloseFollowRoute();StopMove();return Task.FromResult(default(Vector));}
  }
 }
}