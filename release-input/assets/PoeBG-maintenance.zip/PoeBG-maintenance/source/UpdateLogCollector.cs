using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows.Forms;

[assembly:System.Reflection.AssemblyVersion("1.1.0.0")]
[assembly:System.Reflection.AssemblyFileVersion("1.1.0.0")]
public static class UpdateLogCollector {
    const int TailLimit=1024*1024;
    const int ArtifactLimit=64*1024*1024;
    static readonly string[] Components={"PoeBG.exe","PoeBGFriendsUpdater.exe","PoeBGUpdateGuard.exe","Updater.exe","Lib/PoeBG.UpdateSupport.dll","PoeBG-maintenance/Patch.exe","PoeBG-maintenance/Verify.exe"};
    static readonly UTF8Encoding Utf8=new UTF8Encoding(false);
    public static string Clean(string value,string appRoot) {
        string s=value??"";
        var paths=new[]{new[]{appRoot,"[PoeBG]"},new[]{Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"[Desktop]"},new[]{Path.GetTempPath().TrimEnd('\\','/'),"[Temp]"},new[]{Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"[UserProfile]"}};
        foreach(var p in paths.Where(p=>!string.IsNullOrEmpty(p[0])).OrderByDescending(p=>p[0].Length)){
            s=Regex.Replace(s,Regex.Escape(p[0]),m=>p[1],RegexOptions.IgnoreCase);
            s=Regex.Replace(s,Regex.Escape(p[0].Replace('\\','/')),m=>p[1],RegexOptions.IgnoreCase);
        }
        s=Regex.Replace(s,@"(?i)\b[A-Z]:[\\/][^\r\n\t""<>|]*","[LocalPath]");
        s=Regex.Replace(s,@"\\\\[^\r\n\t""<>|]+","[NetworkPath]");
        s=Regex.Replace(s,@"[\p{L}\p{N}_.-]+#\d{3,10}","[Account]");
        s=Regex.Replace(s,@"(?i)[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}","[Email]");
        s=Regex.Replace(s,@"(?im)\b(Authorization\s*:\s*)(?:Bearer|Basic)\s+[^\r\n]+","$1[Redacted]");
        s=Regex.Replace(s,@"(?im)((?:\b(?:account(?:name)?|username|user|password|passwd|pwd|token|api[_-]?key|secret|cookie)\b|帳號|帳戶|角色名稱|主人名稱|密碼)[""']?\s*[=:：]\s*)[^\r\n,;]+","$1[Redacted]");
        s=Regex.Replace(s,@"(?i)(https?://[^\s?""<>]+)\?[^\s""<>]+","$1?[QueryRedacted]");
        foreach(var name in new[]{Environment.UserName,Environment.MachineName}.Where(n=>n!=null&&n.Length>=3).Distinct())s=Regex.Replace(s,@"(?<![\p{L}\p{N}_])"+Regex.Escape(name)+@"(?![\p{L}\p{N}_])","[LocalIdentity]",RegexOptions.IgnoreCase);
        return s;
    }
    public static string SafeFile(string root,string relative) {
        root=Path.GetFullPath(root).TrimEnd('\\','/');
        string full=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));
        if(!full.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Path outside app folder");
        string current=root;
        if((File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked app folder is not collected");
        foreach(var part in full.Substring(root.Length+1).Split(Path.DirectorySeparatorChar)){
            current=Path.Combine(current,part);
            if((File.Exists(current)||Directory.Exists(current))&&(File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked files/folders are not collected");
        }
        return full;
    }
    public static string ReadTail(string path) {
        using(var s=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){
            bool cut=s.Length>TailLimit;long start=Math.Max(0,s.Length-TailLimit);s.Position=start;
            byte[] bytes=new byte[(int)Math.Min(TailLimit,s.Length-start)];int n=0,k;
            while(n<bytes.Length&&(k=s.Read(bytes,n,bytes.Length-n))>0)n+=k;
            Encoding encoding=Encoding.UTF8;int skip=0;
            if(!cut&&n>=2&&bytes[0]==255&&bytes[1]==254){encoding=Encoding.Unicode;skip=2;}
            else if(!cut&&n>=2&&bytes[0]==254&&bytes[1]==255){encoding=Encoding.BigEndianUnicode;skip=2;}
            else if(!cut&&n>=3&&bytes[0]==239&&bytes[1]==187&&bytes[2]==191)skip=3;
            else if(cut){s.Position=0;int a=s.ReadByte(),b=s.ReadByte();if(a==255&&b==254)encoding=Encoding.Unicode;else if(a==254&&b==255)encoding=Encoding.BigEndianUnicode;}
            if(cut&&encoding!=Encoding.UTF8&&start%2!=0)skip=1;
            string text=encoding.GetString(bytes,skip,n-skip);
            if(cut){int line=text.IndexOf('\n');if(line>=0&&line<text.Length-1)text=text.Substring(line+1);text="[Only the last 1 MiB of this log was read.]\r\n"+text;}
            return text;
        }
    }
    static string Hash(string path){using(var sha=SHA256.Create())using(var s=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))return BitConverter.ToString(sha.ComputeHash(s)).Replace("-","");}
    static void Add(ZipArchive zip,string name,string text,string root){var e=zip.CreateEntry(name,CompressionLevel.Optimal);using(var w=new StreamWriter(e.Open(),Utf8))w.Write(Clean(text,root));}
    static void AddUpstreamArtifact(ZipArchive zip,string root,StringBuilder report) {
        report.AppendLine();report.AppendLine("Update program artifact:");
        try {
            string transactions=SafeFile(root,"PoeBG-maintenance/transactions");
            if(!Directory.Exists(transactions)){report.AppendLine("upstream_Slayed.exe: missing (no transactions folder)");return;}
            // Inspect fixed filenames in recent direct transaction folders only.
            foreach(var d in new DirectoryInfo(transactions).GetDirectories().OrderByDescending(d=>d.LastWriteTimeUtc).ThenByDescending(d=>d.Name,StringComparer.Ordinal).Take(100)) {
                if((d.Attributes&FileAttributes.ReparsePoint)!=0){report.AppendLine("Linked transaction folder skipped.");continue;}
                string path=SafeFile(root,"PoeBG-maintenance/transactions/"+d.Name+"/upstream_Slayed.exe");
                if(!File.Exists(path))continue;
                report.AppendLine("Selected transaction modifiedUTC="+d.LastWriteTimeUtc.ToString("s"));
                byte[] bytes;
                using(var input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                    if(input.Length<64||input.Length>ArtifactLimit){report.AppendLine("upstream_Slayed.exe: excluded (invalid size or over 64 MiB)");return;}
                    bytes=new byte[(int)input.Length];int total=0,n;
                    while(total<bytes.Length&&(n=input.Read(bytes,total,bytes.Length-total))>0)total+=n;
                    if(total!=bytes.Length)throw new IOException("Update program changed or could not be fully read");
                }
                int pe=BitConverter.ToInt32(bytes,60);
                if(bytes[0]!=77||bytes[1]!=90||pe<64||pe>bytes.Length-24||bytes[pe]!=80||bytes[pe+1]!=69||bytes[pe+2]!=0||bytes[pe+3]!=0){report.AppendLine("upstream_Slayed.exe: excluded (invalid PE header)");return;}
                string digest;using(var sha=SHA256.Create())digest=BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","");
                string version=FileVersionInfo.GetVersionInfo(path).FileVersion;
                var entry=zip.CreateEntry("artifacts/upstream_Slayed.exe",CompressionLevel.Optimal);using(var target=entry.Open())target.Write(bytes,0,bytes.Length);
                report.AppendLine("upstream_Slayed.exe: INCLUDED unchanged; bytes="+bytes.Length+"; version="+version+"; SHA256="+digest);
                report.AppendLine("Binary bytes are NOT redacted. The artifact was copied only, never loaded or executed.");
                return;
            }
            report.AppendLine("upstream_Slayed.exe: missing in the 100 most recent direct transaction folders");
        } catch(Exception e) {report.AppendLine("upstream_Slayed.exe: unavailable: "+e.GetType().Name+" "+e.Message);}
    }
    public static string Collect(string root,string output) {
        root=Path.GetFullPath(root).TrimEnd('\\','/');
        if(!Directory.Exists(root))throw new IOException("PoeBG 資料夾不存在。");
        SafeFile(root,"PoeBG.exe");
        Directory.CreateDirectory(output);
        string dest=Path.Combine(output,"PoeBG-update-diagnostics-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6)+".zip");
        var report=new StringBuilder();
        report.AppendLine("PoeBG 更新診斷 / Collector 1.1.0");report.AppendLine("Collected: "+DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss zzz"));
        report.AppendLine("Windows: "+Environment.OSVersion.VersionString);report.AppendLine("64-bit OS: "+Environment.Is64BitOperatingSystem+"; collector 64-bit: "+Environment.Is64BitProcess);report.AppendLine(".NET CLR: "+Environment.Version);
        report.AppendLine("App root: [PoeBG]");
        report.AppendLine("Collection: update logs, fixed component metadata and one existing transaction upstream_Slayed.exe; no Role/configuration, screenshots, game memory, private keys or network requests.");
        try{report.AppendLine("Free space GiB: "+(new DriveInfo(Path.GetPathRoot(root)).AvailableFreeSpace/1073741824L));}catch(Exception e){report.AppendLine("Free space: unavailable ("+e.GetType().Name+")");}
        using(var zip=ZipFile.Open(dest,ZipArchiveMode.Create)){
            foreach(string relative in new[]{"PoeBG-maintenance/friends-update.log","PoeBG-maintenance/update.log"}){
                try{string p=SafeFile(root,relative);if(!File.Exists(p)){report.AppendLine(relative+": missing");continue;}Add(zip,"logs/"+Path.GetFileName(p)+".txt",ReadTail(p),root);report.AppendLine(relative+": included (sanitized, tail limited)");}
                catch(Exception e){report.AppendLine(relative+": unavailable: "+e.GetType().Name+" "+e.Message);}
            }
            report.AppendLine();report.AppendLine("Component files:");
            foreach(string relative in Components){
                try{string p=SafeFile(root,relative);if(!File.Exists(p)){report.AppendLine(relative+": MISSING");continue;}
                    var f=new FileInfo(p);report.AppendLine(relative+": version="+FileVersionInfo.GetVersionInfo(p).FileVersion+"; bytes="+f.Length+"; modifiedUTC="+f.LastWriteTimeUtc.ToString("s")+"; readonly="+f.IsReadOnly);
                    if(f.Length<=64L*1024*1024)report.AppendLine("  SHA256="+Hash(p));else report.AppendLine("  SHA256 skipped (over 64 MiB)");
                    try{using(var z=new FileStream(p+":Zone.Identifier",FileMode.Open,FileAccess.Read,FileShare.ReadWrite))report.AppendLine("  Download zone marker: present (contents excluded)");}catch(FileNotFoundException){report.AppendLine("  Download zone marker: absent");}catch{report.AppendLine("  Download zone marker: unavailable");}
                }catch(Exception e){report.AppendLine(relative+": unavailable: "+e.GetType().Name+" "+e.Message);}
            }
            foreach(string leaf in new[]{"installed-release.txt","blocked-version.txt"})try{
                string p=SafeFile(root,"PoeBG-maintenance/"+leaf);
                string text=File.Exists(p)?ReadTail(p).Trim():"";
                report.AppendLine(leaf+": "+(text==""?"missing/empty":Regex.IsMatch(text,@"^\d+(?:\.\d+){1,3}$")?text:"invalid value (contents excluded)"));
            }catch(Exception e){report.AppendLine(leaf+": unavailable ("+e.GetType().Name+")");}
            report.AppendLine();report.AppendLine("PoeBG processes (no titles, command lines or unrelated processes collected):");
            foreach(string name in new[]{"PoeBG","PoeBGUpdateGuard","PoeBGFriendsUpdater","Updater"}){
                int matching=0,unknown=0;
                foreach(var p in Process.GetProcessesByName(name))using(p)try{if(string.Equals(p.MainModule.FileName,Path.Combine(root,name+".exe"),StringComparison.OrdinalIgnoreCase))matching++;}catch{unknown++;}
                report.AppendLine(name+": this folder="+matching+"; location unreadable="+unknown);
            }
            try{
                string tx=SafeFile(root,"PoeBG-maintenance/transactions");
                if(Directory.Exists(tx))foreach(var d in new DirectoryInfo(tx).GetDirectories().OrderByDescending(d=>d.LastWriteTimeUtc).Take(3)){
                    string rel="PoeBG-maintenance/transactions/"+d.Name;SafeFile(root,rel);
                    report.AppendLine("Recent transaction: modifiedUTC="+d.LastWriteTimeUtc.ToString("s")+"; stage="+Directory.Exists(Path.Combine(d.FullName,"stage"))+"; verified="+Directory.Exists(Path.Combine(d.FullName,"verified"))+"; rollback="+Directory.Exists(Path.Combine(d.FullName,"rollback")));
                }
            }catch(Exception e){report.AppendLine("Transactions: unavailable ("+e.GetType().Name+")");}
            AddUpstreamArtifact(zip,root,report);
            Add(zip,"diagnostic-summary.txt",report.ToString(),root);
            Add(zip,"請先閱讀.txt","這是自動更新診斷 ZIP，可傳回協助排查。\r\n包含更新紀錄末尾、固定程式檔版本/雜湊，以及更新交易資料夾內最新找到的一份 upstream_Slayed.exe（最多64MiB）。\r\n更新程式副本原樣封裝，不做個資遮蔽，不會執行。只收集指定檔名，不收集整個更新資料夾。\r\n沒有收集 Role、INI、功能開關、金鑰、截圖或遊戲資料，也沒有自動上傳。\r\n文字紀錄中的常見帳號格式、Email、權杖及個人路徑已遮蔽；自由文字中未標示的個資仍可能未被辨識，分享前可自行查看。\r\n若沒有日誌或更新副本，摘要會標示 missing/unavailable；請保留原有資料夾。\r\n",root);
        }
        return dest;
    }
    static string FindRoot(string start) {
        string candidate=Path.GetFullPath(start);if(File.Exists(Path.Combine(candidate,"PoeBG.exe")))return candidate;
        if(string.Equals(Path.GetFileName(candidate.TrimEnd('\\')),"PoeBG-maintenance",StringComparison.OrdinalIgnoreCase)){
            var parent=Directory.GetParent(candidate);if(parent!=null&&File.Exists(Path.Combine(parent.FullName,"PoeBG.exe")))return parent.FullName;
        }
        return null;
    }
    [STAThread]public static int Main(string[] args) {
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        string root=FindRoot(AppDomain.CurrentDomain.BaseDirectory);
        if(root==null)using(var choose=new FolderBrowserDialog{Description="請選擇含有 PoeBG.exe 的資料夾（不需要關閉遊戲）",ShowNewFolderButton=false}){
            if(choose.ShowDialog()!=DialogResult.OK)return 0;root=FindRoot(choose.SelectedPath);
            if(root==null){MessageBox.Show("選取的資料夾找不到 PoeBG.exe。請將本工具放在 PoeBG.exe 旁再執行。","PoeBG 更新紀錄收集");return 1;}
        }
        string selectedRoot=root;
        using(var form=new Form{Text="PoeBG 更新紀錄收集",Width=450,Height=145,StartPosition=FormStartPosition.CenterScreen,FormBorderStyle=FormBorderStyle.FixedDialog,ControlBox=false}){
            form.Controls.Add(new Label{Left=18,Top=15,Width=405,Height=42,Text="正在收集紀錄及更新程式副本…\n只遮蔽文字日誌；不執行副本、不自動上傳。"});
            form.Controls.Add(new ProgressBar{Left=18,Top=65,Width=398,Style=ProgressBarStyle.Marquee});
            form.Shown+=async(s,e)=>{
                try{
                    string output=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);if(string.IsNullOrEmpty(output))output=Path.GetTempPath();
                    string dest=await Task.Run(()=>Collect(selectedRoot,output));
                    bool included;using(var archive=ZipFile.OpenRead(dest))included=archive.GetEntry("artifacts/upstream_Slayed.exe")!=null;
                    string status=included?"已附上 upstream_Slayed.exe 更新副本。":"未附上更新副本，原因已寫入摘要；請保留原資料夾。";
                    form.Hide();MessageBox.Show("已完成。"+status+"\n請把以下 ZIP 傳回即可：\n\n"+dest+"\n\n按確定後會顯示檔案位置。","PoeBG 更新紀錄收集完成",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    Process.Start(new ProcessStartInfo("explorer.exe","/select,\""+dest+"\""){UseShellExecute=true});
                }catch(Exception ex){form.Hide();MessageBox.Show("紀錄收集未完成：\n"+Clean(ex.Message,selectedRoot)+"\n\n請確認桌面可寫入，或手動傳回 PoeBG-maintenance 裡的兩份 update 紀錄。","PoeBG 更新紀錄收集",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
                finally{form.Close();}
            };
            Application.Run(form);
        }
        return 0;
    }
}
