using System;
using System.IO;
using System.Diagnostics;
class UpdateSupportTests {
 static int count;
 static void Check(bool ok,string reason){count++;if(!ok)throw new Exception(reason);}
 static string Filter(string value){return PoeBGUpdateSupport.Filter(value,"GetVerInfo","AppInfo");}
 static void Main(){
    string marker=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PoeBG-maintenance","blocked-version.txt");
    Directory.CreateDirectory(Path.GetDirectoryName(marker));
    string response="5.6.0.0@https://example.invalid/primary@https://example.invalid/mirror@notice@3";
    string current=FileVersionInfo.GetVersionInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PoeBG.exe")).FileVersion;
    string prior=Environment.GetEnvironmentVariable("POEBG_SKIP_UPDATE_ONCE");
    try {
        Environment.SetEnvironmentVariable("POEBG_SKIP_UPDATE_ONCE",null);
        Check(Filter(response)==response,"Unblocked updates changed");
        File.WriteAllText(marker,"5.6.0.0");
        string filtered=Filter(response);
        Check(!string.IsNullOrEmpty(filtered),"Blocked update became a connection failure");
        Check(filtered==current+response.Substring(response.IndexOf('@')),"URLs or notification metadata changed");
        Check(Filter("5.7.0.0@https://example.invalid/new@0")=="5.7.0.0@https://example.invalid/new@0","Future updates suppressed");
        Check(PoeBGUpdateSupport.Filter(response,"GetVerInfo","UpdaterInfo")==response,"Original updater notifications changed");
        Check(PoeBGUpdateSupport.Filter(response,"other","AppInfo")==response,"Other API commands changed");
        Check(Filter(null)==null && Filter("")=="" && Filter("X")=="X","Actual failed responses hidden");
        File.Delete(marker);
        Environment.SetEnvironmentVariable("POEBG_SKIP_UPDATE_ONCE","1");
        Check(Filter(response)==current+response.Substring(response.IndexOf('@')),"One-time restart skip became fatal");
        Check(PoeBGUpdateSupport.Filter(response,"GetVerInfo","UpdaterInfo")==response,"One-time skip affected updater");
        Console.WriteLine("PASS: "+count+" update filtering checks; blocked versions retain valid response and original notification fields.");
    } finally {Environment.SetEnvironmentVariable("POEBG_SKIP_UPDATE_ONCE",prior);if(File.Exists(marker))File.Delete(marker);}
 }
}
